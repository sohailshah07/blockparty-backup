module.exports = {
    mongoURL: {
        key: 'mongodb+srv://developer:d8KU0EWlUkq1wpV6@cluster0.ft8w2.mongodb.net/blockparty_db'
    }
}
