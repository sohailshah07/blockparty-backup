'use strict';
var env = require('../env.json');

var node_env = process.env.DEPLOY_ENV || 'dev';
console.log(env[node_env].secret);

module.exports = {
	secret: env[node_env].secret,
	user: env[node_env].user,
	host: env[node_env].host,
	database: env[node_env].database,
	password: env[node_env].password,
	port: env[node_env].port,
	pg_port: env[node_env].pg_port,
	clientID: env[node_env].clientID,
	clientSecret: env[node_env].clientSecret,
	apiKey: env[node_env].apiKey,
	mongoURL: env[node_env].mongoURL,
	mongoUN: env[node_env].mongoUN,
	mongoPW: env[node_env].mongoPW,
	sendGridAPIKey: env[node_env].sendGridAPIKey,
	fromEmail: env[node_env].fromEmail,
	templateIdFirst: env[node_env].templateIdFirst,
	templateIdSecond: env[node_env].templateIdSecond,
	STRIPE_PUBLISHABLE_KEY:  env[node_env].STRIPE_PUBLISHABLE_KEY,
	STRIPE_SECRET_KEY:env[node_env].STRIPE_SECRET_KEY,
};
