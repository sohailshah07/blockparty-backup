# Blockparty API

[VIDEO LINK](https://www.loom.com/share/cd9b9b909c7f41d2aedfa1e140b1ec4e)

### Setup guide

Install the following requirments if they are not already pre-installed on your computer:

* Node (https://nodejs.org/en/download/)(v12.3.1)
* NPM (v6.9.0), (Node also includes NPM)

To install all npm dependencies, clone the project locally and run the following command in the terminal:
```
$ cd blockparty-api
$ git checkout develop
$ git pull origin develop
$ npm install
```
The `npm install` command will download all dependencies and needs to be re-ran everytime there is a new dependency.

### Build/Deployment

To run the project locally, in the terminal run:
```
 npm start
```

This command will start a server on [localhost:3000](http://localhost:3000/), follow the link to verify the server is running.

### Branches

There are two important branches: `master` (used by Prod and QA/Stage) and `develop`.

For each new feature/fix, create a new custom branch.

#### Develop
Before starting a new feature, create a new local branch from `develop`:
```
git checkout develop
git pull origin develop
git checkout -b feature/feature-name
```

After your changes are done, create a Pull Request to `develop`.

#### Deployment to Develop server
Once the code is merged to develop, it will build and deploy the branch  to [dev server](http://dev.blockpartyinc.com/api/) using bitbucket pipelines.

#### Importing the Postman collection

Download postman [postman download](https://www.getpostman.com/downloads/) and import collection by [Blockparty postman link](https://www.getpostman.com/collections/3da779120aa4b6e86771).

While testing any API endpoints first obtain a jwt token from the `auth/login` endpoint. Then ensure that the token is included in the header of your other API requests. 