#!/bin/bash
# Install node.js and Forever.js
#sudo apt-get update
#sudo apt-get install nodejs-legacy -y
#sudo apt-get install npm  -y
#sudo npm install forever -g
sudo rm -rf /var/www/blockparty-node-api/*