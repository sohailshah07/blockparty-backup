#!/bin/bash
# Stop all servers and start the server
sudo pm2 stop all
sudo pm2 start /var/www/blockparty-node-api/server.js --name="blockparty-api" -i max
