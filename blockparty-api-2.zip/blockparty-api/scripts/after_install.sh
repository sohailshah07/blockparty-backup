#!/bin/bash
cd /var/www/blockparty-node-api
sudo npm install