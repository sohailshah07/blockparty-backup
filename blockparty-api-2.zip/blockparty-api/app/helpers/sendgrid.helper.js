const sgMail = require('@sendgrid/mail');
const config = require('../../config/main');
const fs = require('fs');


class SendGridHelper {
    static unlockMail(toRecipient, params) {
        sgMail.setApiKey(config.sendGridAPIKey);
        return new Promise((resolve, reject) => {
            if (params.partyPack_name === "2020 Castle View High School Football Sabercat Card") {
                const msg = {
                    to: toRecipient,
                    from: config.fromEmail,
                    subject: params.subject,
                    templateId: params.templateId,
                    dynamic_template_data: {
                        subject: params.subject,
                        partyPack_name: params.partyPack_name,
                        partyPack_image_url: params.partyPack_image_url,
                        unlock_code: params.unlock_code,
                        partyPack_business: params.partyPack_business,
                    },
                };
                sgMail.send(msg).then(
                    (data) => {
                        console.log(data);
                        resolve(data);
                    },
                    (error) => {
                        console.error(error);
                        if (error.response) {
                            console.error(error.response.body);
                            reject(error.response);
                        }
                    }
                );
            } else {
                fs.readFile("/var/www/blockparty-node-api/app/resources/SECORRules.png", (err, data) => {
                    if (err) {
                        console.log(err);
                    }
                    let base64Image = new Buffer(data, 'binary').toString('base64');
                    const msg = {
                        to: toRecipient,
                        from: config.fromEmail,
                        subject: params.subject,
                        templateId: params.templateId,
                        dynamic_template_data: {
                            subject: params.subject,
                            partyPack_name: params.partyPack_name,
                            partyPack_image_url: params.partyPack_image_url,
                            unlock_code: params.unlock_code,
                            partyPack_business: params.partyPack_business,
                        },
                        attachments: [{
                            content: base64Image,
                            fileName: 'SECORRules.png',
                            type: 'application/png',
                            disposition: 'attachment',
                            contextId: 'rules',
                        },]
                    };
                    sgMail.send(msg).then(
                        (data) => {
                            console.log(data);
                            resolve(data);
                        },
                        (error) => {
                            console.error(error);
                            if (error.response) {
                                console.error(error.response.body);
                                reject(error.response);
                            }
                        }
                    );

                })
            }
        });
    }
}

module.exports = SendGridHelper;
