/**
 * Check if the item matchs in two different arrays.
 * @param {*} obj
 * @param {*} key
 * @param {*} list
 * @returns boolean
 */
const containsObject = (obj, key, list) => {
	var i;
	for (i = 0; i < list.length; i++) {
		if (list[i][key].toString() === obj[key].toString()) {
			return true;
		}
	}

	return false;
};

module.exports = { containsObject };
