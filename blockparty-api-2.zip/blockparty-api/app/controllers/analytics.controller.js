const HttpCodes = require('http-status-codes');
const redeem = require('../models/analytics.model').redeemDeals;
const unlock = require('../models/analytics.model').unlock;
const transaction = require('../models/analytics.model').transaction;
const buttonTap = require('../models/analytics.model').buttonTap;
const viewed = require('../models/analytics.model').viewed;

const config = require('../../config/main');
const Passport = require('../models/passport.model');

const Pool = require('pg').Pool;
const pool = new Pool({
	user: config.user,
	host: config.host,
	database: config.database,
	password: config.password,
	port: config.pg_port,
});
class AnalyticsController {
	async addAnalytics(req, res) {
		const {
			platform,
			appVersion,
			eventType,
			eventKey,
			passportId,
			userId,
			passportSku,
			companyName,
			referralCode,
			partyPackType,
			month,
			year,
			date,
		} = req.body;
		try {
			const passportObj = await Passport.find();
			const findRealPassport = passportObj.find(
				(passport) => passport.passportPricing.sku === passportSku
			);
			if (!findRealPassport) {
				return res.status(HttpCodes.NOT_FOUND).json({
					error: `This passport_id ${passportId} is not found!`,
					errorCode: HttpCodes.NOT_FOUND,
				});
			}

			const createdBy = await this.getPsqlUser({
				id: userId,
			}).then(async (response) => {
				let user = response.rows[0];
				const analytics = {
					platform: platform,
					appVersion: appVersion,
					eventType: eventType,
					eventKey: eventKey,
					passportId: passportId,
					userId: userId,
					userName: user.first_name + ' ' + user.last_name,
					userEmail: user.email,
					referralCode: referralCode,
					companyName: companyName,
					partyPackType: !findRealPassport.partyPackType
						? 'REGULAR'
						: findRealPassport.partyPackType,
					month: month,
					year: year,
					date: date,
					createDate: new Date().toISOString(),
					passportSKU: findRealPassport.passportPricing.sku,
					parentPassportId: findRealPassport._id,
					passportName: findRealPassport.passportName,
				};

				switch (eventType) {
					case 'DEAL_REDEEM':
						new redeem(analytics).save();
						break;
					case 'BUTTON_TAP':
						new buttonTap(analytics).save();
						break;
					case 'UNLOCK':
						new unlock(analytics).save();
						break;
					case 'TRANSACTION':
						new transaction(analytics).save();
						break;
					case 'PROMO_VIEWED':
						new viewed(analytics).save();
						break;
					case 'PURCH_VIEWED':
						new viewed(analytics).save();
						break;
					case 'COUPON_VIEWED':
						new viewed(analytics).save();
						break;
					default:
						res.status(HttpCodes.NOT_FOUND).json({
							error: `Please enter a valid EventType`,
							errorCode: HttpCodes.NOT_FOUND,
						});
						break;
				}
			});

			res.status(HttpCodes.OK).json({
				statusCode: HttpCodes.OK,
				message: 'Event Saved Successfully',
			});
		} catch (error) {
			res.status(HttpCodes.NOT_FOUND).json({
				error: `Something went wrong please try again later. ${error}}`,
				errorCode: HttpCodes.NOT_FOUND,
			});
		}
	}

	async getPsqlUser(user) {
		try {
			return await pool.query('SELECT * FROM users WHERE id = $1', [user.id]);
		} catch (error) {
			console.log(error.stack);
		}
	}
}

module.exports = AnalyticsController;
