const config = require('../../config/main');
const HttpCodes = require('http-status-codes');
var crypt = require('../crypt');

const Pool = require('pg').Pool;
const pool = new Pool({
	user: config.user,
	host: config.host,
	database: config.database,
	password: config.password,
	port: config.pg_port,
});

class AuthController {
	async updatePassword(req, res) {
		try {
			const email = req.query.email;
			console.log(email);
			crypt.createHash('test1234', async function (passwordHash) {
				console.log(passwordHash);
				await pool.query(
					'UPDATE users SET password = $1 WHERE LOWER(email) = LOWER($2)',
					[passwordHash, email],
					(err, results) => {
						if (err) {
							res.status(HttpCodes.NOT_FOUND).json({
								error: `Something went wrong please try again later. ${err}}`,
								errorCode: HttpCodes.NOT_FOUND,
							});
						} else {
							res.status(HttpCodes.OK).json({
								statusCode: HttpCodes.OK,
								message: 'Password changed to test1234',
							});
						}
					}
				);
			});
		} catch (error) {
			res.status(HttpCodes.NOT_FOUND).json({
				error: `Something went wrong please try again later. ${error}}`,
				errorCode: HttpCodes.NOT_FOUND,
			});
		}
	}
}

module.exports = AuthController;
