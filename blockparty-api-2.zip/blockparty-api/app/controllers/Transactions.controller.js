const HttpCodes = require('http-status-codes');
const Transaction = require('../models/transactions.model');
const Passport = require('../models/passport.model');
const User = require('../models/users.model');
const Codes = require('../models/code.model');
const sendGridHelper = require('../helpers/sendgrid.helper');
const config = require('../../config/main');

const stripe = require('stripe')(config.STRIPE_SECRET_KEY);

class TransactionsController {
	/**
	 * @param {*} req
	 * @param {*} res
	 * @returns Object
	 * @memberof TransactionsController
	 */

	async createPaymentIntent(req, res) {
		const { amount, currency } = req.body;
		// Create a PaymentIntent with the order amount and currency
		const paymentIntent = await stripe.paymentIntents.create({
			amount: amount,
			currency: currency,
			statement_descriptor: 'Blockparty descriptor',
			statement_descriptor_suffix: 'Blockparty suffix',
		});

		// Send publishable key and PaymentIntent details to client
		res.send({
			publishableKey: config.STRIPE_PUBLISHABLE_KEY,
			// process.env.STRIPE_PUBLISHABLE_KEY,
			status: paymentIntent.status,
			clientSecret: paymentIntent.client_secret,
		});
	}

	async addTransaction(req, res) {
		const { userId, passportId, paymentDetails, count, email, username } = req.body;
		try {
			const findUser = await User.findOne({ userId: userId });
			const findPassport = await Passport.findById(passportId).exec();

			if (!findPassport) {
				return res.status(HttpCodes.NOT_FOUND).json({
					error: `This passport_id ${passportId} is not found!`,
					errorCode: HttpCodes.NOT_FOUND,
				});
			}
			const purchasedPassport = {
				transactionId: paymentDetails.id,
				passportName: findPassport.passportName,
				passportPublisher: findPassport.passportPublisher,
				purchased: true,
				passportDeals: findPassport.passportDeals,
				passportPhoto: findPassport.passportPhoto,
				passportPricing: findPassport.passportPricing,
				active: findPassport.active,
				icons: {
					Automotive:
						'https://blockpartyinc-photos.s3.us-east-2.amazonaws.com/category-icons/Automotive.png',
					Dining:
						'https://blockpartyinc-photos.s3.us-east-2.amazonaws.com/category-icons/Dining.png',
					Entertainment:
						'https://blockpartyinc-photos.s3.us-east-2.amazonaws.com/category-icons/Entertainment.png',
					Other: 'https://blockpartyinc-photos.s3.us-east-2.amazonaws.com/category-icons/Other.png',
					Retail:
						'https://blockpartyinc-photos.s3.us-east-2.amazonaws.com/category-icons/Retail.png',
					'Business Services':
						'https://blockpartyinc-photos.s3.us-east-2.amazonaws.com/category-icons/Business+Services.png',
					'Downtown Parker':
						' https://blockpartyinc-photos.s3.us-east-2.amazonaws.com/category-icons/Downtown+Parker.png',
					'Garden & Landscape':
						'https://blockpartyinc-photos.s3.us-east-2.amazonaws.com/category-icons/Garden+and+Landscape.png',
					'Health & Beauty':
						'https://blockpartyinc-photos.s3.us-east-2.amazonaws.com/category-icons/Health+and+Beauty.png',
					'Healthcare Services':
						'https://blockpartyinc-photos.s3.us-east-2.amazonaws.com/category-icons/Healthcare+Services.png',
					'Home Improvement': 'https://blockpartyinc-photos.s3.us-east-2.amazonaws.com/Home.png',
					'Hotels & Travel':
						'https://blockpartyinc-photos.s3.us-east-2.amazonaws.com/category-icons/Hotels+and+Travel.png',
					'Kids & Family':
						'https://blockpartyinc-photos.s3.us-east-2.amazonaws.com/category-icons/Kids+and+Family.png',
					'Moving Services':
						'https://blockpartyinc-photos.s3.us-east-2.amazonaws.com/category-icons/Moving+Services.png',
					'Parties & Events':
						'https://blockpartyinc-photos.s3.us-east-2.amazonaws.com/category-icons/Parties+and+Events.png',
					'Parties and Events':
						'https://blockpartyinc-photos.s3.us-east-2.amazonaws.com/category-icons/Parties+and+Events.png',
					'Pet Services':
						'https://blockpartyinc-photos.s3.us-east-2.amazonaws.com/category-icons/Pet+Services.png',
					'Professional Services':
						'https://blockpartyinc-photos.s3.us-east-2.amazonaws.com/category-icons/Professional+Services.png',
					'Seasonal-Other':
						'https://blockpartyinc-photos.s3.us-east-2.amazonaws.com/category-icons/Seasonal-Other.png',
					'Sports & Activities':
						'https://blockpartyinc-photos.s3.us-east-2.amazonaws.com/category-icons/Sports+and+Activities.png',
				},
				createDate: findPassport.createDate,
				expiryDate: findPassport.expiryDate,
				location: findPassport.location,
				partyPackType: findPassport.partyPackType,
				purchasedDate: new Date().toISOString(),
				isUnlocked: true,
			};

			const passportList = [];
			if (count >= 1) {
				var UniqueCodes = [];
				for (let i = 0; i < count; i++) {
					const shortCode = this.makeid(8);
					passportList.push(purchasedPassport);
					UniqueCodes.push(
						'<span style="background-color:#EBD9D9;">' + shortCode + '</span><br><br>'
					);
					const sellerCodeData = {
						passportId: passportId,
						passportPSKU: '',
						unlockCode: shortCode,
						isActive: true,
						sellerId: '',
						sellerName: '',
						isUnlocked: true,
						unlockedBy: '',
						username: '',
						email: '',
						partyPackType: findPassport.partyPackType,
						createdByEmail: email,
						createdByUserName: username,
						createdByUserId: userId,
						createDate: new Date().toISOString(),
					};
					new Codes(sellerCodeData).save();
				}
				// if (findPassport.passportName === "2020 Castle View High School Football Sabercat Card") {
				//     const params = {
				//         "unlock_code": UniqueCodes,
				//         "subject": "PartyPack Unlock Codes",
				//         "partyPack_name": findPassport.passportName,
				//         "partyPack_image_url": findPassport.passportPhoto.thumbnailUrl.toString(),
				//         "partyPack_business": findPassport.passportPublisher.publisherName,
				//         "templateId": config.templateIdFirst
				//     }
				//     await sendGridHelper.unlockMail(email, params);
				// } else if (findPassport.passportName === "16 Stops for SECOR") {
				//     const params = {
				//         "unlock_code": UniqueCodes,
				//         "subject": "PartyPack Unlock Codes",
				//         "partyPack_name": '16 Stops for SECORCARES Passport',
				//         "partyPack_image_url": findPassport.passportPhoto.thumbnailUrl.toString(),
				//         "partyPack_business": findPassport.passportPublisher.publisherName,
				//         "templateId": config.templateIdSecond
				//     }
				//     await sendGridHelper.unlockMail(email, params);
				// } else {
				//     const params = {
				//         "unlock_code": UniqueCodes,
				//         "subject": "PartyPack Unlock Codes",
				//         "partyPack_name": findPassport.passportName,
				//         "partyPack_image_url": findPassport.passportPhoto.thumbnailUrl.toString(),
				//         "partyPack_business": findPassport.passportPublisher.publisherName,
				//         "templateId": config.templateIdFirst
				//     }
				//     await sendGridHelper.unlockMail(email, params);
				// }
			}
			if (!findUser) {
				//add user
				new User({
					userId: userId,
					passports: passportList,
				}).save();
			} else {
				//update user with Passport data
				if (count >= 1) {
					for (let i = 0; i < count; i++) {
						findUser.passports.push(purchasedPassport);
					}
					findUser.save();
				} else {
					return res.status(HttpCodes.NOT_FOUND).json({
						error: `Please enter a valid count`,
						errorCode: HttpCodes.NOT_FOUND,
					});
				}
			}
			// * create new transaction
			const transactionData = {
				user: findUser,
				payment_details: paymentDetails,
			};
			new Transaction(transactionData).save();
			res.status(HttpCodes.OK).json({
				statusCode: HttpCodes.OK,
				message: 'Transaction is successfully created!',
			});
		} catch (error) {
			return res.status(HttpCodes.NOT_FOUND).json({
				error: `Something went wrong please try again later. ${error}`,
				errorCode: HttpCodes.NOT_FOUND,
			});
		}
	}

	async redeemPassport(req, res) {
		const { userId, passportId, redeemCode, username, email } = req.body;
		try {
			const findUser = await User.findOne({ userId: userId });
			const findUnlockCode = await Codes.findOne({ unlockCode: redeemCode });
			if (!findUser) {
				const findPassport = await Passport.findById(passportId);
				if (!findPassport) {
					return res.status(HttpCodes.NOT_FOUND).json({
						error: `This passport_id ${passportId} is not found!`,
						errorCode: HttpCodes.NOT_FOUND,
					});
				}
				if (!findUnlockCode) {
					return res.status(HttpCodes.NOT_FOUND).json({
						error: `This UnlockCode ${redeemCode} is not found!`,
						errorCode: HttpCodes.NOT_FOUND,
					});
				}
				if (findUnlockCode.passportId !== passportId) {
					return res.status(HttpCodes.NOT_FOUND).json({
						error: `This RedeemCode ${redeemCode} is not for valid PartyPack`,
						errorCode: HttpCodes.NOT_FOUND,
					});
				}

				if (findUnlockCode.isUnlocked && !findUnlockCode.isActive) {
					return res.status(HttpCodes.NOT_FOUND).json({
						error: `This RedeemCode ${redeemCode} is already Redeemed!`,
						errorCode: HttpCodes.NOT_FOUND,
					});
				}
				findUnlockCode.isActive = false;
				findUnlockCode.isUnlocked = true;
				findUnlockCode.unlockedBy = userId;
				findUnlockCode.username = username;
				findUnlockCode.email = email;
				findUnlockCode.partyPackType = !findPassport.partyPackType
					? 'REGULAR'
					: findPassport.partyPackType;

				findUnlockCode.save();

				const purchasedPassport = {
					findPassport,
					transactionId: redeemCode,
					passportName: findPassport.passportName,
					passportPublisher: findPassport.passportPublisher,
					purchased: true,
					passportDeals: findPassport.passportDeals,
					passportPhoto: findPassport.passportPhoto,
					passportPricing: findPassport.passportPricing,
					active: findPassport.active,
					createDate: findPassport.createDate,
					purchasedDate: new Date().toISOString(),
					isUnlocked: true,
					unlockedDate: new Date().toISOString(),
					expiryDate: findPassport.expiryDate,
				};

				if (!findUser) {
					new User({
						userId: userId,
						passports: purchasedPassport,
					}).save();
				} else {
					findUser.passports.push(purchasedPassport);
					findUser.save();
				}

				const transactionData = {
					user: findUser,
					payment_details: findUnlockCode,
				};

				new Transaction(transactionData).save();

				res.status(HttpCodes.OK).json({
					statusCode: HttpCodes.OK,
					message: 'Transaction is successfully created!',
				});
			} else if (findUser) {
				const findUserPassport = findUser.passports;
				const toModifyPassport = findUserPassport.find(
					(passport) => passport._id.toString() === passportId
				);

				const findPassport = await Passport.findById(passportId);
				if (!findPassport) {
					return res.status(HttpCodes.NOT_FOUND).json({
						error: `This passport_id ${passportId} is not found!`,
						errorCode: HttpCodes.NOT_FOUND,
					});
				}

				if (!findUnlockCode) {
					return res.status(HttpCodes.NOT_FOUND).json({
						error: `This passport_id ${passportId} is not found!`,
						errorCode: HttpCodes.NOT_FOUND,
					});
				}

				if (findUnlockCode.passportId !== passportId) {
					return res.status(HttpCodes.NOT_FOUND).json({
						error: `This RedeemCode ${redeemCode} is not for valid PartyPack`,
						errorCode: HttpCodes.NOT_FOUND,
					});
				}

				if (findUnlockCode.isUnlocked && !findUnlockCode.isActive) {
					return res.status(HttpCodes.NOT_FOUND).json({
						error: `This RedeemCode ${redeemCode} is already Redeemed!`,
						errorCode: HttpCodes.NOT_FOUND,
					});
				}
				findUnlockCode.isActive = false;
				findUnlockCode.isUnlocked = true;
				findUnlockCode.unlockedBy = userId;
				findUnlockCode.username = username;
				findUnlockCode.email = email;
				findUnlockCode.partyPackType = !findPassport.partyPackType
					? 'REGULAR'
					: findPassport.partyPackType;

				findUnlockCode.save();

				if (toModifyPassport) {
					toModifyPassport.isUnlocked = true;
					findUserPassport[
						findUserPassport.findIndex((passportObj) => passportObj._id.toString() === passportId)
					] = toModifyPassport;
					findUser.passports = findUserPassport;
					findUser.save();
				} else {
					const purchasedPassport = {
						findPassport,
						transactionId: redeemCode,
						passportName: findPassport.passportName,
						passportPublisher: findPassport.passportPublisher,
						purchased: true,
						passportDeals: findPassport.passportDeals,
						passportPhoto: findPassport.passportPhoto,
						passportPricing: findPassport.passportPricing,
						active: findPassport.active,
						createDate: findPassport.createDate,
						purchasedDate: findPassport.purchasedDate,
						isUnlocked: true,
						expiryDate: findPassport.expiryDate,
						unlockedDate: new Date().toISOString(),
					};
					findUser.passports.push(purchasedPassport);
					findUser.save();
				}
				const transactionData = {
					user: findUser,
					payment_details: findUnlockCode,
				};

				new Transaction(transactionData).save();

				res.status(HttpCodes.OK).json({
					statusCode: HttpCodes.OK,
					message: 'Transaction is Successfully created!',
				});
			}
		} catch (error) {
			return res.status(HttpCodes.NOT_FOUND).json({
				error: `Something went wrong please try again later. ${error}`,
				errorCode: HttpCodes.NOT_FOUND,
			});
		}
	}

	makeid(length) {
		var result = '';
		const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
		const charactersLength = characters.length;
		for (var i = 0; i < length; i++) {
			result += characters.charAt(Math.floor(Math.random() * charactersLength));
		}
		return result;
	}
}

module.exports = TransactionsController;
