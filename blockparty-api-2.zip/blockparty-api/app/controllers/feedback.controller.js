const HttpCodes = require('http-status-codes');
const Feedback = require('../models/feedback.model');
const User = require('../models/users.model');
const Passport = require('../models/passport.model');

class FeedbackController {
    async addFeedback(req, res) {
        try {
            const {userId, passportId, studentCode, source, transactionId, userName, email} = req.body;
            const findUser = await User.findOne({userId: userId});
            if (!findUser) {
                return res.status(HttpCodes.NOT_FOUND).json({
                    errorCode: HttpCodes.NOT_FOUND,
                    error: `This user_id ${userId} is not found!`,
                });
            }

            const findPassport = await Passport.findOne({_id: passportId})
            if (!findPassport) {
                return res.status(HttpCodes.NOT_FOUND).json({
                    errorCode: HttpCodes.NOT_FOUND,
                    error: `This passport_id ${passportId} is not found!`,
                });
            }

            new Feedback({
                passportId: passportId,
                userId: userId,
                source: source,
                studentCode: studentCode || '',
                transactionId: transactionId,
                userName: userName,
                userEmail: email
            }).save();
            res.status(HttpCodes.OK).json({
                statusCode: HttpCodes.OK,
                message: 'Feedback is Submitted Successfully!'
            })
        } catch (error) {
            return res.status(HttpCodes.NOT_FOUND).json({
                error: `something went wrong please try again later. ${error}`,
                errorCode: HttpCodes.NOT_FOUND
            })
        }
    }
}

module.exports = FeedbackController;
