const HttpCodes = require('http-status-codes');
const Feedback = require('../models/feedback.model');
const User = require('../models/users.model');
const Passport = require('../models/passport.model');
const Redeem = require('../models/analytics.model').redeemDeals;
const QrCode = require('../models/analytics.model').qrCode;
const Codes = require('../models/code.model');
const PassportUser = require('../models/users.model');
const converter = require('json-2-csv');
const fs = require('fs');
var ObjectId = require('mongoose').Types.ObjectId;
const Viewed = require('../models/analytics.model').viewed;

var config = require('../../config/main');

let result = [];
const Pool = require('pg').Pool;
const pool = new Pool({
	user: config.user,
	host: config.host,
	database: config.database,
	password: config.password,
	port: config.pg_port,
});

class ReportController {
	async getHello(req, res) {
		res.status(HttpCodes.OK).json({
			statusCode: HttpCodes.OK,
			message: 'Report Controller is up! Work in progress!',
		});
	}

	async getPsqlUser(user) {
		let response;
		try {
			return await pool.query('SELECT * FROM users WHERE id = $1 OR email = $2 limit 1', [
				user.id,
				user.email,
			]);
		} catch (error) {
			console.log(error.stack);
		}
	}

	async getPassportSales(req, res, reportType) {
		try {
			//const { passportId, isCardSales } = req.body;
			const isCardSales = reportType;
			let matchQuery = '';
			matchQuery = isCardSales
				? { sellerId: { $eq: '' } }
				: { $and: [{ isActive: false }, { sellerId: { $ne: '' } }] };

			console.log('isCardSales: ' + isCardSales);
			console.log('Filter Query :' + matchQuery);
			//FIND ALL SELLER_CODE AS PER MATCHQUERY
			const findSoldCodes = await Codes.aggregate().match(matchQuery).lookup({
				from: 'feedback',
				localField: 'unlockedBy',
				foreignField: 'userId',
				as: 'feedback',
			});

			//CASE: FOUND CODES
			if (findSoldCodes) {
				console.log('findSoldCodes.length: ' + findSoldCodes.length);

				//MODIFY FOR REPORT
				//TO TEST LOCALLY - LIMITS
				findSoldCodes.reverse();
				//findSoldCodes.splice(20, findSoldCodes.length - 10);
				//console.log(findSoldCodes);
				for (const code of findSoldCodes) {
					//if (!code.createDate) code.createDate = code._id.getTimestamp().toISOString();

					code.paymentType = isCardSales ? 'CARD' : 'UNLOCK CODE';
					//IF CARD SALE
					if (isCardSales == 1) {
						code.paymentType = 'CARD';
						if (!code.createDate) code.createDate = code._id.getTimestamp().toISOString();
					}
					//ELSE IT IS A CASH SALE
					else {
						code.paymentType = 'UNLOCK CODE';
						//code.createDate;
						await User.findOne({
							$and: [{ userId: code.unlockedBy }, { 'passports.transactionId': code.unlockCode }],
						}).then((userObj) => {
							if (userObj != null && userObj.passports.length > 0) {
								for (let p of userObj.passports) {
									if (p.transactionId === code.unlockCode) {
										code.createDate = p.unlockedDate;
										break;
									}
								}
							}
						});
					}

					console.log('Generation user..for code ' + code.unlockedBy);
					console.log(code.feedback.length);

					if (code.feedback.length > 0 && code.feedback[0].userId) {
						await this.getPsqlUser({
							id: code.feedback[0].userId,
						}).then((response) => {
							let buyer = response.rows[0];
							if (buyer != undefined) {
								code.userName = buyer.first_name + ' ' + buyer.last_name;
								code.userEmail = buyer.email;
							}
							const getIndex = code.feedback.length - 1;
							code.source = '';
							code.studentCode = '';
							for (const fb of code.feedback) {
								if (fb.source != undefined && fb.source.length > 1)
									code.source = code.source + ' / ' + fb.source;
								if (fb.studentCode != undefined && fb.studentCode.length > 1)
									code.studentCode = code.studentCode + ' / ' + fb.studentCode;
							}
						});
					} else {
						//GET USER BY unlockedBy
						const createdBy = await this.getPsqlUser({
							id: code.unlockedBy,
							email: code.createdByEmail,
						}).then(async (response) => {
							let buyer = response.rows[0];

							if (buyer != undefined) {
								code.userName = buyer.first_name + ' ' + buyer.last_name;
								code.userEmail = buyer.email;

								//GUESS FEEDBACK BY BUYER USER
								console.log('Enter guessing phase....');
								console.log('buyer.id: ' + buyer.id);
								console.log('code.passportId: ' + code.passportId);

								const matchQuery = {
									$and: [{ userId: buyer.id }, { passportId: code.passportId }],
								};
								//FETCH ALL FEEDBACKS FOR THE USER AS PER PASSPORT
								if (isCardSales == 1) {
									await Feedback.aggregate()
										.match(matchQuery)
										.then((feedbacks) => {
											if (feedbacks != null && feedbacks.length > 0) {
												console.log('Guessed feedback for user');
												//CONCAT SOURCE AND CODE
												code.source = '';
												code.studentCode = '';
												for (const fb of feedbacks) {
													if (fb.source != undefined && fb.source.length > 1)
														code.source = code.source + ' / ' + fb.source;
													if (fb.studentCode != undefined && fb.studentCode.length > 1)
														code.studentCode = code.studentCode + ' / ' + fb.studentCode;
												}
											} else {
												console.log('Guessed feedback for user ' + buyer.id + ' failed');
											}
										});
								}
							}
							//NO SOURCE FOUND
							else {
								code.source = 'NO SOURCE PRESENT';
								code.studentCode = 'NO SELLER CODE PRESENT';
							}
						});
					}

					//DELETE UNSUED KEYS
					//code.partyPackType = code.partyPackType === undefined ? 'REGULAR' : code.partyPackType;
					delete code.feedback;
					delete code._class;
					delete code.__v;
					delete code._id;
					delete code.username;
					delete code.email;
					if (isCardSales == 1) {
						delete code.passportSKU;
						delete code.sellerId;
						delete code.sellerName;
						delete code.unlockedBy;
					} else {
						delete code.source;
						delete code.studentCode;
						code.isActive = true;
					}
					console.log('Done...');

					///SET PP TYPE

					const findPassport = await Passport.findById(code.passportId).exec();

					if (findPassport && findPassport.partyPackType) {
						console.log(' FOUND PP');
						code.partyPackType = findPassport.partyPackType;
						code.partyPackName = findPassport.passportName;
						code.partyPackSKU = findPassport.passportPricing.sku;
					} else {
						code.partyPackType = 'REGULAR';
						code.partyPackName = 'DELETED';
					}
				}
				// convert JSON array to CSV string for downloads
				(async () => {
					try {
						const csv = await converter.json2csvAsync(findSoldCodes);
						res.header('Content-Type', 'text/csv');
						isCardSales
							? res.attachment('CreditCardSales' + Date() + '.csv')
							: res.attachment('CashSales' + Date() + '.csv');
						return res.send(csv);
					} catch (err) {
						throw err;
					}
				})();
			}
		} catch (error) {
			console.error(error);
			return res.status(HttpCodes.INTERNAL_SERVER_ERROR).json({
				error: `something went wrong please try again later. ${error}`,
				errorCode: HttpCodes.INTERNAL_SERVER_ERROR,
			});
		}
	}

	async getRedeemDealReport(req, res) {
		try {
			const redeemCodes = await Redeem.find();
			if (redeemCodes) {
				console.log('redeemCodes.length: ' + redeemCodes.length);

				let objs = redeemCodes.map(function (obj) {
					return {
						platform: obj.platform,
						appVersion: obj.appVersion,
						eventType: obj.eventType,
						eventKey: obj.eventKey,
						userName: obj.userName,
						userEmail: obj.userEmail,
						createDate: obj.createDate,
						passportSKU: obj.passportSKU,
						passportName: obj.passportName,
						companyName: obj.companyName,
						partyPackType: !obj.partyPackType ? 'REGULAR' : obj.partyPackType,
						month: obj.month,
						year: obj.year,
						date: obj.date,
						referralCode: obj.referralCode,
					};
				});

				// convert JSON array to CSV string for downloads
				(async () => {
					try {
						const csv = await converter.json2csvAsync(objs);
						console.log('csvv', csv);
						res.header('Content-Type', 'text/csv');
						res.attachment('redeemDeal' + Date() + '.csv');
						return res.send(csv);
					} catch (err) {
						throw err;
					}
				})();
			}
		} catch (error) {
			console.error(error);
			return res.status(HttpCodes.INTERNAL_SERVER_ERROR).json({
				error: `something went wrong please try again later. ${error}`,
				errorCode: HttpCodes.INTERNAL_SERVER_ERROR,
			});
		}
	}

	async getQrCodeReport(req, res) {
		try {
			const qrCodes = await QrCode.find();
			if (qrCodes) {
				console.log('qrCodes.length: ' + qrCodes.length);
				let objs = qrCodes.map(function (obj) {
					return {
						userName: obj.name,
						userEmail: obj.email,
						passportName: obj.passportName,
						qrCode: obj.qrCode,
						passportSKU: obj.passportSku,
						date: new Date(obj._id.getTimestamp()).getDate(),
						month: new Date(obj._id.getTimestamp()).getMonth() + 1,
						year: new Date(obj._id.getTimestamp()).getFullYear(),
						createDate: new Date(obj._id.getTimestamp()),
					};
				});

				// convert JSON array to CSV string for downloads
				(async () => {
					try {
						const csv = await converter.json2csvAsync(objs);
						console.log('csvv', csv);
						res.header('Content-Type', 'text/csv');
						res.attachment('qrCode' + Date() + '.csv');
						return res.send(csv);
					} catch (err) {
						throw err;
					}
				})();
			} else {
				return res.status(HttpCodes.NOT_FOUND).json({
					error: `There is no QR codes added`,
					errorCode: HttpCodes.NOT_FOUND,
				});
			}
		} catch (error) {
			console.log(error);
			return res.status(HttpCodes.INTERNAL_SERVER_ERROR).json({
				error: `something went wrong please try again later. ${error}`,
				errorCode: HttpCodes.INTERNAL_SERVER_ERROR,
			});
		}
	}

	checkJson(jsonData) {
		for (let key in jsonData) {
			if (
				jsonData[key].hasOwnProperty('CompanyName') ||
				jsonData[key].hasOwnProperty('email') ||
				jsonData[key].hasOwnProperty('dealType') ||
				jsonData[key].hasOwnProperty('source')
			) {
				// console.log("property");
				// result.push(jsonData[key]);
				var data = {
					DealTitle: jsonData[key]['DealTitle'],
					CompanyName: jsonData[key]['CompanyName'],
					dealType: jsonData[key]['dealType'],
					Date: jsonData[key]['Date'] == undefined ? 'N/A' : jsonData[key]['Date'],
					Month: jsonData[key]['Month'] == undefined ? 'N/A' : jsonData[key]['Month'],
					Year: jsonData[key]['Year'] == undefined ? 'N/A' : jsonData[key]['Year'],
					email: jsonData[key]['email'] == undefined ? 'N/A' : jsonData[key]['email'],
					source: jsonData[key]['source'] == undefined ? 'N/A' : jsonData[key]['source'],
					referralCode:
						jsonData[key]['referralCode'] == undefined ? 'N/A' : jsonData[key]['referralCode'],
				};

				result.push(data);
			} else {
				this.checkJson(jsonData[key]);
			}
		}
	}

	async sendRealtimeData(req, res) {
		// console.log('Got body:',  req.files[0].buffer, );
		var buffer = req.files[0].buffer;
		result = [];
		try {
			var jsonData = JSON.parse(buffer);
			this.checkJson(jsonData);

			var csvData = await converter.json2csvAsync(result, (err, csv) => {
				if (err) {
					res.status(HttpCodes.NOT_FOUND).json({
						error: `Something went wrong please try again later000. ${error}}`,
						errorCode: HttpCodes.NOT_FOUND,
					});
				}
			});

			res.header('Content-Type', 'text/csv');
			res.attachment('realtimeDeals' + Date() + '.csv');
			return res.send(csvData);

			// res.header('Content-Type', 'text/csv');
			// res.status(HttpCodes.OK).send(csvData);
			// res.status(HttpCodes.NOT_FOUND).json(jsonData);
		} catch (error) {
			res.status(HttpCodes.NOT_FOUND).json({
				error: `Something went wrong please try again later999. ${error}}`,
				errorCode: HttpCodes.NOT_FOUND,
			});
		}
	}

	async getViewedDealsReport(_req, res) {
		try {
			const viewedDeals = await Viewed.find();
			if (viewedDeals) {
				let objs = viewedDeals.map(function (obj) {
					return {
						platform: obj.platform,
						appVersion: obj.appVersion,
						eventType: obj.eventType,
						eventKey: obj.eventKey,
						userName: obj.userName,
						userEmail: obj.userEmail,
						createDate: obj.createDate,
						passportSKU: obj.passportSKU,
						passportName: obj.passportName,
						companyName: obj.companyName,
						partyPackType: obj.partyPackType,
						month: obj.month,
						year: obj.year,
						date: obj.date,
						referralCode: obj.referralCode,
					};
				});

				// convert JSON array to CSV string for downloads
				(async () => {
					try {
						const csv = await converter.json2csvAsync(objs);
						res.header('Content-Type', 'text/csv');
						res.attachment('viewedDeals' + Date() + '.csv');
						return res.send(csv);
					} catch (err) {
						throw err;
					}
				})();
			}
		} catch (error) {
			console.error(error);
			return res.status(HttpCodes.INTERNAL_SERVER_ERROR).json({
				error: `something went wrong please try again later. ${error}`,
				errorCode: HttpCodes.INTERNAL_SERVER_ERROR,
			});
		}
	}
}

module.exports = ReportController;
