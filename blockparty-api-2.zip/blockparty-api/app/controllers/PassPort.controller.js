const HttpCodes = require('http-status-codes');
const Passport = require('../models/passport.model');
const User = require('../models/users.model');
const Code = require('../models/code.model');
const DealRedeem = require('../models/deal.redeem.model');
const QrCodeAnalytics = require('../models/analytics.model').qrCode;
const config = require('../../config/main');
const icons = {
	Automotive:
		'https://blockpartyinc-photos.s3.us-east-2.amazonaws.com/category-icons/Automotive.png',
	Dining: 'https://blockpartyinc-photos.s3.us-east-2.amazonaws.com/category-icons/Dining.png',
	Entertainment:
		'https://blockpartyinc-photos.s3.us-east-2.amazonaws.com/category-icons/Entertainment.png',
	Other: 'https://blockpartyinc-photos.s3.us-east-2.amazonaws.com/category-icons/Other.png',
	Retail: 'https://blockpartyinc-photos.s3.us-east-2.amazonaws.com/category-icons/Retail.png',
	'Business Services':
		'https://blockpartyinc-photos.s3.us-east-2.amazonaws.com/category-icons/Business+Services.png',
	'Downtown Parker':
		' https://blockpartyinc-photos.s3.us-east-2.amazonaws.com/category-icons/Downtown+Parker.png',
	'Garden & Landscape':
		'https://blockpartyinc-photos.s3.us-east-2.amazonaws.com/category-icons/Garden+and+Landscape.png',
	'Health & Beauty':
		'https://blockpartyinc-photos.s3.us-east-2.amazonaws.com/category-icons/Health+and+Beauty.png',
	'Healthcare Services':
		'https://blockpartyinc-photos.s3.us-east-2.amazonaws.com/category-icons/Healthcare+Services.png',
	'Home Improvement': 'https://blockpartyinc-photos.s3.us-east-2.amazonaws.com/Home.png',
	'Hotels & Travel':
		'https://blockpartyinc-photos.s3.us-east-2.amazonaws.com/category-icons/Hotels+and+Travel.png',
	'Kids & Family':
		'https://blockpartyinc-photos.s3.us-east-2.amazonaws.com/category-icons/Kids+and+Family.png',
	'Moving Services':
		'https://blockpartyinc-photos.s3.us-east-2.amazonaws.com/category-icons/Moving+Services.png',
	'Parties & Events':
		'https://blockpartyinc-photos.s3.us-east-2.amazonaws.com/category-icons/Parties+and+Events.png',
	'Parties and Events':
		'https://blockpartyinc-photos.s3.us-east-2.amazonaws.com/category-icons/Parties+and+Events.png',
	'Pet Services':
		'https://blockpartyinc-photos.s3.us-east-2.amazonaws.com/category-icons/Pet+Services.png',
	'Professional Services':
		'https://blockpartyinc-photos.s3.us-east-2.amazonaws.com/category-icons/Professional+Services.png',
	'Seasonal-Other':
		'https://blockpartyinc-photos.s3.us-east-2.amazonaws.com/category-icons/Seasonal-Other.png',
	'Sports & Activities':
		'https://blockpartyinc-photos.s3.us-east-2.amazonaws.com/category-icons/Sports+and+Activities.png',
};
const Pool = require('pg').Pool;
const pool = new Pool({
	user: config.user,
	host: config.host,
	database: config.database,
	password: config.password,
	port: config.pg_port,
});

class PassPortController {
	async getPassportList(req, res) {
		const userId = req.query.userId;
		const location = req.query.location;

		console.log(`userId ${userId}`);
		try {
			const findUser = await User.findOne({ userId: userId });
			let passportList;
			let findPassport;
			if (location !== '' && location !== undefined) {
				passportList = await Passport.find()
					.or([{ location: { $regex: '.*' + location + '.*' } }, { location: '' }])
					.and([{ partyPackType: { $ne: 'QR' } }])
					.exec();
			} else {
				passportList = await Passport.find()
					.and([{ partyPackType: { $ne: 'QR' } }])
					.exec();
			}
			let passportsListWithPurchasedKey = [];
			let todayDate = new Date();

			passportList.forEach((list) => {
				list.icons = icons;
			});

			for (let i = 0; i < passportList.length; i++) {
				if (
					(passportList[i].expiryDate != null &&
						new Date(passportList[i].expiryDate) < todayDate) ||
					!passportList[i].active
				) {
					console.log(passportList[i].expiryDate);
					delete passportList[i];
				}
			}

			var filteredPassPortListPartyPacks = passportList.filter(function (el) {
				return el != null;
			});
			passportList = filteredPassPortListPartyPacks;

			if (!findUser) {
				passportsListWithPurchasedKey.push(passportList);
				return res.status(HttpCodes.OK).json({
					statusCode: HttpCodes.OK,
					data: passportsListWithPurchasedKey,
				});
			}
			let userPassportList = findUser.passports.reverse();
			userPassportList.forEach((user) => {
				user.icons = icons;
			});
			for (let j = 0; j < userPassportList.length; j++) {
				if (
					userPassportList[j].expiryDate != null &&
					new Date(userPassportList[j].expiryDate) < todayDate
				) {
					delete userPassportList[j];
				}
			}

			var filteredPassPortList = userPassportList.filter(function (el) {
				return el != null;
			});

			userPassportList = filteredPassPortList;
			passportsListWithPurchasedKey.push(passportList);
			passportsListWithPurchasedKey.push(userPassportList);
			return res.status(HttpCodes.OK).json({
				statusCode: HttpCodes.OK,
				data: passportsListWithPurchasedKey,
			});
		} catch (error) {
			console.log(error);
			return res.status(HttpCodes.NOT_FOUND).json({
				error: `something went wrong please try again later. ${error}`,
				errorCode: HttpCodes.NOT_FOUND,
			});
		}
	}

	//getPartyPack
	async getPartyPack(req, res) {
		const { userId } = req.params;
		console.log(`userId in partyPACK` + userId);
		try {
			// * find user by id
			const findUser = await User.findOne({ userId: userId });
			let passportsListWithPurchasedKey = [];
			// * user not found
			if (!findUser) {
				return res.status(HttpCodes.NOT_FOUND).json({
					error: `User not found. ${error}`,
					errorCode: HttpCodes.NOT_FOUND,
				});
			}

			// get all the passports
			const userPassportList = findUser.passports.reverse();
			passportsListWithPurchasedKey.push(userPassportList);
			console.log('##### user found: ' + passportsListWithPurchasedKey);
			return res.status(HttpCodes.OK).json({
				statusCode: HttpCodes.OK,
				data: passportsListWithPurchasedKey,
			});
		} catch (error) {
			return res.status(HttpCodes.NOT_FOUND).json({
				error: `something went wrong please try again later. ${error}`,
				errorCode: HttpCodes.NOT_FOUND,
			});
		}
	}

	async getPassportById(req, res) {
		const id = req.params.id;
		console.log(`passport-id ${id}`);
		try {
			const passportObj = await Passport.find({ _id: id });
			if (!passportObj) {
				return res.status(HttpCodes.NOT_FOUND).json({
					error: `This passport_id ${id} is not found!`,
					errorCode: HttpCodes.NOT_FOUND,
				});
			} else {
				return res.status(HttpCodes.OK).json({
					status: 'success',
					data: passportObj,
				});
			}
		} catch (error) {
			return res.status(HttpCodes.NOT_FOUND).json({
				error: `Something went wrong please try again later. ${error}`,
				errorCode: HttpCodes.NOT_FOUND,
			});
		}
	}

	// Validate QA Code
	async validateQRCode(req, res) {
		const qrCode = req.query.qrcode;
		const qrActive = true;
		console.log(req.query.qrcode);
		try {
			const qrCodeObject = await Code.find({ unlockCode: qrCode, isActive: qrActive });
			if (qrCodeObject.length == 0) {
				return res.status(HttpCodes.NOT_FOUND).json({
					status: 'Not Found',
					error: 'Code has already been used or is invalid.',
					valid: false,
				});
			} else {
				return res.status(HttpCodes.OK).json({
					status: 'Success',
					msg: 'Valid QR code',
					valid: true,
				});
			}
		} catch (error) {
			return res.status(HttpCodes.NOT_FOUND).json({
				error: `Something went wrong please try again later. ${error}`,
				errorCode: HttpCodes.NOT_FOUND,
			});
		}
	}

	// redeem
	async redeem(req, res) {
		const { passportId, userId, dealId } = req.body;
		try {
			const findUser = await User.findOne({ userId: userId });
			if (!findUser) {
				return this.returnError(res, `This user_id ${userId} is not found!`);
			}
			const passportArray = findUser.passports;
			const passportsObj = passportArray.find((passport) => passport._id.toString() === passportId);
			if (!passportsObj) {
				return this.returnError(res, `This passportId ${passportId} is not found!`);
			}

			const dealsArray = passportsObj.passportDeals;
			const dealsObj = dealsArray.find((deals) => deals._id.toString() === dealId);
			if (!dealsObj) {
				return this.returnError(res, `This dealId ${dealId} is not found!`);
			}

			const createBy = await this.getPsqlUser({
				id: userId,
			}).then(async (response) => {
				let user = response.rows[0];
				new DealRedeem({
					passportId: passportsObj._id,
					passportSKU: passportsObj.passportPricing.sku,
					dealId: dealsObj._id,
					dealName: dealsObj.title,
					userId: userId,
					userName: user.first_name + ' ' + user.last_name,
					userEmail: user.email,
					createDate: new Date().toISOString(),
					eventType: 'DEAL_REDEEM',
					parentPassportId: passportId,
				}).save();
			});

			if (dealsObj.isMultipleRedeem) {
				dealsObj.toObject().redeemCount = dealsObj.redeemCount++;
				dealsObj.toObject().redeemStatus = true;
				this.saveUserPassport(
					dealsArray,
					dealId,
					dealsObj,
					findUser,
					passportArray,
					passportId,
					passportsObj
				);
				return this.dealSaved(res, dealsObj);
			} else {
				if (dealsObj.redeemStatus) {
					return this.returnError(res, 'This deal has already been redeemed.');
				} else {
					dealsObj.redeemStatus = true;
					this.saveUserPassport(
						dealsArray,
						dealId,
						dealsObj,
						findUser,
						passportArray,
						passportId,
						passportsObj
					);
					return this.dealSaved(res, dealsObj);
				}
			}
		} catch (error) {
			return this.returnError(res, `Something went wrong please try again later. ${error}`);
		}
	}

	saveUserPassport(
		dealsArray,
		dealId,
		dealsObj,
		findUser,
		passportArray,
		passportId,
		passportsObj
	) {
		dealsArray[dealsArray.findIndex((dealObj) => dealObj._id.toString() === dealId)] = dealsObj;
		findUser.passports.passportDeals = dealsArray;
		passportArray[
			passportArray.findIndex((passportObj) => passportObj._id.toString() === passportId)
		] = passportsObj;
		findUser.passports = passportArray;
		findUser.save();
	}

	dealSaved(res, findDeals) {
		return res.status(HttpCodes.OK).json({
			statusCode: HttpCodes.OK,
			data: findDeals,
		});
	}

	returnError(res, errorMessage) {
		return res.status(HttpCodes.NOT_FOUND).json({
			errorCode: HttpCodes.NOT_FOUND,
			errorMessage: errorMessage,
		});
	}

	async getPsqlUser(user) {
		let response;
		try {
			return await pool.query('SELECT * FROM users WHERE id = $1 OR email = $2 limit 1', [
				user.id,
				user.email,
			]);
		} catch (error) {
			console.log(error.stack);
		}
	}

	// Check QR code
	async checkQrCode(req, res) {
		try {
			const { userId, unlockCode } = req.body;
			// const qrCode = unlockCode
			// * 1 Find the Database code.
			const findCode = await Code.findOne({ unlockCode, isActive: true, isUnlocked: false }).exec();

			// * 2 Return a message if code not found
			if (findCode === null) {
				return res.status(HttpCodes.NOT_FOUND).json({
					status: 'Not Found',
					error: 'Code has already been used or is invalid.',
					valid: false,
				});
			}

			// * 3 Check QR code expiration.
			// return res.status(HttpCodes.NOT_FOUND).json({
			// 	errorCode: HttpCodes.NOT_ACCEPTABLE,
			// 	errorMessage: `This '${unlockCode}' QR code is expired.`,
			// });

			// * 4 If code found: Find database code passport with deals
			else {
				const findPassport = await Passport.findById(findCode.passportId).exec();
				findPassport.qrCode = unlockCode;

				// await Passport.update({ activeDays: 60, expiryDate: '' });

				// * 5 Check passport expiration.
				const { expiryDate, activeDays } = findPassport;
				let userPassportExpiryDate;

				//console.log(expiryDate+ "--"+ activeDays);
				if (!expiryDate || expiryDate === 'null' || expiryDate === null) {
					const date = new Date();
					const addDays = date.setDate(date.getDate() + activeDays);
					userPassportExpiryDate = new Date(addDays).toDateString();
				} else {
					const expiry = new Date(expiryDate);
					userPassportExpiryDate = new Date(findPassport.expiryDate);
					const now = new Date();
					if (now.toISOString() > expiry.toISOString()) {
						return res.status(HttpCodes.NOT_FOUND).json({
							errorCode: HttpCodes.NOT_ACCEPTABLE,
							errorMessage: `This '${unlockCode}' QR code is expired.`,
						});
						return res.json(findUser);
					}
				}

				//#region // * 6 Add passport to the givin user email.
				let findUser;
				let verifyUser = false;
				findUser = await User.findOne({ userId });
				if (findUser !== null) {
					// * 1 If user found Add passport to the user
					await findUser.passports.push({
						passportName: findPassport.passportName,
						passportPublisher: findPassport.passportPublisher,
						purchased: true,
						passportDeals: findPassport.passportDeals,
						passportPhoto: findPassport.passportPhoto,
						passportPricing: findPassport.passportPricing,
						active: findPassport.active,
						createDate: findPassport.createDate,
						purchasedDate: findPassport.purchasedDate,
						isUnlocked: findPassport.isUnlocked,
						qrCode: findPassport.qrCode,
						expiryDate: findPassport.expiryDate,
						icons: icons,
						location: findPassport.location,
						partyPackType: findPassport.partyPackType,
						activeDays,
					});
					await findUser.save();
				} else {
					// * 2 if user not found: Create new user with givin PG userId with adding passport to the user
					findUser = await User.create({
						userId,
						passports: [
							{
								passportName: findPassport.passportName,
								passportPublisher: findPassport.passportPublisher,
								purchased: true,
								passportDeals: findPassport.passportDeals,
								passportPhoto: findPassport.passportPhoto,
								passportPricing: findPassport.passportPricing,
								active: findPassport.active,
								createDate: findPassport.createDate,
								purchasedDate: findPassport.purchasedDate,
								isUnlocked: findPassport.isUnlocked,
								qrCode: findPassport.qrCode,
								expiryDate: findPassport.expiryDate,
								icons: icons,
								activeDays,
							},
						],
					});
				}

				if (findUser) {
					let buyer = await pool.query(
						'SELECT * FROM users WHERE id = $1',
						[findUser.userId],
						(error, results) => {
							let analyticsQrCode = QrCodeAnalytics.create({
								name: results.rows[0].first_name + ' ' + results.rows[0].last_name,
								email: results.rows[0].email,
								passportName: findPassport.passportName,
								passportSku: findPassport.passportPricing.sku,
								qrCode: findPassport.qrCode,
								date: new Date().getDate(),
								createDate: new Date(),
								month: new Date().getMonth() + 1,
								year: new Date().getFullYear(),
							});
						}
					);

					//
					/*Set the QR Code as inactive and unlocked*/
					const updatedCode = await Code.update(
						{ _id: findCode._id },
						{ isActive: false, isUnlocked: true, unlockedBy: findUser.userId }
					);

					return res.status(HttpCodes.OK).json({
						status: 'Success',
						msg: 'Valid QR code',
						valid: true,
					});
					//
				}
			}
		} catch (error) {
			console.log(error);
			return res.status(HttpCodes.NOT_FOUND).json({
				errorCode: HttpCodes.BAD_REQUEST,
				errorMessage: 'Something went wrong. Please try again!',
			});
		}
	}

	// Check QR code
	async purchasedList(req, res) {
		try {
			const { userId } = req.params;
			// * 4 If code found: Find database code passport with deals
			const findUser = await User.findOne({ userId }).exec();
			const passports = findUser.passports;
			const passportFilter = [];
			passports.forEach((passport) => {
				if (passport.expiryDate) {
					const expiry = new Date(passport.expiryDate);
					const now = new Date();
					if (expiry.toISOString() > now.toISOString()) {
						return passportFilter.push(passport);
					}
				}
			});

			// * 7 return success respond
			return res.status(HttpCodes.OK).json({
				statusCode: HttpCodes.OK,
				data: passportFilter,
			});
		} catch (error) {
			console.error('Error found in QR code checking', error);
			return res.status(HttpCodes.NOT_FOUND).json({
				errorCode: HttpCodes.BAD_REQUEST,
				errorMessage: error,
			});
		}
	}
}

module.exports = PassPortController;
