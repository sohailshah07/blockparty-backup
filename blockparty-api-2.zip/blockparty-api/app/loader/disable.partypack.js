class DisablePartypack{
   static disableByName(passportName){
        db.users.find().forEach(function (doc) {
            doc.passports.forEach(function (p) {
                if(p.passportName == passportName){
                    p.active = false;
                }
            });
            db.users.save(doc);
        });
    }
    //actual mongo script.....

    /*db.users.find().forEach(function (doc) {
        doc.passports.forEach(function (p) {
            if(p.passportName == "2020 Castle View High School Football Sabercat Card"){
                p.active = false;
            }
        });
        db.users.save(doc);
    });*/
}