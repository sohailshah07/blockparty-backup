const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const feedback = new Schema({
    passportId: {type: String},
    userId: {type: String},
    source: {type: String},
    studentCode: {type: String},
    transactionId: {type: String},
    userName: {type: String},
    userEmail: {type: String}
});

const Feedback = mongoose.model('feedback', feedback, 'feedback');

module.exports = Feedback;
