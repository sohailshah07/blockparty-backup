const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const code = new Schema({
	passportId: { type: String },
	passportSKU: { type: String },
	unlockCode: { type: String },
	isActive: { type: Boolean },
	sellerId: { type: String },
	sellerName: { type: String },
	isUnlocked: { type: Boolean },
	partyPackType: { type: String },
	unlockedBy: { type: String },
	username: { type: String },
	email: { type: String },
	createdByEmail: { type: String },
	createdByUserName: { type: String },
	createDate: { type: Date },
	createdByUserId: { type: String },
});

const Codes = mongoose.model('seller_code', code, 'seller_code');

module.exports = Codes;
