const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const analytics = new Schema({
	platform: { type: String },
	appVersion: { type: String },
	eventType: { type: String },
	eventKey: { type: String },
	passportId: { type: String },
	userId: { type: String },
	userName: { type: String },
	userEmail: { type: String },
	createDate: { type: Date, default: new Date() },
	passportSKU: { type: String },
	parentPassportId: { type: String },
	passportName: { type: String },
	partyPackType: { type: String },
	companyName: { type: String },
	referralCode: { type: String },
	date: { type: Number, default: new Date().getDate() },
	month: { type: Number, default: new Date().getMonth() + 1 },
	year: { type: Number, default: new Date().getFullYear() },
});

const users = new Schema({
	name: { type: String },
	email: { type: String },
	passportName: { type: String },
	passportSku: { type: String },
	createDate: { type: Date, default: new Date() },
	qrCode: { type: String },
	date: { type: String, default: new Date().getUTCDate() },
	month: { type: String, default: new Date().getUTCMonth() + 1 },
	year: { type: String, default: new Date().getUTCFullYear() },
});

let redeemDeals = mongoose.model('analytics_redeem_deals', analytics, 'analytics_redeem_deals');
let buttonTap = mongoose.model('analytics_button_tap', analytics, 'analytics_button_tap');
let transaction = mongoose.model('analytics_transaction', analytics, 'analytics_transaction');
let unlock = mongoose.model('analytics_unlock', analytics, 'analytics_unlock');
let viewed = mongoose.model('analytics_viewed', analytics, 'analytics_viewed');
let qrCode = mongoose.model('analytics_qr_code', users, 'analytics_qr_code');

module.exports = {
	redeemDeals: redeemDeals,
	buttonTap: buttonTap,
	transaction: transaction,
	unlock: unlock,
	viewed: viewed,
	qrCode: qrCode,
};
