const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const seller = new Schema({
	name: { type: String },
	email: { type: String },
	phone: { type: String },
	address: { type: String },
	state: { type: String },
	zip: { type: String },
	passportCode: [
		{
			passportId: { type: String },
			passportSKU: { type: String },
			unlockCode: { type: String },
			isActive: { type: Boolean },
		},
	],
});

const Seller = mongoose.model('sellers', seller, 'sellers');

module.exports = Seller;
