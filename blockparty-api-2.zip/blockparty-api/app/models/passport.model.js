const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const passport = new Schema({
	passportName: { type: String },
	partyPackType: { type: String },
	purchased: { type: Boolean },
	active: { type: Boolean },
	shortcutStatus: { type: Boolean },
	createDate: { type: Number },
	location: { type: String },
	isUnlocked: { type: Boolean },
	expiryDate: { type: Date },
	activeDays: { type: Number },
	icons: { type: Object },
	passportPhoto: {
		url: { type: String },
		subtext: { type: String },
		thumbnailUrl: { type: String },
		type: { type: String },
	},
	passportPricing: {
		amount: { type: Number },
		currency: { type: String },
		sku: { type: String },
	},
	passportPublisher: {
		publisherName: { type: String },
		email: { type: String },
		phone: { type: String },
		websiteUrl: { type: String },
		zip: { type: String },
		cityName: { type: String },
		state: { type: String },
	},
	passportDeals: [
		{
			category: { type: String },
			details: { type: String },
			title: { type: String },
			redeemCode: { type: String },
			passportDealsPhoto: { type: String },
			photo1: [
				{
					url: { type: String },
					subtext: { type: String },
					thumbnailUrl: { type: String },
					type: { type: String },
				},
			],
			photo7: [
				{
					url: { type: String },
					subtext: { type: String },
					thumbnailUrl: { type: String },
					type: { type: String },
				},
			],
			photo11: [
				{
					url: { type: String },
					subtext: { type: String },
					thumbnailUrl: { type: String },
					type: { type: String },
				},
			],
			isMultipleRedeem: { type: Boolean },
			redeemStatus: { type: Boolean },
			isUnlocked: { type: Boolean },
			expiryDate: { type: Date },
			redeemCount: { type: Number },
			dealBuiness: {
				bussinessName: { type: String },
				address: { type: String },
				email: { type: String },
				phone: { type: String },
				websiteUrl: { type: String },
				zip: { type: String },
				cityName: { type: String },
				state: { type: String },
			},
		},
	],
});

const Passport = mongoose.model('passport', passport, 'passport');

module.exports = Passport;
