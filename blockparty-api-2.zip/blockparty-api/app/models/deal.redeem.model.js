const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const dealData = new Schema({
	passportId: { type: String },
	passportSKU: { type: String },
	dealId: { type: String },
	dealName: { type: String },
	userId: { type: String },
	userName: { type: String },
	userEmail: { type: String },
	createDate: { type: Date, default: new Date() },
	eventType: { type: String },
	parentPassportId: { type: String },
	companyName: { type: String },
	date: { type: Number, default: new Date().getDate() },
	month: { type: Number, default: new Date().getMonth() + 1 },
	year: { type: Number, default: new Date().getFullYear() },
	referralCode: { type: String },
});

const DealData = mongoose.model('analytics_deal_redeem', dealData, 'analytics_deal_redeem');

module.exports = DealData;
