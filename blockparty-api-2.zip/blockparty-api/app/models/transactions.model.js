const mongoose = require('mongoose');

const Schema = mongoose.Schema;
var transactions = new Schema({
        user: {
            type: Schema.Types.ObjectId,
            ref: 'User',
        },
        payment_details: Object,
    },
    {timestamps: true}
);

const Transaction = mongoose.model('Transaction', transactions, "transactions");

module.exports = Transaction;
