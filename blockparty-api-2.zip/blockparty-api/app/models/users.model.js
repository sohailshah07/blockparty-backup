const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const users = new Schema({
	userId: { type: String },
	passports: [
		{
			transactionId: { type: String },
			passportName: { type: String },
			purchased: { type: Boolean },
			qrCode: { type: String },
	        location: { type: String },
        	partyPackType: { type: String },
			active: { type: Boolean },
			createDate: { type: Number },
			isUnlocked: { type: Boolean },
			purchasedDate: { type: Date },
			unlockedDate: { type: Date },
			expiryDate: { type: Date },
			activeDays: { type: Number },
			icons : { type : Object
			},
			passportPhoto: {
				url: { type: String },
				subtext: { type: String },
				thumbnailUrl: { type: String },
				type: { type: String },
			},
			passportPricing: {
				amount: { type: Number },
				currency: { type: String },
				sku: { type: String },
			},
			passportPublisher: {
				publisherName: { type: String },
				email: { type: String },
				phone: { type: String },
				websiteUrl: { type: String },
				zip: { type: String },
				cityName: { type: String },
				state: { type: String },
			},
			passportDeals: [
				{
					category: { type: String },
					details: { type: String },
					title: { type: String },
					redeemCode: { type: String },
					passportDealsPhoto: { type: String },
					photo1: [
						{
							url: { type: String },
							subtext: { type: String },
							thumbnailUrl: { type: String },
							type: { type: String },
						},
					],
					photo7: [
						{
							url: { type: String },
							subtext: { type: String },
							thumbnailUrl: { type: String },
							type: { type: String },
						},
					],
					photo11: [
						{
							url: { type: String },
							subtext: { type: String },
							thumbnailUrl: { type: String },
							type: { type: String },
						},
					],
					isMultipleRedeem: { type: Boolean },
					redeemStatus: { type: Boolean },
			        expiryDate : {type: Date},
					redeemCount: { type: Number },
					dealBuiness: {
						bussinessName: { type: String },
						address: { type: String },
						Name: { type: String },
						email: { type: String },
						phone: { type: String },
						websiteUrl: { type: String },
						zip: { type: String },
						cityName: { type: String },
						state: { type: String },
					},
				},
			],
		},
	],
});

const User = mongoose.model('users', users, 'users');

module.exports = User;
