"use strict";
var crypt = require("../crypt");
var config = require("../../config/main");
var db = {};
const uuidv1 = require("uuid/v1");


const Pool = require("pg").Pool;
const pool = new Pool({
    user: config.user,
    host: config.host,
    database: config.database,
    password: config.password,
    port: config.pg_port
});
var moment = require("moment-timezone");
const {response} = require("express");

function dateData() {
    var today = new Date().getDay().toLocaleString("en-US", {
        timeZone: "America/Denver"
    });
    if (today == 0) var presentDay = "schedule.sunday";
    if (today == 1) var presentDay = "schedule.monday";
    if (today == 2) var presentDay = "schedule.tuesday";
    if (today == 3) var presentDay = "schedule.wednesday";
    if (today == 4) var presentDay = "schedule.thursday";
    if (today == 5) var presentDay = "schedule.friday";
    if (today == 6) var presentDay = "schedule.saturday";

    return presentDay;
}

function currentData() {
    var d = new Date(),
    month = "" + (d.getMonth() + 1),
    day = "" + d.getDate(),
    year = d.getFullYear();

if (month.length < 2) month = "0" + month;
if (day.length < 2) day = "0" + day;

return [year, month, day].join("-");
}

function formatDate(date) {
    var d = new Date(date),
        month = "" + (d.getMonth() + 1),
        day = "" + d.getDate(),
        year = d.getFullYear();

    if (month.length < 2) month = "0" + month;
    if (day.length < 2) day = "0" + day;

    return [year, month, day].join("-");
}

pool.query("SELECT * FROM users", (error, result) => {
    if (result) console.log("Connected to PG");
    else console.log("Connection error : " + error);
});


// find deals
db.findDeals = function (city, successCallback, failureCallback) {
    var date = dateData();
    var setquery =
        'SELECT deals.id,deals.pinned,deals.details,deals.url,deals.title,deals.expiry_date,deals.create_date, business.lat,deals.business_id,business.long,business.phone,'
        + 'business.website_url,business.address_line1,business.zip,business.email, business.description, city.city, city.state,json_object(array_agg(photos.type),'
        + 'array_agg(photos.photo)) AS "photo",array_to_string(array_agg( distinct photos."type"),\',\')  AS "type"'
        + ',array_to_string(array_agg(distinct business.name),\',\') AS "name",deals.redeem_code,array_to_string(array_agg(distinct open_hours.day),\',\')  AS "day", '
        + 'array_agg(distinct  open_hours.day || \':\' || open_hours.hours) As "hour", '
        + 'deals.redeems_allowed, redeems.redeem_count as user_redeem_count,redeems.user_id '
        + 'FROM city INNER JOIN neighbourhood ON (city.id = neighbourhood.city_id) '
        + 'INNER JOIN business ON (neighbourhood.id = business.neighbourhood_id) '
        + 'INNER JOIN deals ON (deals.business_id = business.id ) '
        + 'INNER JOIN deb_photos ON (deb_photos.deals_id=deals."id") '
        + 'INNER JOIN photos ON (photos."id" = deb_photos.photo_id) '
        + 'INNER JOIN open_hours ON (open_hours.business_id=business.id) '
        + 'INNER JOIN schedule ON (schedule.deal_id = deals.id) '
        + 'left outer JOIN redeems ON (redeems.deal_id = deals.id and redeems.user_id=$3) '
        + 'WHERE (city.city = $1 AND deals.pinned = 0 AND deals.is_feature = $2 AND ' + + "GROUP BY deals.id,deals.pinned,deals.details,deals.url,deals.title,deals.expiry_date, business.lat,business.long,business.phone,business.website_url,business.address_line1,business.zip, business.email, business.description, city.city, city.state,deals.create_date, redeems.user_id,redeems.redeem_count ORDER BY RANDOM()";
    pool.query(
        setquery,
        [city["city"], city["is_featured"], city['user_id']],
        (error, results) => {
            console.log(results);
            if (error) successCallback([]);
            else{
                results.rows.forEach(function (item, index) {
                    results.rows[index].hours = [];
                    results.rows[index].hour.forEach(function (time, i) {
                        results.rows[index].createDate = moment(
                            results.rows[index].create_date
                        ).format("MM/DD/YYYY");
                        if (results.rows[index].hour.length > 6) {
                            results.rows[index].hours[0] = results.rows[index].hour[1];
                            results.rows[index].hours[1] = results.rows[index].hour[5];
                            results.rows[index].hours[2] = results.rows[index].hour[6];
                            results.rows[index].hours[3] = results.rows[index].hour[4];
                            results.rows[index].hours[4] = results.rows[index].hour[0];
                            results.rows[index].hours[5] = results.rows[index].hour[2];
                            results.rows[index].hours[6] = results.rows[index].hour[3];

                            if (
                                results.rows[index].hours[0] == "Monday:By appointment" &&
                                results.rows[index].hours[1] == "Tuesday:By appointment" &&
                                results.rows[index].hours[2] == "Wednesday:By appointment" &&
                                results.rows[index].hours[3] == "Thursday:By appointment"
                            ) {
                                results.rows[index].hours = [];
                                results.rows[index].hours[0] = "By appointment";
                            }

                            if (
                                results.rows[index].hours[0] ==
                                "Monday:Opening in October 2019" &&
                                results.rows[index].hours[1] ==
                                "Tuesday:Opening in October 2019" &&
                                results.rows[index].hours[2] ==
                                "Wednesday:Opening in October 2019" &&
                                results.rows[index].hours[3] == "Thursday:Opening in October 2019"
                            ) {
                                results.rows[index].hours = [];
                                results.rows[index].hours[0] = "Opening in October 2019";
                            }

                            if (
                                results.rows[index].hours[0] == "Monday:24/7" &&
                                results.rows[index].hours[1] == "Tuesday:24/7" &&
                                results.rows[index].hours[2] == "Wednesday:24/7"
                            ) {
                                results.rows[index].hours = [];

                                results.rows[index].hours[0] = "24/7";
                            }
                        } else {
                            if (
                                results.rows[index].hour[0] == "Class: Times and By Appointment."
                            )
                                results.rows[index].hours[0] = "Class: Times and By Appointment.";
                            if (results.rows[index].hour[0] == "Private: Events & Parties")
                                results.rows[index].hours[0] = "Private: Events & Parties";
                            if (results.rows[index].hour[0] == "Private: Events & Parties")
                                results.rows[index].hours[0] = "Private: Events & Parties";
                            if (results.rows[index].hour[0] == "By: Appointment")
                                results.rows[index].hours[0] = "By: Appointment";
                            if (results.rows[index].hour[0] == "24: hours")
                                results.rows[index].hours[0] = "24: hours";

                            for (var hr = 0; hr < results.rows[index].hour.length; hr++) {
                                if (results.rows[index].hour[hr].includes("Monday")) {
                                    results.rows[index].hours[0] = results.rows[index].hour[hr];
                                } else if (results.rows[index].hour[hr].includes("Tuesday")) {
                                    results.rows[index].hours[1] = results.rows[index].hour[hr];
                                } else if (results.rows[index].hour[hr].includes("Wednesday")) {
                                    results.rows[index].hours[2] = results.rows[index].hour[hr];
                                } else if (results.rows[index].hour[hr].includes("Thursday")) {
                                    results.rows[index].hours[3] = results.rows[index].hour[hr];
                                } else if (results.rows[index].hour[hr].includes("Friday")) {
                                    results.rows[index].hours[4] = results.rows[index].hour[hr];
                                } else if (results.rows[index].hour[hr].includes("Saturday")) {
                                    results.rows[index].hours[5] = results.rows[index].hour[hr];
                                } else if (results.rows[index].hour[hr].includes("Sunday")) {
                                    results.rows[index].hours[6] = results.rows[index].hour[hr];
                                }
                            }
                        }
                    });
                    results.rows[index].hours = results.rows[index].hours.filter(
                        v => v != null
                    );
                });
                successCallback(results.rows);
            }

        }
    );
};

db.findDealsSpecial = function (city, successCallback, failureCallback) {
    var date = dateData();
    var currentDate = currentData();
    var displayDateRange = currentDate + ' 00:00:00'
    var setquery =
    'SELECT deals.id,deals.pinned,deals.details,deals.url,deals.business_id,deals.title,deals.expiry_date,business.lat,business.long,business.phone,business.website_url,business.address_line1,business.zip,business.email, business.description, business.city_name AS "city",business.state, json_object(array_agg(photos.type),array_agg(photos.photo)) AS "photo",array_to_string(array_agg( distinct photos."type"),\',\')  AS "type",array_to_string(array_agg(distinct business.name),\',\') AS "name",deals.redeem_code,array_to_string(array_agg(distinct open_hours.day),\',\')  AS "day",array_agg(distinct open_hours.day || \':\' || open_hours.hours) As "hour" ,deals.redeems_allowed, redeems.redeem_count as user_redeem_count,redeems.user_id FROM city INNER JOIN neighbourhood ON (city.id = neighbourhood.city_id) INNER JOIN business ON (neighbourhood.id = business.neighbourhood_id) INNER JOIN deals ON (deals.business_id = business.id ) INNER JOIN deb_photos ON (deb_photos.deals_id=deals."id") INNER JOIN photos ON (photos."id" = deb_photos.photo_id) INNER JOIN open_hours ON (open_hours.business_id=business.id) INNER JOIN schedule ON (schedule.deal_id = deals.id) left outer JOIN redeems ON (redeems.deal_id = deals.id and redeems.user_id=$3) WHERE (city.city = $1 AND deals.pinned = 0 AND deals.is_feature = $2 AND deals.is_today = $2 AND deals.today_deal_startdate <= $4 AND deals.today_deal_enddate   >= $4)' +
    "GROUP BY  deals.id,deals.pinned,deals.details,deals.url,deals.business_id,deals.title,deals.expiry_date, business.lat,business.long,business.phone,business.website_url,business.address_line1,business.zip,business.email , business.description, business.city_name, business.state,deals.create_date, redeems.user_id,redeems.redeem_count  UNION ALL SELECT deals.id,deals.pinned,deals.details,deals.url,deals.business_id,deals.title,deals.expiry_date,business.lat,business.long,business.phone,business.website_url,business.address_line1,business.zip,business.email, business.description, business.city_name AS \"city\",business.state, json_object(array_agg(photos.type),array_agg(photos.photo)) AS \"photo\",array_to_string(array_agg( distinct photos.\"type\"),',')  AS \"type\",array_to_string(array_agg(distinct business.name),',') AS \"name\",deals.redeem_code,array_to_string(array_agg(distinct open_hours.day),',')  AS \"day\",array_agg(distinct open_hours.day || ':' || open_hours.hours) As \"hour\" ,deals.redeems_allowed, redeems.redeem_count as user_redeem_count,redeems.user_id FROM city INNER JOIN neighbourhood ON (city.id = neighbourhood.city_id) INNER JOIN business ON (neighbourhood.id = business.neighbourhood_id) INNER JOIN deals ON (deals.business_id = business.id ) INNER JOIN business_cities ON (business.id=business_cities.business_id) INNER JOIN deb_photos ON (deb_photos.deals_id=deals.\"id\") INNER JOIN photos ON (photos.\"id\" = deb_photos.photo_id) INNER JOIN open_hours ON (open_hours.business_id=business.id) INNER JOIN schedule ON (schedule.deal_id = deals.id) left outer JOIN redeems ON (redeems.deal_id = deals.id and redeems.user_id=$3) WHERE (business_cities.additional_location=$1 AND deals.pinned = 0  AND deals.is_feature = $2 AND deals.is_today = $2 AND deals.today_deal_startdate <= $4 AND deals.today_deal_enddate >= $4) " +
    "GROUP BY  deals.id,deals.pinned,deals.details,deals.url,deals.business_id,deals.title,deals.expiry_date, business.lat,business.long,business.phone,business.website_url,business.address_line1,business.zip,business.email , business.description, business.city_name, business.state,deals.create_date,business_cities.additional_location, redeems.user_id,redeems.redeem_count";

    // "SELECT deals.id,deals.details,deals.url,deals.title,deals.expiry_date,deals.create_date, business.lat,deals.business_id," +
    //     "business.long,business.phone,business.website_url,business.address_line1,business.zip,business.email, business.description, city.city," +
    //     ' city.state,json_object(array_agg(photos.type),array_agg(photos.photo)) AS "photo",array_to_string(array_agg( distinct photos."type"),\',\')  AS "type",' +
    //     "array_to_string(array_agg(distinct business.name),',') AS \"name\",deals.redeem_code,array_to_string(array_agg(distinct open_hours.day),',')  AS \"day\"" +
    //     ", array_agg(distinct  open_hours.day || ':' || open_hours.hours) As \"hour\" ,deals.redeems_allowed, redeems.redeem_count as user_redeem_count,redeems.user_id FROM city INNER JOIN neighbourhood ON (city.id = neighbourhood.city_id) " +
    //     "INNER JOIN business ON (neighbourhood.id = business.neighbourhood_id) INNER JOIN deals ON (deals.business_id = business.id ) " +
    //     'INNER JOIN deb_photos ON (deb_photos.deals_id=deals."id") INNER JOIN photos ON (photos."id" = deb_photos.photo_id) ' +
    //     "INNER JOIN open_hours ON (open_hours.business_id=business.id) INNER JOIN schedule ON (schedule.deal_id = deals.id) " +
    //     "left outer JOIN redeems ON (redeems.deal_id = deals.id and redeems.user_id=$5) " +
    //     "WHERE ((city.city = $1 )  AND deals.is_feature = $2 AND " +
    //     date +
    //     "= $3 AND deals.is_today=$2 AND today_deal_startdate <= $4::date AND    today_deal_enddate   >= $4::date) " +
    //     "GROUP BY deals.id,deals.details,deals.url,deals.title,deals.expiry_date, business.lat,business.long,business.phone,business.website_url," +
    //     "business.address_line1,business.zip, business.email, business.description, city.city, city.state,deals.create_date,deals.redeems_allowed,redeems.redeem_count,redeems.user_id" +
    //     " ORDER BY deals.create_date DESC";

    pool.query(
        setquery,
        [city["city"], city["is_featured"], city["user_id"],displayDateRange],
        (error, results) => {
            results.rows.forEach(function (item, index) {
                results.rows[index].hours = [];
                results.rows[index].hour.forEach(function (time, i) {
                    results.rows[index].createDate = moment(
                        results.rows[index].create_date
                    ).format("MM/DD/YYYY");
                    if (results.rows[index].hour.length > 6) {
                        results.rows[index].hours[0] = results.rows[index].hour[1];
                        results.rows[index].hours[1] = results.rows[index].hour[5];
                        results.rows[index].hours[2] = results.rows[index].hour[6];
                        results.rows[index].hours[3] = results.rows[index].hour[4];
                        results.rows[index].hours[4] = results.rows[index].hour[0];
                        results.rows[index].hours[5] = results.rows[index].hour[2];
                        results.rows[index].hours[6] = results.rows[index].hour[3];

                        if (
                            results.rows[index].hours[0] == "Monday:By appointment" &&
                            results.rows[index].hours[1] == "Tuesday:By appointment" &&
                            results.rows[index].hours[2] == "Wednesday:By appointment" &&
                            results.rows[index].hours[3] == "Thursday:By appointment"
                        ) {
                            results.rows[index].hours = [];
                            results.rows[index].hours[0] = "By appointment";
                        }

                        if (
                            results.rows[index].hours[0] ==
                            "Monday:Opening in October 2019" &&
                            results.rows[index].hours[1] ==
                            "Tuesday:Opening in October 2019" &&
                            results.rows[index].hours[2] ==
                            "Wednesday:Opening in October 2019" &&
                            results.rows[index].hours[3] == "Thursday:Opening in October 2019"
                        ) {
                            results.rows[index].hours = [];
                            results.rows[index].hours[0] = "Opening in October 2019";
                        }

                        if (
                            results.rows[index].hours[0] == "Monday:24/7" &&
                            results.rows[index].hours[1] == "Tuesday:24/7" &&
                            results.rows[index].hours[2] == "Wednesday:24/7"
                        ) {
                            results.rows[index].hours = [];

                            results.rows[index].hours[0] = "24/7";
                        }
                    } else {
                        if (
                            results.rows[index].hour[0] == "Class: Times and By Appointment."
                        )
                            results.rows[index].hours[0] = "Class: Times and By Appointment.";
                        if (results.rows[index].hour[0] == "Private: Events & Parties")
                            results.rows[index].hours[0] = "Private: Events & Parties";
                        if (results.rows[index].hour[0] == "Private: Events & Parties")
                            results.rows[index].hours[0] = "Private: Events & Parties";
                        if (results.rows[index].hour[0] == "By: Appointment")
                            results.rows[index].hours[0] = "By: Appointment";
                        if (results.rows[index].hour[0] == "24: hours")
                            results.rows[index].hours[0] = "24: hours";

                        for (var hr = 0; hr < results.rows[index].hour.length; hr++) {
                            if (results.rows[index].hour[hr].includes("Monday")) {
                                results.rows[index].hours[0] = results.rows[index].hour[hr];
                            } else if (results.rows[index].hour[hr].includes("Tuesday")) {
                                results.rows[index].hours[1] = results.rows[index].hour[hr];
                            } else if (results.rows[index].hour[hr].includes("Wednesday")) {
                                results.rows[index].hours[2] = results.rows[index].hour[hr];
                            } else if (results.rows[index].hour[hr].includes("Thursday")) {
                                results.rows[index].hours[3] = results.rows[index].hour[hr];
                            } else if (results.rows[index].hour[hr].includes("Friday")) {
                                results.rows[index].hours[4] = results.rows[index].hour[hr];
                            } else if (results.rows[index].hour[hr].includes("Saturday")) {
                                results.rows[index].hours[5] = results.rows[index].hour[hr];
                            } else if (results.rows[index].hour[hr].includes("Sunday")) {
                                results.rows[index].hours[6] = results.rows[index].hour[hr];
                            }
                        }
                    }
                });
                results.rows[index].hours = results.rows[index].hours.filter(
                    v => v != null
                );
            });

            if (error) failureCallback(error);
            else successCallback(results.rows);
        }
    );
};

db.findSavedDealsbyid = function (user, successCallback, failureCallback) {
    pool.query(
        'SELECT deals.id, user_deals.pinned,user_deals.id as "user_deal_id", user_deals.is_archive,deals.business_id, deals.details, deals.url, deals.title,deals.expiry_date,business.lat,business.long,business.phone,business.website_url,business.address_line1,business.zip,business.email, business.description,city.city, city.state,json_object(array_agg(photos.type),array_agg(photos.photo)) AS "photo",array_to_string(array_agg( distinct photos."type"),\',\')  AS "type",array_to_string(array_agg(distinct business.name),\',\') AS "name",deals.redeem_code,array_to_string(array_agg(distinct open_hours.day),\',\')  AS "day",array_agg(distinct open_hours.day || \':\' || open_hours.hours) As "hour" FROM user_deals INNER JOIN deals ON (user_deals.deal_id = deals.id) INNER JOIN business ON (deals.business_id = business.id) INNER JOIN deb_photos ON (deb_photos.deals_id=deals."id") INNER JOIN photos ON (photos."id" = deb_photos.photo_id) INNER JOIN open_hours ON (open_hours.business_id=business.id)  INNER JOIN  neighbourhood ON (neighbourhood.id = business.neighbourhood_id)  INNER JOIN  city ON (neighbourhood.city_id = city.id) WHERE (user_deals.user_id = $1 AND user_deals.deal_id  NOT IN (select deal_id from redeems WHERE redeems.user_id = $1)) GROUP BY  deals.id,user_deals.pinned, user_deals.id, user_deals.is_archive, deals.details,deals.url,city.city, city.state,deals.title,deals.expiry_date, business.lat,business.long,business.phone,business.website_url,business.address_line1,business.zip,business.email, business.description,deals.create_date ORDER BY deals.create_date DESC',
        [user["user_id"]],
        (error, results) => {

            //filter only non-archived saved deal....
            if(results.rows != null)
            results.rows = results.rows.filter(v => v.is_archive === 0);

            if(results.rows != null)
            results.rows.forEach(function (item, index) {
                console.error(item.id);
                results.rows[index].hours = [];
                results.rows[index].hour.forEach(function (time, i) {
                    if (results.rows[index].hour.length < 2) {
                        results.rows[index].hours[0] = results.rows[index].hour[0];
                    }
                    if (results.rows[index].hour.length > 6) {
                        results.rows[index].hours[0] = results.rows[index].hour[1];
                        results.rows[index].hours[1] = results.rows[index].hour[5];
                        results.rows[index].hours[2] = results.rows[index].hour[6];
                        results.rows[index].hours[3] = results.rows[index].hour[4];
                        results.rows[index].hours[4] = results.rows[index].hour[0];
                        results.rows[index].hours[5] = results.rows[index].hour[2];
                        results.rows[index].hours[6] = results.rows[index].hour[3];

                        if (
                            results.rows[index].hours[0] == "Monday:By appointment" &&
                            results.rows[index].hours[1] == "Tuesday:By appointment" &&
                            results.rows[index].hours[2] == "Wednesday:By appointment" &&
                            results.rows[index].hours[3] == "Thursday:By appointment"
                        ) {
                            results.rows[index].hours = [];
                            results.rows[index].hours[0] = "By appointment";
                        }

                        if (
                            results.rows[index].hours[0] ==
                            "Monday:Opening in October 2019" &&
                            results.rows[index].hours[1] ==
                            "Tuesday:Opening in October 2019" &&
                            results.rows[index].hours[2] ==
                            "Wednesday:Opening in October 2019" &&
                            results.rows[index].hours[3] == "Thursday:Opening in October 2019"
                        ) {
                            results.rows[index].hours = [];
                            results.rows[index].hours[0] = "Opening in October 2019";
                        }

                        if (
                            results.rows[index].hours[0] == "Monday:24/7" &&
                            results.rows[index].hours[1] == "Tuesday:24/7" &&
                            results.rows[index].hours[2] == "Wednesday:24/7"
                        ) {
                            results.rows[index].hours = [];

                            results.rows[index].hours[0] = "24/7";
                        }
                    } else {
                        for (var hr = 0; hr < results.rows[index].hour.length; hr++) {
                            if (results.rows[index].hour[hr].includes("Monday")) {
                                results.rows[index].hours[0] = results.rows[index].hour[hr];
                            } else if (results.rows[index].hour[hr].includes("Tuesday")) {
                                results.rows[index].hours[1] = results.rows[index].hour[hr];
                            } else if (results.rows[index].hour[hr].includes("Wednesday")) {
                                results.rows[index].hours[2] = results.rows[index].hour[hr];
                            } else if (results.rows[index].hour[hr].includes("Thursday")) {
                                results.rows[index].hours[3] = results.rows[index].hour[hr];
                            } else if (results.rows[index].hour[hr].includes("Friday")) {
                                results.rows[index].hours[4] = results.rows[index].hour[hr];
                            } else if (results.rows[index].hour[hr].includes("Saturday")) {
                                results.rows[index].hours[5] = results.rows[index].hour[hr];
                            } else if (results.rows[index].hour[hr].includes("Sunday")) {
                                results.rows[index].hours[6] = results.rows[index].hour[hr];
                            }
                        }
                    }
                });
                results.rows[index].hours = results.rows[index].hours.filter(
                    v => v != null
                );
            });
			let todayDate = new Date();

            for (let j = 0; j < results.rows.length; j++) {
				if (
					results.rows[j].expiry_date != null &&
					new Date(results.rows[j].expiry_date) < todayDate
				) {
					delete results.rows[j];
				}
			}

			var filteredSavedDeals = results.rows.filter(function (el) {
				return el != null;
			});

			results.rows = filteredSavedDeals;


            if (error) {
                failureCallback(error);
            } else successCallback(results.rows);
        }
    );
};


db.findRedeembyid = function (user, successCallback, failureCallback) {
    pool.query(
        'SELECT deals.id,redeems.is_archive, redeems.id AS \"user_redeem_id\", deals.business_id,deals.details,deals.url,deals.redeems_allowed,redeems.redeem_count AS user_redeem_count,deals.title,deals.expiry_date,business.lat,'
        + 'business.long,business.phone,business.website_url,business.address_line1,business.zip,business.email, business.description,city.city, city.state,'
        + 'json_object(array_agg(photos.type),array_agg(photos.photo)) AS "photo",array_to_string(array_agg( distinct photos."type"),\',\')  AS "type",'
        + 'array_to_string(array_agg(distinct business.name),\',\') AS "name",array_to_string(array_agg(distinct open_hours.day),\',\')  AS "day",'
        + 'array_agg(distinct open_hours.day || \':\' || open_hours.hours) As "hour",redeems.redeem_code '
        + 'FROM redeems INNER JOIN deals ON (redeems.deal_id = deals.id) '
        + 'INNER JOIN business ON (deals.business_id = business.id)  '
        + 'INNER JOIN deb_photos ON (deb_photos.deals_id=deals."id") '
        + 'INNER JOIN photos ON (photos."id" = deb_photos.photo_id) '
        + 'INNER JOIN open_hours ON (open_hours.business_id=business.id)  '
        + 'INNER JOIN  neighbourhood ON (neighbourhood.id = business.neighbourhood_id)  '
        + 'INNER JOIN  city ON (neighbourhood.city_id = city.id) '
        + 'WHERE (redeems.user_id = $1 ) '
        + 'GROUP BY  deals.id, redeems.is_archive, redeems.id, deals.details,deals.url,city.city, city.state,deals.title,deals.expiry_date, business.lat,business.long,business.phone,business.website_url,'
        + 'business.address_line1,business.zip,business.email, business.description,deals.create_date,redeems.redeem_code, redeems.redeem_count ORDER BY deals.create_date DESC',
        [user["user_id"]],
        (error, results) => {
            //filter only non-archived saved redeem....
            if(results.rows != null)
                results.rows = results.rows.filter(v => v.is_archive === 0);

            if(results.rows != null)
            results.rows.forEach(function (item, index) {
                results.rows[index].hours = [];
                results.rows[index].hour.forEach(function (time, i) {
                    if (results.rows[index].hour.length < 2) {
                        results.rows[index].hours[0] = results.rows[index].hour[0];
                    }
                    if (results.rows[index].hour.length > 6) {
                        results.rows[index].hours[0] = results.rows[index].hour[1];
                        results.rows[index].hours[1] = results.rows[index].hour[5];
                        results.rows[index].hours[2] = results.rows[index].hour[6];
                        results.rows[index].hours[3] = results.rows[index].hour[4];
                        results.rows[index].hours[4] = results.rows[index].hour[0];
                        results.rows[index].hours[5] = results.rows[index].hour[2];
                        results.rows[index].hours[6] = results.rows[index].hour[3];

                        if (
                            results.rows[index].hours[0] == "Monday:By appointment" &&
                            results.rows[index].hours[1] == "Tuesday:By appointment" &&
                            results.rows[index].hours[2] == "Wednesday:By appointment" &&
                            results.rows[index].hours[3] == "Thursday:By appointment"
                        ) {
                            results.rows[index].hours = [];
                            results.rows[index].hours[0] = "By appointment";
                        }

                        if (
                            results.rows[index].hours[0] ==
                            "Monday:Opening in October 2019" &&
                            results.rows[index].hours[1] ==
                            "Tuesday:Opening in October 2019" &&
                            results.rows[index].hours[2] ==
                            "Wednesday:Opening in October 2019" &&
                            results.rows[index].hours[3] == "Thursday:Opening in October 2019"
                        ) {
                            results.rows[index].hours = [];
                            results.rows[index].hours[0] = "Opening in October 2019";
                        }

                        if (
                            results.rows[index].hours[0] == "Monday:24/7" &&
                            results.rows[index].hours[1] == "Tuesday:24/7" &&
                            results.rows[index].hours[2] == "Wednesday:24/7"
                        ) {
                            results.rows[index].hours = [];

                            results.rows[index].hours[0] = "24/7";
                        }
                    } else {
                        for (var hr = 0; hr < results.rows[index].hour.length; hr++) {
                            if (results.rows[index].hour[hr].includes("Monday")) {
                                results.rows[index].hours[0] = results.rows[index].hour[hr];
                            } else if (results.rows[index].hour[hr].includes("Tuesday")) {
                                results.rows[index].hours[1] = results.rows[index].hour[hr];
                            } else if (results.rows[index].hour[hr].includes("Wednesday")) {
                                results.rows[index].hours[2] = results.rows[index].hour[hr];
                            } else if (results.rows[index].hour[hr].includes("Thursday")) {
                                results.rows[index].hours[3] = results.rows[index].hour[hr];
                            } else if (results.rows[index].hour[hr].includes("Friday")) {
                                results.rows[index].hours[4] = results.rows[index].hour[hr];
                            } else if (results.rows[index].hour[hr].includes("Saturday")) {
                                results.rows[index].hours[5] = results.rows[index].hour[hr];
                            } else if (results.rows[index].hour[hr].includes("Sunday")) {
                                results.rows[index].hours[6] = results.rows[index].hour[hr];
                            }
                        }
                    }
                });
                results.rows[index].hours = results.rows[index].hours.filter(
                    v => v != null
                );
            });
            if (error) {
                failureCallback(error);
            } else successCallback(results.rows);
        }
    );
};

//save deals
db.saveDeals = function (data, successCallback, failureCallback) {
    const id = uuidv1("");

    pool.query(
        "INSERT INTO user_deals(id, user_id, deal_id) VALUES ($1, $2, $3) ",
        [id, data.user_id, data.deals_id],
        (error, results) => {
            if (error) {
                failureCallback(error);
            } else {
                successCallback("success");
            }
        }
    );
};

//archive saved-offers & deals
db.deleteSavedOffers = function (data, successCallback, failureCallback) {
    const userId = data.user_id;
    const offerId = data.offer_id;
    console.log('user-id '+userId);
    console.log('offer-id '+offerId);
    console.log('updating saved offer archive....');

    const findSavedOffersQuery = 'SELECT * FROM user_deals where id = $1';
    pool.query(findSavedOffersQuery,[offerId], (error, response) => {
        if (error) {
            console.log('error to fetch savedOffers');
            failureCallback(error);
        } else {
            console.log('successfully fetched offers');
            if(response.rows.length === 0){
                failureCallback('Invalid offer id.');
            }else{
                const archiveOfferQuery = 'UPDATE user_deals SET is_archive = 1 where id = $1';
                pool.query(archiveOfferQuery,[offerId], (err, res) => {
                    if (err) {
                        console.log('error to archive savedOffer');
                        failureCallback(error);
                    } else {
                        console.log('successfully update offer');
                        console.log(res);
                        successCallback('offer successfully archived.');
                    }
                })
            }
        }
    });

};

db.deleteRedeems = function (data, successCallback, failureCallback) {
    const userId = data.user_id;
    const redeemId = data.redeem_id;
    console.log('user-id '+userId);
    console.log('redeem-id '+redeemId);
    console.log('updating saved redeem archive....');

    const findSavedRedeemQuery = 'SELECT * FROM redeems where id = $1';
    pool.query(findSavedRedeemQuery,[redeemId], (error, response) => {
        if (error) {
            console.log('error to fetch savedRedeems');
            failureCallback(error);
        } else {
            console.log('successfully fetched redeems');
            if(response.rows.length === 0){
                failureCallback('Invalid redeem id.');
            }else{
                const archiveRedeemQuery = 'UPDATE redeems SET is_archive = 1 where id = $1';
                pool.query(archiveRedeemQuery,[redeemId], (err, res) => {
                    if (err) {
                        console.log('error to archive savedRedeem');
                        failureCallback(error);
                    } else {
                        console.log('successfully update redeem');
                        console.log(res);
                        successCallback('redeem successfully archived.');
                    }
                })
            }
        }
    });

};

//simpleDeals

db.simpleDeals = function (city, successCallback, failureCallback) {
    var date = dateData();
    var setquery =
        'SELECT deals.id,deals.pinned,deals.details,deals.url,deals.title,deals.expiry_date,business.lat,business.long,business.phone,business.website_url,business.address_line1,business.zip,business.email, business.description, city.city, city.state, json_object(array_agg(photos.type),array_agg(photos.photo)) AS "photo",array_to_string(array_agg( distinct photos."type"),\',\')  AS "type",array_to_string(array_agg(distinct business.name),\',\') AS "name",deals.redeem_code,array_to_string(array_agg(distinct open_hours.day),\',\')  AS "day",array_agg(distinct open_hours.day || \':\' || open_hours.hours) As "hour" FROM city INNER JOIN neighbourhood ON (city.id = neighbourhood.city_id) INNER JOIN business ON (neighbourhood.id = business.neighbourhood_id) INNER JOIN deals ON (deals.business_id = business.id ) INNER JOIN deb_photos ON (deb_photos.deals_id=deals."id") INNER JOIN photos ON (photos."id" = deb_photos.photo_id) INNER JOIN open_hours ON (open_hours.business_id=business.id) INNER JOIN schedule ON (schedule.deal_id = deals.id) WHERE (city.city = $1 AND deals.is_feature = $2 AND deals.is_feature = $2 AND deals.pinned = 0)' +
        "GROUP BY  deals.id,deals.pinned,deals.details,deals.url,deals.title,deals.expiry_date, business.lat,business.long,business.phone,business.website_url,business.address_line1,business.zip,business.email , business.description, city.city, city.state,deals.create_date ORDER BY RANDOM()";
    pool.query(
        setquery,
        [city["city"], city["is_featured"]],
        (error, results) => {
            if (!error) {
                results.rows.forEach(function (item, index) {
                    results.rows[index].hours = [];
                    results.rows[index].hour.forEach(function (time, i) {
                        if (results.rows[index].hour.length > 6) {
                            results.rows[index].hours[0] = results.rows[index].hour[1];
                            results.rows[index].hours[1] = results.rows[index].hour[5];
                            results.rows[index].hours[2] = results.rows[index].hour[6];
                            results.rows[index].hours[3] = results.rows[index].hour[4];
                            results.rows[index].hours[4] = results.rows[index].hour[0];
                            results.rows[index].hours[5] = results.rows[index].hour[2];
                            results.rows[index].hours[6] = results.rows[index].hour[3];

                            if (
                                results.rows[index].hours[0] == "Monday:By appointment" &&
                                results.rows[index].hours[1] == "Tuesday:By appointment" &&
                                results.rows[index].hours[2] == "Wednesday:By appointment" &&
                                results.rows[index].hours[3] == "Thursday:By appointment"
                            ) {
                                results.rows[index].hours = [];
                                results.rows[index].hours[0] = "By appointment";
                            }

                            if (
                                results.rows[index].hours[0] ==
                                "Monday:Opening in October 2019" &&
                                results.rows[index].hours[1] ==
                                "Tuesday:Opening in October 2019" &&
                                results.rows[index].hours[2] ==
                                "Wednesday:Opening in October 2019" &&
                                results.rows[index].hours[3] ==
                                "Thursday:Opening in October 2019"
                            ) {
                                results.rows[index].hours = [];
                                results.rows[index].hours[0] = "Opening in October 2019";
                            }

                            if (
                                results.rows[index].hours[0] == "Monday:24/7" &&
                                results.rows[index].hours[1] == "Tuesday:24/7" &&
                                results.rows[index].hours[2] == "Wednesday:24/7"
                            ) {
                                results.rows[index].hours = [];

                                results.rows[index].hours[0] = "24/7";
                            }
                        } else {
                            for (var hr = 0; hr < results.rows[index].hour.length; hr++) {
                                if (results.rows[index].hour[hr].includes("Monday")) {
                                    results.rows[index].hours[0] = results.rows[index].hour[hr];
                                } else if (results.rows[index].hour[hr].includes("Tuesday")) {
                                    results.rows[index].hours[1] = results.rows[index].hour[hr];
                                } else if (results.rows[index].hour[hr].includes("Wednesday")) {
                                    results.rows[index].hours[2] = results.rows[index].hour[hr];
                                } else if (results.rows[index].hour[hr].includes("Thursday")) {
                                    results.rows[index].hours[3] = results.rows[index].hour[hr];
                                } else if (results.rows[index].hour[hr].includes("Friday")) {
                                    results.rows[index].hours[4] = results.rows[index].hour[hr];
                                } else if (results.rows[index].hour[hr].includes("Saturday")) {
                                    results.rows[index].hours[5] = results.rows[index].hour[hr];
                                } else if (results.rows[index].hour[hr].includes("Sunday")) {
                                    results.rows[index].hours[6] = results.rows[index].hour[hr];
                                }
                            }
                        }
                    });
                    results.rows[index].hours = results.rows[index].hours.filter(
                        v => v != null
                    );
                });
            }
            if (error) failureCallback(error);
            else successCallback(results.rows);
        }
    );
};

db.locationDeals = function (city, successCallback, failureCallback) {
    var date = dateData();
    //// TODO:  need to update below logic for separating isfeature true and false data once requirement comes
    var isFetaure = (city.is_featured != undefined && city.is_featured.toUpperCase() === "TRUE") ? true : false;
    var queryLimit = isFetaure ? "limit 0" : "";

    pool.query(
        "SELECT lat, lng FROM city WHERE city ILIKE $1",
        [city.city],
        (error, results) => {
            if (error) {
                failureCallback(error);
            } else if (results.rowCount > 0) {

                var firstPart = 'select deals.id ,deals.pinned,deals.details,deals.title,deals.url,business.description, deals.business_id, deals.expiry_date, business.lat,'
                    + ' business.long,business.phone, business.website_url,business.address_line1, business.zip, business.city_name AS "city", business.state, '
                    + 'array_to_string(array_agg(distinct business.name),\',\') AS "name",array_to_string(array_agg(distinct open_hours.day),\',\')  AS "day",'
                    + 'array_agg(distinct open_hours.day || \':\' || open_hours.hours) As "hour",array_to_string(array_agg(distinct photos."type"),\',\' ) AS "type",'
                    + 'json_object(array_agg(photos.type),array_agg(photos.photo)) AS "photo",deals.redeem_code,deals.create_date, '
                    + 'deals.redeems_allowed, redeems.redeem_count as user_redeem_count,redeems.user_id '
                    + 'from deals inner join business  on (deals.business_id = business.id) '
                    + 'inner join  neighbourhood  on (business.neighbourhood_id=neighbourhood."id") '
                    + 'inner join city  on (neighbourhood.city_id=city."id") '
                    + 'inner join open_hours on (open_hours.business_id=business.id) '
                    + 'inner join deb_photos on (deals.id=deb_photos.deals_id) '
                    + 'inner join photos on (deb_photos.photo_id= photos.id) '
                    + 'INNER JOIN schedule ON (schedule.deal_id = deals.id) '
                    + 'left outer JOIN redeems ON (redeems.deal_id = deals.id and redeems.user_id=$4) '
                    + 'WHERE   (ST_DWithin(business.geom,ST_SetSrid(ST_Point($1,$2),4326),10) AND city.city = $3 AND deals.pinned = 0)' +
                    'GROUP BY  deals.id,deals.pinned,deals.details,deals.url,deals.title,deals.expiry_date,deals.business_id, deals.expiry_date, business.lat,business.long,business.phone,business.website_url,business.address_line1,business.zip,business.email,business.description, business.city_name , business.state,deals.create_date, redeems.user_id,redeems.redeem_count ' + queryLimit;

                var secondPart =
                    ' select * from ( (' + firstPart + ' )'
                    + 'UNION ALL '
                    + '(select deals.id,deals.pinned,deals.details,deals.title,deals.url,business.description, deals.business_id, deals.expiry_date, business.lat, business.long,business.phone, '
                    + 'business.website_url,business.address_line1, business.zip, business.city_name AS "city", business.state, '
                    + 'array_to_string(array_agg(distinct business.name),\',\') AS "name",array_to_string(array_agg(distinct open_hours.day),\',\')  AS "day",'
                    + 'array_agg(distinct open_hours.day || \':\' || open_hours.hours) As "hour",array_to_string(array_agg(distinct photos."type"),\',\' ) AS "type",'
                    + 'json_object(array_agg(photos.type),array_agg(photos.photo)) AS "photo",deals.redeem_code,deals.create_date, '
                    + 'deals.redeems_allowed, redeems.redeem_count as user_redeem_count,redeems.user_id '
                    + 'from deals inner join business  on (deals.business_id = business.id) '
                    + 'inner join business_cities on (business.id=business_cities.business_id)  '
                    + 'inner join open_hours on (open_hours.business_id=business.id) '
                    + 'inner join deb_photos on (deals.id=deb_photos.deals_id) '
                    + 'inner join photos on (deb_photos.photo_id= photos.id) '
                    + 'INNER JOIN schedule ON (schedule.deal_id = deals.id) '
                    + 'left outer JOIN redeems ON (redeems.deal_id = deals.id and redeems.user_id=$4) '
                    + 'WHERE business_cities.additional_location=$3 AND deals.pinned = 0'+
                    "GROUP BY  deals.id,deals.pinned,deals.details,deals.url,deals.title,deals.expiry_date,deals.business_id, deals.expiry_date, business.lat,business.long,business.phone,business.website_url,business.address_line1,business.zip,business.email,business.description, business.city_name , business.state,deals.create_date,business.city_name, redeems.user_id,redeems.redeem_count) ) tt ORDER BY RANDOM()";

                var setquery = isFetaure ? firstPart : secondPart;

                pool.query(
                    setquery,
                    [
                        results.rows[0].lat,
                        results.rows[0].lng,
                        city.city,
                        city.user_id
                    ],
                    (error, results) => {
                        if (error) {
                            failureCallback("Data not found.");
                        }

                        var arr = [],
                            resarr = [];

                        results.rows.forEach(function (item, index) {
                            if (!arr.includes(results.rows[index].name.toLowerCase())) {
                                resarr.push(results.rows[index]);
                                arr.push(results.rows[index].name.toLowerCase());
                            }
                            results.rows[index].hours = [];
                            results.rows[index].hour.forEach(function (time, i) {
                                if (results.rows[index].hour.length < 2) {
                                    results.rows[index].hours[0] = results.rows[index].hour[0];
                                }
                                if (results.rows[index].hour.length > 6) {
                                    results.rows[index].hours[0] = results.rows[index].hour[1];
                                    results.rows[index].hours[1] = results.rows[index].hour[5];
                                    results.rows[index].hours[2] = results.rows[index].hour[6];
                                    results.rows[index].hours[3] = results.rows[index].hour[4];
                                    results.rows[index].hours[4] = results.rows[index].hour[0];
                                    results.rows[index].hours[5] = results.rows[index].hour[2];
                                    results.rows[index].hours[6] = results.rows[index].hour[3];

                                    if (
                                        results.rows[index].hours[0] == "Monday:By appointment" &&
                                        results.rows[index].hours[1] == "Tuesday:By appointment" &&
                                        results.rows[index].hours[2] ==
                                        "Wednesday:By appointment" &&
                                        results.rows[index].hours[3] == "Thursday:By appointment"
                                    ) {
                                        results.rows[index].hours = [];
                                        results.rows[index].hours[0] = "By appointment";
                                    }

                                    if (
                                        results.rows[index].hours[0] ==
                                        "Monday:Opening in October 2019" &&
                                        results.rows[index].hours[1] ==
                                        "Tuesday:Opening in October 2019" &&
                                        results.rows[index].hours[2] ==
                                        "Wednesday:Opening in October 2019" &&
                                        results.rows[index].hours[3] ==
                                        "Thursday:Opening in October 2019"
                                    ) {
                                        results.rows[index].hours = [];
                                        results.rows[index].hours[0] = "Opening in October 2019";
                                    }

                                    if (
                                        results.rows[index].hours[0] == "Monday:24/7" &&
                                        results.rows[index].hours[1] == "Tuesday:24/7" &&
                                        results.rows[index].hours[2] == "Wednesday:24/7"
                                    ) {
                                        results.rows[index].hours = [];

                                        results.rows[index].hours[0] = "24/7";
                                    }
                                } else {
                                    for (var hr = 0; hr < results.rows[index].hour.length; hr++) {
                                        if (results.rows[index].hour[hr].includes("Monday")) {
                                            results.rows[index].hours[0] =
                                                results.rows[index].hour[hr];
                                        } else if (
                                            results.rows[index].hour[hr].includes("Tuesday")
                                        ) {
                                            results.rows[index].hours[1] =
                                                results.rows[index].hour[hr];
                                        } else if (
                                            results.rows[index].hour[hr].includes("Wednesday")
                                        ) {
                                            results.rows[index].hours[2] =
                                                results.rows[index].hour[hr];
                                        } else if (
                                            results.rows[index].hour[hr].includes("Thursday")
                                        ) {
                                            results.rows[index].hours[3] =
                                                results.rows[index].hour[hr];
                                        } else if (
                                            results.rows[index].hour[hr].includes("Friday")
                                        ) {
                                            results.rows[index].hours[4] =
                                                results.rows[index].hour[hr];
                                        } else if (
                                            results.rows[index].hour[hr].includes("Saturday")
                                        ) {
                                            results.rows[index].hours[5] =
                                                results.rows[index].hour[hr];
                                        } else if (
                                            results.rows[index].hour[hr].includes("Sunday")
                                        ) {
                                            results.rows[index].hours[6] =
                                                results.rows[index].hour[hr];
                                        }
                                    }
                                }
                            });
                            results.rows[index].hours = results.rows[index].hours.filter(
                                v => v != null
                            );
                        });
                        if (results) successCallback(resarr);
                    }
                );
            } else {
                successCallback("No data");
            }
        }
    );
};


db.redeemDeals = function (redeem, successCallback, failureCallback) {

    var dealId = redeem.deals_id;
    var userId = redeem.user_id;
    pool.query("select * from deals where id = $1", [dealId], (error, deals) => {
        if (error) {
            failureCallback(error);
        }
        if (deals.rows.length != 0) {
            var dealsAllowed = parseInt(deals.rows[0].redeems_allowed == null ? 0 : deals.rows[0].redeems_allowed);
            var redeemCode = deals.rows[0].redeem_code;

            //checking deal save logic
            pool.query("select * from user_deals where deal_id=$1 AND user_id=$2", [dealId, userId], (error, userDeals) => {
                if (error) {
                    failureCallback(error)
                }
                if (userDeals.rows.length == 0) {
                    const dealSaveId = uuidv1("");
                    pool.query("INSERT INTO user_deals (id, user_id, deal_id,redeem_code) VALUES ($1, $2, $3,$4)", [dealSaveId, userId, dealId, redeemCode], (error, redeem_rows) => {
                        if (error) {
                            failureCallback(error);
                        }
                    });
                }
            });

            //deal redeem saving logic
            pool.query('select * from redeems where deal_id = $1 and user_id = $2', [dealId, userId], (error, dealRedeem) => {
                if (error) {
                    failureCallback(error);
                }
                if (dealRedeem.rows.length != 0) {
                    var redeemCount = parseInt(dealRedeem.rows[0].redeem_count == null ? 0 : dealRedeem.rows[0].redeem_count);
                    if (dealsAllowed == 0) {

                        pool.query("update redeems set redeem_count = $3 where deal_id = $1 AND user_id = $2", [dealId, userId, redeemCount + 1], (error, results) => {
                            if (error) {
                                failureCallback(error)
                            }
                            successCallback(redeemCode);
                        });
                    } else {
                        if (redeemCount >= 0 && redeemCount < dealsAllowed) {
                            pool.query("update redeems set redeem_count = $3 where deal_id = $1 AND user_id = $2", [dealId, userId, redeemCount + 1], (error, results) => {
                                if (error) {
                                    failureCallback(error)
                                }
                                successCallback(redeemCode);

                            });
                        } else {
                            successCallback("Reached maximum redeem limit..!");
                        }
                    }
                } else if (dealRedeem.rows.length == 0) {
                    pool.query("INSERT INTO redeems (id, user_id, deal_id, status, redeem_code, redeem_count) VALUES ($1, $2, $3, $4, $5, $6) ", [uuidv1(""), userId, dealId, 'saved', redeemCode, 1], (error, userDealRedeem) => {
                        if (error) {
                            failureCallback(error)
                        }
                        successCallback(redeemCode);
                    });
                }
            });

        }
    });
};


db.searchDeals = function (data, successCallback, failureCallback) {
    var date = dateData();
    var setquery =
    'SELECT deals.id,deals.pinned,deals.details,deals.url,deals.business_id,deals.title,deals.expiry_date,business.lat,business.long,business.phone,business.website_url,business.address_line1,business.zip,business.email, business.description, business.city_name AS "city",business.state, json_object(array_agg(photos.type),array_agg(photos.photo)) AS "photo",array_to_string(array_agg( distinct photos."type"),\',\')  AS "type",array_to_string(array_agg(distinct business.name),\',\') AS "name",deals.redeem_code,array_to_string(array_agg(distinct open_hours.day),\',\')  AS "day",array_agg(distinct open_hours.day || \':\' || open_hours.hours) As "hour" ,deals.redeems_allowed, redeems.redeem_count as user_redeem_count,redeems.user_id FROM city INNER JOIN neighbourhood ON (city.id = neighbourhood.city_id) INNER JOIN business ON (neighbourhood.id = business.neighbourhood_id) INNER JOIN deals ON (deals.business_id = business.id ) INNER JOIN deb_photos ON (deb_photos.deals_id=deals."id") INNER JOIN photos ON (photos."id" = deb_photos.photo_id) INNER JOIN open_hours ON (open_hours.business_id=business.id) INNER JOIN schedule ON (schedule.deal_id = deals.id) left outer JOIN redeems ON (redeems.deal_id = deals.id and redeems.user_id=$7) WHERE (city.city = $1 AND deals.pinned = 0)' +
    "AND (business.name iLIKE '%' || $2 || '%' OR business.description iLike '%' || $3 || '%' OR deals.title iLike '%' || $4 || '%' OR deals.details iLike '%' || $5 || '%') GROUP BY  deals.id,deals.pinned,deals.details,deals.url,deals.business_id,deals.title,deals.expiry_date, business.lat,business.long,business.phone,business.website_url,business.address_line1,business.zip,business.email , business.description, business.city_name, business.state,deals.create_date, redeems.user_id,redeems.redeem_count  UNION ALL SELECT deals.id,deals.pinned,deals.details,deals.url,deals.business_id,deals.title,deals.expiry_date,business.lat,business.long,business.phone,business.website_url,business.address_line1,business.zip,business.email, business.description, business.city_name AS \"city\",business.state, json_object(array_agg(photos.type),array_agg(photos.photo)) AS \"photo\",array_to_string(array_agg( distinct photos.\"type\"),',')  AS \"type\",array_to_string(array_agg(distinct business.name),',') AS \"name\",deals.redeem_code,array_to_string(array_agg(distinct open_hours.day),',')  AS \"day\",array_agg(distinct open_hours.day || ':' || open_hours.hours) As \"hour\" ,deals.redeems_allowed, redeems.redeem_count as user_redeem_count,redeems.user_id FROM city INNER JOIN neighbourhood ON (city.id = neighbourhood.city_id) INNER JOIN business ON (neighbourhood.id = business.neighbourhood_id) INNER JOIN deals ON (deals.business_id = business.id ) INNER JOIN business_cities ON (business.id=business_cities.business_id) INNER JOIN deb_photos ON (deb_photos.deals_id=deals.\"id\") INNER JOIN photos ON (photos.\"id\" = deb_photos.photo_id) INNER JOIN open_hours ON (open_hours.business_id=business.id) INNER JOIN schedule ON (schedule.deal_id = deals.id) left outer JOIN redeems ON (redeems.deal_id = deals.id and redeems.user_id=$7) WHERE (business_cities.additional_location=$6 AND deals.pinned = 0) " +
    "AND (business.name iLIKE '%' || $2 || '%' OR business.description iLike '%' || $3 || '%' OR deals.title iLike '%' || $4 || '%' OR deals.details iLike '%' || $5 || '%')   GROUP BY  deals.id,deals.pinned,deals.details,deals.url,deals.business_id,deals.title,deals.expiry_date, business.lat,business.long,business.phone,business.website_url,business.address_line1,business.zip,business.email , business.description, business.city_name, business.state,deals.create_date,business_cities.additional_location, redeems.user_id,redeems.redeem_count";


pool.query(
    setquery,
    [
        data["city"],
        data["name"],
        data["name"],
        data["name"],
        data["name"],
        data["city"],
        data["user_id"]
    ],
        (error, results) => {
            var arr = [],
                resarr = [];
            results.rows.forEach(function (item, index) {
                if (!arr.includes(results.rows[index].name)) {
                    resarr.push(results.rows[index]);
                    arr.push(results.rows[index].name);
                }

                results.rows[index].hours = [];
                results.rows[index].hour.forEach(function (time, i) {
                    if (results.rows[index].hour.length < 2) {
                        results.rows[index].hours[0] = results.rows[index].hour[0];
                    }
                    if (results.rows[index].hour.length > 6) {
                        results.rows[index].hours[0] = results.rows[index].hour[1];
                        results.rows[index].hours[1] = results.rows[index].hour[5];
                        results.rows[index].hours[2] = results.rows[index].hour[6];
                        results.rows[index].hours[3] = results.rows[index].hour[4];
                        results.rows[index].hours[4] = results.rows[index].hour[0];
                        results.rows[index].hours[5] = results.rows[index].hour[2];
                        results.rows[index].hours[6] = results.rows[index].hour[3];

                        if (results.rows[index].hours[0] == "Monday:By appointment") {
                            results.rows[index].hours = [];
                            results.rows[index].hours[0] = "By appointment";
                        }

                        if (results.rows[index].hours[0] == "Monday:24/7") {
                            results.rows[index].hours = [];
                            results.rows[index].hours[0] = "24/7";
                        }
                    } else {
                        for (var hr = 0; hr < results.rows[index].hour.length; hr++) {
                            if (results.rows[index].hour[hr].includes("Monday")) {
                                results.rows[index].hours[0] = results.rows[index].hour[hr];
                            } else if (results.rows[index].hour[hr].includes("Tuesday")) {
                                results.rows[index].hours[1] = results.rows[index].hour[hr];
                            } else if (results.rows[index].hour[hr].includes("Wednesday")) {
                                results.rows[index].hours[2] = results.rows[index].hour[hr];
                            } else if (results.rows[index].hour[hr].includes("Thursday")) {
                                results.rows[index].hours[3] = results.rows[index].hour[hr];
                            } else if (results.rows[index].hour[hr].includes("Friday")) {
                                results.rows[index].hours[4] = results.rows[index].hour[hr];
                            } else if (results.rows[index].hour[hr].includes("Saturday")) {
                                results.rows[index].hours[5] = results.rows[index].hour[hr];
                            } else if (results.rows[index].hour[hr].includes("Sunday")) {
                                results.rows[index].hours[6] = results.rows[index].hour[hr];
                            }
                        }
                    }
                });
                results.rows[index].hours = results.rows[index].hours.filter(
                    v => v != null
                );
            });

            if (error) failureCallback(error);
            else successCallback(resarr);
        }
    );
};


db.hotDeals = function (data, successCallback, failureCallback) {
    var date = dateData();
    var setquery =
        '(SELECT deals.id,deals.details,deals.url,deals.title,deals.expiry_date,business."name",business.lat,business.long,business.phone,business.website_url,business.address_line1,business.zip,business.email, business.description, city.city, city.state,json_object(array_agg(photos.type),array_agg(photos.photo)) AS "photo",array_to_string(array_agg( distinct photos."type"),\',\')  AS "type",array_to_string(array_agg(distinct business.name),\',\') AS "name",deals.redeem_code,array_to_string(array_agg(distinct open_hours.day),\',\')  AS "day",array_agg(distinct open_hours.day || \':\' || open_hours.hours) As "hour",business.id as "business_id",business.city_name AS "city1" FROM city INNER JOIN neighbourhood ON (city.id = neighbourhood.city_id) INNER JOIN business ON (neighbourhood.id = business.neighbourhood_id) INNER JOIN deals ON (deals.business_id = business.id ) INNER JOIN deb_photos ON (deb_photos.deals_id=deals."id") INNER JOIN photos ON (photos."id" = deb_photos.photo_id) INNER JOIN open_hours ON (open_hours.business_id=business.id) INNER JOIN schedule ON (schedule.deal_id = deals.id) WHERE (city.city ILike $1 AND deals.is_feature=$2 AND deals.is_hot_deals=$3 AND ' +
        date +
        '= $5 ) GROUP BY  deals.id,deals.details,deals.url,deals.title,deals.expiry_date, business.lat,business.long,business.phone,business.website_url,business.address_line1,business.zip,business.email , business.description, city.city, city.state,deals.create_date,business."name",business.id,business.city_name  ORDER BY deals.create_date DESC) UNION ALL (SELECT deals.id,deals.details,deals.url,deals.title,deals.expiry_date,business."name",business.lat,business.long,business.phone,business.website_url,business.address_line1,business.zip,business.email, business.description, city.city, city.state,json_object(array_agg(photos.type),array_agg(photos.photo)) AS "photo",array_to_string(array_agg( distinct photos."type"),\',\')  AS "type",array_to_string(array_agg(distinct business.name),\',\') AS "name",deals.redeem_code,array_to_string(array_agg(distinct open_hours.day),\',\')  AS "day",array_agg(distinct open_hours.day || \':\' || open_hours.hours) As "hour",business.id as "business_id",business.city_name AS "city1" FROM city INNER JOIN neighbourhood ON (city.id = neighbourhood.city_id) INNER JOIN business ON (neighbourhood.id = business.neighbourhood_id) INNER JOIN deals ON (deals.business_id = business.id ) INNER JOIN business_cities on (business.id=business_cities.business_id) INNER JOIN deb_photos ON (deb_photos.deals_id=deals."id") INNER JOIN photos ON (photos."id" = deb_photos.photo_id) INNER JOIN open_hours ON (open_hours.business_id=business.id)  INNER JOIN schedule ON (schedule.deal_id = deals.id) WHERE (business_cities.additional_location=$4 AND deals.is_feature=$2 AND deals.is_hot_deals=$3 AND ' +
        date +
        '= $5)  GROUP BY  deals.id,deals.details,deals.url,deals.title,deals.expiry_date, business.lat,business.long,business.phone,business.website_url,business.address_line1,business.zip,business.email , business.description, city.city, city.state,deals.create_date,business."name",business.id,business.city_name  ORDER BY deals.create_date DESC)';
    pool.query(
        setquery,
        [data.city, data.is_feature, data.is_hot_deals, data.city, true],
        (error, results) => {
            console.log(error);

            var arr = [],
                resarr = [];
            results.rows.forEach(function (item, index) {
                if (!arr.includes(results.rows[index].name.toLowerCase())) {
                    resarr.push(results.rows[index]);
                    arr.push(results.rows[index].name.toLowerCase());
                }
                results.rows[index].hours = [];
                results.rows[index].hour.forEach(function (time, i) {
                    if (results.rows[index].hour.length < 2) {
                        results.rows[index].hours[0] = results.rows[index].hour[0];
                    }
                    if (results.rows[index].hour.length > 6) {
                        results.rows[index].hours[0] = results.rows[index].hour[1];
                        results.rows[index].hours[1] = results.rows[index].hour[5];
                        results.rows[index].hours[2] = results.rows[index].hour[6];
                        results.rows[index].hours[3] = results.rows[index].hour[4];
                        results.rows[index].hours[4] = results.rows[index].hour[0];
                        results.rows[index].hours[5] = results.rows[index].hour[2];
                        results.rows[index].hours[6] = results.rows[index].hour[3];
                    } else {
                        results.rows[index].hours = results.rows[index].hour;
                    }
                });
            });
            if (error) failureCallback(error);
            else successCallback(resarr);
        }
    );
};
//hot_deals search DB
db.hotDealsSearch = function (data, successCallback, failureCallback) {
    var date = dateData();
    var setquery =
        '(SELECT deals.id,deals.details,deals.url,deals.title,deals.expiry_date,business."name",business.lat,business.long,business.phone,business.website_url,business.address_line1,business.zip,business.email, business.description, city.city, city.state,json_object(array_agg(photos.type),array_agg(photos.photo)) AS "photo",array_to_string(array_agg( distinct photos."type"),\',\')  AS "type",array_to_string(array_agg(distinct business.name),\',\') AS "name",deals.redeem_code,array_to_string(array_agg(distinct open_hours.day),\',\')  AS "day",array_agg(distinct open_hours.day || \':\' || open_hours.hours) As "hour",business.id as "business_id",business.city_name AS "city1" FROM city INNER JOIN neighbourhood ON (city.id = neighbourhood.city_id) INNER JOIN business ON (neighbourhood.id = business.neighbourhood_id) INNER JOIN deals ON (deals.business_id = business.id ) INNER JOIN deb_photos ON (deb_photos.deals_id=deals."id") INNER JOIN photos ON (photos."id" = deb_photos.photo_id) INNER JOIN open_hours ON (open_hours.business_id=business.id) INNER JOIN schedule ON (schedule.deal_id = deals.id) WHERE (deals.is_feature= $1 AND deals.is_hot_deals= $2 AND ' +
        date +
        "= $8 AND city.city ilike '%' || $3 || '%' AND (business.name iLIKE '%' || $4 || '%' OR business.description iLike '%' || $5 || '%' OR deals.title iLike '%' || $6 || '%' OR deals.details iLike '%' || $7 || '%') ) GROUP BY  deals.id,deals.details,deals.url,deals.title,deals.expiry_date, business.lat,business.long,business.phone,business.website_url,business.address_line1,business.zip,business.email , business.description, city.city, city.state,deals.create_date,business.\"name\",business.id,business.city_name   ORDER BY deals.create_date DESC) UNION ALL (SELECT deals.id,deals.details,deals.url,deals.title,deals.expiry_date,business.\"name\",business.lat,business.long,business.phone,business.website_url,business.address_line1,business.zip,business.email, business.description, city.city, city.state,json_object(array_agg(photos.type),array_agg(photos.photo)) AS \"photo\",array_to_string(array_agg( distinct photos.\"type\"),',')  AS \"type\",array_to_string(array_agg(distinct business.name),',') AS \"name\",deals.redeem_code,array_to_string(array_agg(distinct open_hours.day),',')  AS \"day\",array_agg(distinct open_hours.day || ':' || open_hours.hours) As \"hour\",business.id as \"business_id\",business.city_name AS \"city1\" FROM city INNER JOIN neighbourhood ON (city.id = neighbourhood.city_id) INNER JOIN business ON (neighbourhood.id = business.neighbourhood_id) INNER JOIN deals ON (deals.business_id = business.id )INNER JOIN business_cities on (business.id=business_cities.business_id) INNER JOIN deb_photos ON (deb_photos.deals_id=deals.\"id\") INNER JOIN photos ON (photos.\"id\" = deb_photos.photo_id) INNER JOIN open_hours ON (open_hours.business_id=business.id) INNER JOIN schedule ON (schedule.deal_id = deals.id) WHERE (deals.is_feature= $1 AND deals.is_hot_deals= $2 AND " +
        date +
        "= $8 AND (city.city ilike '%' || $3 || '%' OR business_cities.additional_location=$3) AND (business.name iLIKE '%' || $4 || '%' OR business.description iLike '%' || $5 || '%' OR deals.title iLike '%' || $6 || '%' OR deals.details iLike '%' || $7 || '%') ) GROUP BY  deals.id,deals.details,deals.url,deals.title,deals.expiry_date, business.lat,business.long,business.phone,business.website_url,business.address_line1,business.zip,business.email , business.description, city.city, city.state,deals.create_date,business.\"name\",business.id,business.city_name  ORDER BY deals.create_date DESC)";
    pool.query(
        setquery,
        [
            data.is_feature,
            data.is_hot_deal,
            data.city,
            data.name,
            data.name,
            data.name,
            data.name,
            true
        ],
        (error, results) => {
            console.log(error);
            var arr = [],
                resarr = [];
            results.rows.forEach(function (item, index) {
                if (!arr.includes(results.rows[index].name.toLowerCase())) {
                    resarr.push(results.rows[index]);
                    arr.push(results.rows[index].name.toLowerCase());
                }
                results.rows[index].hours = [];
                results.rows[index].hour.forEach(function (time, i) {
                    if (results.rows[index].hour.length < 2) {
                        results.rows[index].hours[0] = results.rows[index].hour[0];
                    }
                    if (results.rows[index].hour.length > 6) {
                        results.rows[index].hours[0] = results.rows[index].hour[1];
                        results.rows[index].hours[1] = results.rows[index].hour[5];
                        results.rows[index].hours[2] = results.rows[index].hour[6];
                        results.rows[index].hours[3] = results.rows[index].hour[4];
                        results.rows[index].hours[4] = results.rows[index].hour[0];
                        results.rows[index].hours[5] = results.rows[index].hour[2];
                        results.rows[index].hours[6] = results.rows[index].hour[3];
                    } else {
                        results.rows[index].hours = results.rows[index].hour;
                    }
                });
            });
            if (error) {
                failureCallback(error);
            } else successCallback(resarr);
        }
    );
};

db.multiDeals = function (data, successCallback, failureCallback) {
    var date = dateData();
    pool.query(
        "select * from business where business.id=$1",
        [data.id],
        (error, result) => {
            if (error) {
                failureCallback(error);
            } else if (result.rowCount > 0) {
                if (data.is_hot_deals == "false") {
                    var setquery =
                        'SELECT deals.id,deals.pinned,deals.details,deals.url,deals.title,deals.expiry_date,business.lat,business.long,business.phone,business.website_url,business.address_line1,business.zip,business.email, business.description, city.city, city.state, json_object(array_agg(photos.type),array_agg(photos.photo)) AS "photo",array_to_string(array_agg( distinct photos."type"),\',\')  AS "type",array_to_string(array_agg(distinct business.name),\',\') AS "name",deals.redeem_code,array_to_string(array_agg(distinct open_hours.day),\',\')  AS "day",array_agg(distinct open_hours.day || \':\' || open_hours.hours) As "hour",deals.create_date, deals.redeems_allowed, redeems.redeem_count as user_redeem_count,redeems.user_id  FROM city INNER JOIN neighbourhood ON (city.id = neighbourhood.city_id) INNER JOIN business ON (neighbourhood.id = business.neighbourhood_id) INNER JOIN deals ON (deals.business_id = business.id ) INNER JOIN deb_photos ON (deb_photos.deals_id=deals."id") INNER JOIN photos ON (photos."id" = deb_photos.photo_id) INNER JOIN open_hours ON (open_hours.business_id=business.id) INNER JOIN schedule ON (schedule.deal_id = deals.id) left outer JOIN redeems ON (redeems.deal_id = deals.id and redeems.user_id=$2) WHERE (business.name=$1 AND deals.pinned = 0)' +
                        "GROUP BY  deals.id,deals.pinned,deals.details,deals.url,deals.title,deals.expiry_date, business.lat,business.long,business.phone,business.website_url,business.address_line1,business.zip,business.email , business.description, city.city, city.state,deals.create_date, redeems.user_id,redeems.redeem_count ORDER BY deals.create_date DESC";
                    pool.query(
                        setquery,
                        [result.rows[0].name, data['user_id']],
                        (error, results) => {
                            console.log(error);
                            var allDeals = [],
                                resultDeals = [];
                            results.rows.forEach(function (item, index) {
                                if (!allDeals.includes(results.rows[index].title)) {
                                    resultDeals.push(results.rows[index]);
                                    allDeals.push(results.rows[index].title);
                                }
                                results.rows[index].hours = [];
                                results.rows[index].hour.forEach(function (time, i) {
                                    if (results.rows[index].hour.length < 2) {
                                        results.rows[index].hours[0] = results.rows[index].hour[0];
                                    }
                                    if (results.rows[index].hour.length > 6) {
                                        results.rows[index].hours[0] = results.rows[index].hour[1];
                                        results.rows[index].hours[1] = results.rows[index].hour[5];
                                        results.rows[index].hours[2] = results.rows[index].hour[6];
                                        results.rows[index].hours[3] = results.rows[index].hour[4];
                                        results.rows[index].hours[4] = results.rows[index].hour[0];
                                        results.rows[index].hours[5] = results.rows[index].hour[2];
                                        results.rows[index].hours[6] = results.rows[index].hour[3];
                                    } else {
                                        results.rows[index].hours = results.rows[index].hour;
                                    }
                                });
                            });
                            if (results) {
                                successCallback(resultDeals);
                            } else if (error) {
                                failureCallback(error);
                            }
                        }
                    );
                } else {
                    var setquery =
                        'SELECT deals.id,deals.pinned,deals.details,deals.url,deals.title,deals.expiry_date,business.lat,business.long,business.phone,business.website_url,business.address_line1,business.zip,business.email, business.description, city.city, city.state, json_object(array_agg(photos.type),array_agg(photos.photo)) AS "photo",array_to_string(array_agg( distinct photos."type"),\',\')  AS "type",array_to_string(array_agg(distinct business.name),\',\') AS "name",deals.redeem_code,array_to_string(array_agg(distinct open_hours.day),\',\')  AS "day",array_agg(distinct open_hours.day || \':\' || open_hours.hours) As "hour",deals.create_date FROM city INNER JOIN neighbourhood ON (city.id = neighbourhood.city_id) INNER JOIN business ON (neighbourhood.id = business.neighbourhood_id) INNER JOIN deals ON (deals.business_id = business.id ) INNER JOIN deb_photos ON (deb_photos.deals_id=deals."id") INNER JOIN photos ON (photos."id" = deb_photos.photo_id) INNER JOIN open_hours ON (open_hours.business_id=business.id) INNER JOIN schedule ON (schedule.deal_id = deals.id) WHERE (business.name=$1 AND deals.pinned = 0' +
                        "AND deals.is_hot_deals = $2) GROUP BY  deals.id,deals.pinned,deals.details,deals.url,deals.title,deals.expiry_date, business.lat,business.long,business.phone,business.website_url,business.address_line1,business.zip,business.email , business.description, city.city, city.state,deals.create_date ORDER BY deals.create_date DESC";
                    pool.query(
                        setquery,
                        [result.rows[0].name, true],
                        (error, results) => {
                            var allDeals = [],
                                resultDeals = [];
                            results.rows.forEach(function (item, index) {
                                if (!allDeals.includes(results.rows[index].title)) {
                                    resultDeals.push(results.rows[index]);
                                    allDeals.push(results.rows[index].title);
                                }
                                results.rows[index].hours = [];
                                results.rows[index].hour.forEach(function (time, i) {
                                    if (results.rows[index].hour.length < 2) {
                                        results.rows[index].hours[0] = results.rows[index].hour[0];
                                    }
                                    if (results.rows[index].hour.length > 6) {
                                        results.rows[index].hours[0] = results.rows[index].hour[1];
                                        results.rows[index].hours[1] = results.rows[index].hour[5];
                                        results.rows[index].hours[2] = results.rows[index].hour[6];
                                        results.rows[index].hours[3] = results.rows[index].hour[4];
                                        results.rows[index].hours[4] = results.rows[index].hour[0];
                                        results.rows[index].hours[5] = results.rows[index].hour[2];
                                        results.rows[index].hours[6] = results.rows[index].hour[3];
                                    } else {
                                        results.rows[index].hours = results.rows[index].hour;
                                    }
                                });
                            });
                            if (results) {
                                successCallback(resultDeals);
                            } else if (error) {
                                failureCallback(error);
                            }
                        }
                    );
                }
            }
            //}
        }
    );
};

module.exports = db;
