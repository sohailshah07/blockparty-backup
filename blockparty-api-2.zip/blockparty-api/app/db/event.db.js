"use strict";
var crypt = require("../crypt");
var config = require("../../config/main");
var db = {};
const uuidv1 = require("uuid/v1");


const Pool = require("pg").Pool;
const pool = new Pool({
    user: config.user,
    host: config.host,
    database: config.database,
    password: config.password,
    port: config.pg_port
});
var moment = require("moment-timezone");

function dateData() {
    var today = new Date().getDay().toLocaleString("en-US", {
        timeZone: "America/Denver"
    });
    if (today == 0) var presentDay = "schedule.sunday";
    if (today == 1) var presentDay = "schedule.monday";
    if (today == 2) var presentDay = "schedule.tuesday";
    if (today == 3) var presentDay = "schedule.wednesday";
    if (today == 4) var presentDay = "schedule.thursday";
    if (today == 5) var presentDay = "schedule.friday";
    if (today == 6) var presentDay = "schedule.saturday";

    return presentDay;
}

function currentData() {
    var today = new Date();
    var date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
    return date;
}

function formatDate(date) {
    var d = new Date(date),
        month = "" + (d.getMonth() + 1),
        day = "" + d.getDate(),
        year = d.getFullYear();

    if (month.length < 2) month = "0" + month;
    if (day.length < 2) day = "0" + day;

    return [year, month, day].join("-");
}

pool.query("SELECT * FROM users", (error, result) => {
    if (result) console.log("Connected to PG");
    else console.log("Connection error : " + error);
});


db.findTodaysEvents = function (data, successCallback, failureCallback) {
    const _ = require("lodash");
    var moment = require("moment");
    var today = new Date();
    var todate = formatDate(today);
    var resupdate = [];
    var query =
        "SELECT events.id,events.title,events.neighbourhood_id,events.url,events.details,events.eventtime,events.start_date,events.location,to_char(events.start_date::DATE , 'Month DD') AS MONTHS ,events.is_ttod,events.end_date,city.city,city.state,events.is_feature,array_to_string(array_agg(DISTINCT open_hours.id),',') AS open_hours_id,array_to_string(array_agg(DISTINCT open_hours.day),',')  AS \"day\",array_agg(DISTINCT open_hours.day || ':' || open_hours.hours) AS \"hour\" FROM city INNER JOIN neighbourhood ON (city.id = neighbourhood.city_id) INNER JOIN events ON (neighbourhood.id = events.neighbourhood_id)INNER JOIN open_hours ON (open_hours.event_id=events.id)   WHERE city.city =$1 AND events.is_ttod=$2   GROUP BY  events.id,events.details,events.title, city.city, city.state,events.create_date ORDER BY events.start_date ASC";
    pool.query(query, [data["city"], true], (error, results) => {
        console.log(error);
        results.rows.forEach(function (item, index) {
            results.rows[index].hours = [];

            results.rows[index].hour.forEach(function (time, i) {
                var todatenew = formatDate(results.rows[index].start_date);
                if (todatenew == todate) {
                    resupdate.push(results.rows[index]);
                }
                if (results.rows[index].hour.length > 6) {
                    results.rows[index].hours[0] = results.rows[index].hour[1];
                    results.rows[index].hours[1] = results.rows[index].hour[5];
                    results.rows[index].hours[2] = results.rows[index].hour[6];
                    results.rows[index].hours[3] = results.rows[index].hour[4];
                    results.rows[index].hours[4] = results.rows[index].hour[0];
                    results.rows[index].hours[5] = results.rows[index].hour[2];
                    results.rows[index].hours[6] = results.rows[index].hour[3];
                } else {
                    results.rows[index].hours = results.rows[index].hour;
                }
            });
        });
        if (resupdate) {
            successCallback(resupdate);
        } else if (error) {
            failureCallback(error);
        }
    });
};

db.findThingsTodo = function (data, successCallback, failureCallback) {
    var today = Date.parse(formatDate(new Date()));
    var resupdate = [];
    pool.query(
        "SELECT events.id,events.neighbourhood_id,events.body,events.location,events.url,events.start_date,events.end_date,city.city," +
        "city.state,events.is_feature,array_to_string(array_agg(distinct events.title),',') AS \"title\", " +
        'json_object(array_agg(photos.type),array_agg(photos.photo)) AS "photos",array_to_string(array_agg( distinct photos."type"),\',\')  AS "type",' +
        " array_to_string(array_agg(DISTINCT open_hours.id),',') AS open_hours_id,array_to_string(array_agg(DISTINCT open_hours.day),',')  AS \"day\"," +
        "array_agg(DISTINCT open_hours.day || ':' || open_hours.hours) AS \"hour\", to_char(events.start_date::DATE ,'Month DD')AS MONTHS " +
        "FROM city INNER JOIN neighbourhood ON (city.id = neighbourhood.city_id) INNER JOIN events ON (neighbourhood.id = events.neighbourhood_id) " +
        "INNER JOIN deb_photos ON(deb_photos.events_id=events.id) INNER JOIN photos ON(deb_photos.photo_id=photos.id)" +
        "left outer JOIN open_hours ON (open_hours.event_id=events.id) WHERE (city.city =$1 AND (events.is_feature=$2 OR events.is_news_feed=$2) AND events.is_today=$2) " +
        "GROUP BY  events.id,events.details,events.title, city.city, city.state,events.create_date ORDER BY events.create_date DESC",
        [data["city"], true],
        (error, results) => {
            console.log(error);
            results.rows.forEach(function (item, index) {

                var sd = Date.parse(formatDate(results.rows[index].start_date));
                var ed = Date.parse(formatDate(results.rows[index].end_date));

                if (today >= sd && today <= ed) {
                    resupdate.push(results.rows[index]);
                } else if (sd == 0 && ed == 0) {
                    resupdate.push(results.rows[index]);
                } else if (today == sd && ed == 0) {
                    resupdate.push(results.rows[index]);
                }
            });
            resupdate.forEach(function (item, index) {
                resupdate[index].hours = [];
                resupdate[index].hour.forEach(function (time, i) {
                    if (resupdate[index].hour.length > 6) {
                        resupdate[index].hours[0] = resupdate[index].hour[1];
                        resupdate[index].hours[1] = resupdate[index].hour[5];
                        resupdate[index].hours[2] = resupdate[index].hour[6];
                        resupdate[index].hours[3] = resupdate[index].hour[4];
                        resupdate[index].hours[4] = resupdate[index].hour[0];
                        resupdate[index].hours[5] = resupdate[index].hour[2];
                        resupdate[index].hours[6] = resupdate[index].hour[3];
                    } else {
                        resupdate[index].hours = resupdate[index].hour;
                    }
                });
            });

            if (results) {
                successCallback(resupdate);
            } else if (error) {
                failureCallback(error);
            }
        }
    );
};

db.eventPhotos = function (data, successCallback, failureCallback) {
    var query =
        "SELECT photos.type, photos.photo from deb_photos inner JOIN photos ON(deb_photos.photo_id=photos.id) where events_id=$1";
    pool.query(query, [data["eventId"]], (error, photoList) => {
        if (photoList) {
            successCallback(photoList.rows);
        } else if (error) {
            failureCallback(error);
        }
    });
};
//fix this
db.findFeaturedEvents = function (data, successCallback, failureCallback) {
    var today = Date.parse(formatDate(new Date()));
    var endDate = Date.parse(formatDate(Date.now() + 12096e5));
    //console.log(today);
    //console.log(endDate);
    var resupdate = [];
    var eventsIds = [];
    var isFeature = data["is_feature"];
    var isNewFeed = data["is_news_feed"];
    var isFeaureOrNeewsFeed = "(current_date between start_date -1 and start_date + 31) and events.is_news_feed";
    var newsFeedFlag = (isFeature != undefined && isFeature.toUpperCase() === "TRUE") ? false : true;
    isFeaureOrNeewsFeed = newsFeedFlag ? isFeaureOrNeewsFeed : "";
    var featureCaluse = newsFeedFlag ? "(events.is_feature=$2 OR events.is_news_feed=$2) AND events.is_today=$2" : "events.is_feature=$2"
    var intialPartQuery = "SELECT events.id,events.title,events.body,events.neighbourhood_id,events.location,events.url,events.start_date,events.end_date,city.city," +
        "city.state,events.is_feature,array_to_string(array_agg(DISTINCT open_hours.id),',') AS open_hours_id, " +
        'json_object(array_agg(photos.type),array_agg(photos.photo)) AS "photos",array_to_string(array_agg( distinct photos."type"),\',\')  AS "type",' +
        "array_to_string(array_agg(DISTINCT open_hours.day),',')  AS \"day\",array_agg(DISTINCT open_hours.day || ':' || open_hours.hours) AS \"hour\"," +
        "to_char(events.start_date::DATE ,'Month DD')AS MONTHS " +
        "FROM city INNER JOIN neighbourhood ON (city.id = neighbourhood.city_id) " +
        "INNER JOIN events ON (neighbourhood.id = events.neighbourhood_id) " +
        "LEFT outer JOIN open_hours ON (open_hours.event_id=events.id) " +
        "Left JOIN deb_photos ON(deb_photos.events_id=events.id) " +
        "JOIN photos ON(deb_photos.photo_id=photos.id) ";
    pool.query(intialPartQuery + "WHERE city.city =$1 AND " + featureCaluse +
        "GROUP BY events.id,events.details,events.title, city.city, city.state,events.create_date ORDER BY events.create_date DESC ",
        [data["city"], true],
        (error, results) => {
            //console.log(error);
            console.log(JSON.stringify(results));
            results.rows.forEach(function (item, index) {
                var sd = Date.parse(formatDate(results.rows[index].start_date));
                var ed = Date.parse(formatDate(results.rows[index].end_date));
                if ((today >= sd || sd < endDate) && (ed >= today)) { //startDate  = 2020-08-22T18:30:00.000Z today = 22/08 enddate 05/09
                    resupdate.push(results.rows[index]);
                    eventsIds.push(results.rows[index].id);
                } else if (sd == 0 && ed == 0) {
                    resupdate.push(results.rows[index]);
                    eventsIds.push(results.rows[index].id);
                } else if (today == sd && ed == 0) {
                    resupdate.push(results.rows[index]);
                    eventsIds.push(results.rows[index].id);
                }
            });
            if (newsFeedFlag) {
                resupdate = resupdate.slice(0, resupdate.length > 3 ? 3 : resupdate.length);
                eventsIds = eventsIds.slice(0, eventsIds.length > 3 ? 3 : eventsIds.length)
            }

            if (newsFeedFlag) {
                pool.query(intialPartQuery + "WHERE city.city =$1 AND " + isFeaureOrNeewsFeed + "=$2 " +
                    "GROUP BY events.id,events.details,events.title, city.city, city.state,events.create_date ORDER BY events.create_date DESC",
                    [data["city"], true],
                    (error, results2) => {
                        console.log(error);
                        results2.rows.forEach(function (item, position) {
                            if (!eventsIds.includes(results2.rows[position].id)) {
                                resupdate.push(results2.rows[position]);
                                eventsIds.push(results2.rows[position].id);
                            }
                        });
                        resupdate = getHours(resupdate);
                        if (resupdate.length > 0) {
                            successCallback(resupdate);
                        } else if (error) {
                            failureCallback(error);
                        }
                    });
            } else {
                resupdate = getHours(resupdate);
                if (resupdate.length > 0) {
                    successCallback(resupdate);
                } else if (error) {
                    failureCallback(error);
                }
            }
        }
    );
};

function getHours(resupdate) {
    resupdate.forEach(function (item, index) {
        resupdate[index].hours = [];
        resupdate[index].hour.forEach(function (time, i) {
            if (resupdate[index].hour.length > 6) {
                resupdate[index].hours[0] = resupdate[index].hour[1];
                resupdate[index].hours[1] = resupdate[index].hour[5];
                resupdate[index].hours[2] = resupdate[index].hour[6];
                resupdate[index].hours[3] = resupdate[index].hour[4];
                resupdate[index].hours[4] = resupdate[index].hour[0];
                resupdate[index].hours[5] = resupdate[index].hour[2];
                resupdate[index].hours[6] = resupdate[index].hour[3];
            } else {
                resupdate[index].hours = resupdate[index].hour;
            }
        });
    });
    return resupdate;
}


//Home Screen Data for Events
db.findEventstodo = function (data, successCallback, failureCallback) {
    const _ = require("lodash");
    var moment = require("moment");
    pool.query(
        "SELECT events.id,events.title,events.neighbourhood_id,events.url,events.details,events.eventtime,events.start_date,events.location," +
        "to_char(events.start_date::DATE , 'Month DD') AS MONTHS ,events.is_ttod,events.end_date,photos.photo,city.city,city.state," +
        "events.is_feature,array_to_string(array_agg(DISTINCT open_hours.id),',') AS open_hours_id," +
        "array_to_string(array_agg(DISTINCT open_hours.day),',')  AS \"day\"," +
        "array_agg(DISTINCT open_hours.day || ':' || open_hours.hours) AS \"hour\" " +
        "FROM city INNER JOIN neighbourhood ON (city.id = neighbourhood.city_id) " +
        "INNER JOIN events ON (neighbourhood.id = events.neighbourhood_id) " +
        "INNER JOIN open_hours ON (open_hours.event_id=events.id) " +
        "LEFT OUTER JOIN deb_photos ON (deb_photos.events_id=events.id) " +
        "LEFT OUTER JOIN photos ON (photos.id = deb_photos.photo_id)  " +
        "WHERE city.city =$1 AND events.is_ttod=$2 AND is_today=$2 " +
        "GROUP BY  events.id,events.details,events.title, photos.photo, city.city, city.state,events.create_date ORDER BY events.start_date ASC",
        [data["city"], data["is_todo"]],
        (error, results) => {
            results.rows.forEach(function (item, index) {
                results.rows[index].is_feature = null;
                results.rows[index].hours = [];
                results.rows[index].startdate = moment(
                    results.rows[index].start_date
                ).format("MM/DD/YYYY");
                results.rows[index].enddate = moment(
                    results.rows[index].end_date
                ).format("MM/DD/YYYY");

                results.rows[index].hour.forEach(function (time, i) {
                    if (results.rows[index].hour.length > 6) {
                        results.rows[index].hours[0] = results.rows[index].hour[1];
                        results.rows[index].hours[1] = results.rows[index].hour[5];
                        results.rows[index].hours[2] = results.rows[index].hour[6];
                        results.rows[index].hours[3] = results.rows[index].hour[4];
                        results.rows[index].hours[4] = results.rows[index].hour[0];
                        results.rows[index].hours[5] = results.rows[index].hour[2];
                        results.rows[index].hours[6] = results.rows[index].hour[3];
                    } else {
                        results.rows[index].hours = results.rows[index].hour;
                    }
                });
            });

            var groups = _.groupBy(results.rows, function (date) {
                var result = moment(date.start_date).format("dddd, YYYY MMMM DD");
                return result;
            });
            if (results) {
                successCallback(groups);
            } else if (error) {
                failureCallback(error);
            }
        }
    );
};

//evne
db.findEvents = function (data, successCallback, failureCallback) {
    const _ = require("lodash");
    var moment = require("moment");
    pool.query(
        "SELECT events.id,events.title, events.category_name, events.category_url, events.neighbourhood_id,events.url,events.details,events.eventtime,events.start_date," +
        "events.location,to_char(events.start_date::DATE , 'Month DD') AS MONTHS ,events.is_ttod,events.end_date,city.city,city.state," +
        "events.is_feature,array_to_string(array_agg(DISTINCT open_hours.id),',') AS open_hours_id," +
        'json_object(array_agg(photos.type),array_agg(photos.photo)) AS "photos",array_to_string(array_agg( distinct photos."type"),\',\')  AS "type",' +
        "array_to_string(array_agg(DISTINCT open_hours.day),',')  AS \"day\",array_agg(DISTINCT open_hours.day || ':' || open_hours.hours) AS \"hour\" " +
        "FROM city INNER JOIN neighbourhood ON (city.id = neighbourhood.city_id) " +
        "INNER JOIN events ON (neighbourhood.id = events.neighbourhood_id) " +
        "INNER JOIN open_hours ON (open_hours.event_id=events.id) " +
        "Left JOIN deb_photos ON(deb_photos.events_id=events.id) " +
        "JOIN photos ON(deb_photos.photo_id=photos.id) "+
        "WHERE city.city =$1 AND events.is_ttod=$2 " +
        "GROUP BY events.id,events.details,events.title, city.city, city.state,events.create_date ORDER BY events.start_date ASC",
        [data["city"], data["is_todo"]],
        (error, results) => {
            results.rows.forEach(function (item, index) {
                results.rows[index].is_feature = null;
                results.rows[index].hours = [];
                results.rows[index].hour.forEach(function (time, i) {
                    if (results.rows[index].hour.length > 6) {
                        results.rows[index].hours[0] = results.rows[index].hour[1];
                        results.rows[index].hours[1] = results.rows[index].hour[5];
                        results.rows[index].hours[2] = results.rows[index].hour[6];
                        results.rows[index].hours[3] = results.rows[index].hour[4];
                        results.rows[index].hours[4] = results.rows[index].hour[0];
                        results.rows[index].hours[5] = results.rows[index].hour[2];
                        results.rows[index].hours[6] = results.rows[index].hour[3];
                    } else {
                        results.rows[index].hours = results.rows[index].hour;
                    }
                });
            });

            var groups = _.groupBy(results.rows, function (date) {
                var result = moment(date.start_date).format("dddd, YYYY MMMM DD");
                return result;
            });
            if (results) {
                successCallback(groups);
            } else if (error) {
                failureCallback(error);
            }
        }
    );
};

db.findUpcommingEvents = function (data, successCallback, failureCallback) {
    db.findEvents(data, successCallback, failureCallback);
};
//save events
db.saveEvents = function (data, successCallback, failureCallback) {
    pool.query(
        "select * from user_events where user_id=$1 and event_id=$2",
        [data.user_id, data.event_id],
        (error, results) => {
            if (error) {
                failureCallback(error);
            } else if (results.rows.length == 0) {
                const id = uuidv1("");

                pool.query(
                    "INSERT INTO user_events(id, user_id, event_id) VALUES ($1, $2, $3) ",
                    [id, data.user_id, data.event_id],
                    (error, results) => {
                        if (error) {
                            failureCallback(error);
                        } else {
                            successCallback("success");
                        }
                    }
                );
            } else {
                successCallback("You alredy saved it");
            }
        }
    );
};

//archive saved-offers & deals
db.deleteSavedEvents = function (data, successCallback, failureCallback) {
    const userId = data.user_id;
    const eventId = data.event_id;
    console.log('user-id '+userId);
    console.log('event-id '+eventId);
    console.log('updating saved event archive....');

    const findSavedEventsQuery = 'SELECT * FROM user_events where id = $1';
    pool.query(findSavedEventsQuery,[eventId], (error, response) => {
        if (error) {
            console.log('error to fetch SavedEvents');
            failureCallback(error);
        } else {
            console.log('successfully fetched events');
            if(response.rows.length === 0){
                failureCallback('Invalid event id.');
            }else{
                const archiveEventQuery = 'UPDATE user_events SET is_archive = 1 where id = $1';
                pool.query(archiveEventQuery,[eventId], (err, res) => {
                    if (err) {
                        console.log('error to archive savedEvents');
                        failureCallback(error);
                    } else {
                        console.log('successfully update event');
                        console.log(res);
                        successCallback('event successfully archived.');
                    }
                })
            }
        }
    });

};

//get events by id
db.findSavedEventsbyid = function (data, successCallback, failureCallback) {
    pool.query(
        "SELECT events.id, user_events.is_archive, user_events.id AS \"user_event_id\", events.url,events.title,events.neighbourhood_id,events.location,to_char(events.start_date::DATE , 'MONTH DD') AS MONTHS, "
        + "events.end_date,events.start_date,city.city,city.state,events.is_feature,"
        + "json_object(array_agg(photos.type),array_agg(photos.photo)) AS \"photos\",array_to_string(array_agg( distinct photos.\"type\"),\',\')  AS \"type\","
        + "array_to_string(array_agg(DISTINCT open_hours.id),',') AS open_hours_id,"
        + "array_to_string(array_agg(DISTINCT open_hours.day),',')  AS \"day\",array_agg(DISTINCT open_hours.day || ':' || open_hours.hours) AS \"hour\" "
        + "FROM user_events INNER JOIN events on(user_events.event_id=events.id) "
        + "INNER JOIN deb_photos ON (deb_photos.events_id=events.id) "
        + "INNER JOIN photos ON (photos.id = deb_photos.photo_id) "
        + "INNER JOIN  neighbourhood ON (neighbourhood.id = events.neighbourhood_id) "
        + "INNER JOIN  city ON (neighbourhood.city_id = city.id) "
        + "left outer JOIN open_hours ON (open_hours.event_id=events.id) "
        + " WHERE user_events.user_id = $1  "
        + "GROUP BY  events.id, user_events.is_archive, user_events.id, events.title,events.neighbourhood_id,events.location,events.end_date,city.city,city.state,events.is_feature "
        + "ORDER BY events.create_date DESC",
        [data.user_id],
        (error, results) => {

            //filter only non-archived saved deal....
            if(results.rows != null)
                results.rows = results.rows.filter(v => v.is_archive === 0);

            if(results.rows != null)
            results.rows.forEach(function (item, index) {
                results.rows[index].hours = [];
                results.rows[index].hour.forEach(function (time, i) {
                    if (results.rows[index].hour.length > 6) {
                        results.rows[index].hours[0] = results.rows[index].hour[1];
                        results.rows[index].hours[1] = results.rows[index].hour[5];
                        results.rows[index].hours[2] = results.rows[index].hour[6];
                        results.rows[index].hours[3] = results.rows[index].hour[4];
                        results.rows[index].hours[4] = results.rows[index].hour[0];
                        results.rows[index].hours[5] = results.rows[index].hour[2];
                        results.rows[index].hours[6] = results.rows[index].hour[3];
                    } else {
                        results.rows[index].hours = results.rows[index].hour;
                    }
                });
            });
            if (results) {
                successCallback(results.rows);
            } else if (error) {
                failureCallback(error);
            }
        }
    );
};

db.searchEventsForFeature = function (data, successCallback, failureCallback) {
    pool.query(
        "SELECT events.id,events.title, events.url,events.neighbourhood_id,events.location,to_char(events.start_date::DATE , 'MONTH DD') AS MONTHS ," +
        "events.end_date,events.start_date,city.city,city.state,events.is_feature," +
        "array_to_string(array_agg(DISTINCT open_hours.id),',') AS open_hours_id,array_to_string(array_agg(DISTINCT open_hours.day),',')  AS \"day\"," +
        'json_object(array_agg(photos.type),array_agg(photos.photo)) AS "photos",array_to_string(array_agg( distinct photos."type"),\',\')  AS "type",' +
        "array_agg(DISTINCT open_hours.day || ':' || open_hours.hours) AS \"hour\" " +
        "FROM city INNER JOIN neighbourhood ON (city.id = neighbourhood.city_id) " +
        "INNER JOIN events ON (neighbourhood.id = events.neighbourhood_id) " +
        "LEFT outer JOIN open_hours ON (open_hours.event_id=events.id) " +
        "Left JOIN deb_photos ON (deb_photos.events_id=events.id) " +
        "INNER JOIN photos ON(deb_photos.photo_id=photos.id) " +
        "WHERE (events.is_feature=$1 AND city.city = $2 " +
        "AND (events.title iLIKE '%' || $3 || '%' OR events.details iLike '%' || $3 || '%'  OR events.location iLike '%' || $3 || '%'  )) " +
        "GROUP BY  events.id,events.title,events.neighbourhood_id,events.location,events.end_date,city.city,city.state,events.is_feature ORDER BY events.create_date DESC",
        [data.is_feature, data.city, data.name],
        (error, results) => {
            results.rows.forEach(function (item, index) {
                results.rows[index].hours = [];
                results.rows[index].hour.forEach(function (time, i) {
                    if (results.rows[index].hour.length > 6) {
                        results.rows[index].hours[0] = results.rows[index].hour[1];
                        results.rows[index].hours[1] = results.rows[index].hour[5];
                        results.rows[index].hours[2] = results.rows[index].hour[6];
                        results.rows[index].hours[3] = results.rows[index].hour[4];
                        results.rows[index].hours[4] = results.rows[index].hour[0];
                        results.rows[index].hours[5] = results.rows[index].hour[2];
                        results.rows[index].hours[6] = results.rows[index].hour[3];

                        if (results.rows[index].hours[0] == "Monday:By appointment") {
                            results.rows[index].hours = [];
                            results.rows[index].hours[0] = "By appointment";
                        }

                        if (results.rows[index].hours[0] == "Monday:24/7") {
                            results.rows[index].hours = [];
                            results.rows[index].hours[0] = "24/7";
                        }
                    } else {
                        results.rows[index].hours = results.rows[index].hour;
                    }
                });
            });

            if (error) failureCallback(error);
            else successCallback(results.rows);
        }
    );
};
db.searchEventsForTodo = function (data, successCallback, failureCallback) {
    var moment = require("moment");
    pool.query(
        "SELECT events.id,events.title,events.neighbourhood_id,events.start_date,events.location,to_char(events.start_date::DATE , 'Month DD') AS MONTHS ,to_char(events.start_date::DATE , 'Month ') AS MONTH,events.is_ttod,events.end_date,city.city,city.state,events.is_feature,array_to_string(array_agg(DISTINCT open_hours.id),',') AS open_hours_id,array_to_string(array_agg(DISTINCT open_hours.day),',')  AS \"day\",array_agg(DISTINCT open_hours.day || ':' || open_hours.hours) AS \"hour\" FROM city INNER JOIN neighbourhood ON (city.id = neighbourhood.city_id) INNER JOIN events ON (neighbourhood.id = events.neighbourhood_id)INNER JOIN open_hours ON (open_hours.event_id=events.id)  WHERE (events.is_ttod=$1 AND city.city = $2 AND events.title iLIKE '%' || $3 || '%' OR events.details iLike '%' || $4 || '%'  OR events.location iLike '%' || $5 || '%'  )  GROUP BY  events.id,events.details,events.title, city.city, city.state,events.create_date",
        [data.is_todo, data.city, data.name, data.name, data.name],
        (error, results) => {
            results.rows.forEach(function (item, index) {
                results.rows[index].hours = [];
                results.rows[index].hour.forEach(function (time, i) {
                    if (results.rows[index].hour.length > 6) {
                        results.rows[index].hours[0] = results.rows[index].hour[1];
                        results.rows[index].hours[1] = results.rows[index].hour[5];
                        results.rows[index].hours[2] = results.rows[index].hour[6];
                        results.rows[index].hours[3] = results.rows[index].hour[4];
                        results.rows[index].hours[4] = results.rows[index].hour[0];
                        results.rows[index].hours[5] = results.rows[index].hour[2];
                        results.rows[index].hours[6] = results.rows[index].hour[3];

                        if (results.rows[index].hours[0] == "Monday:By appointment") {
                            results.rows[index].hours = [];
                            results.rows[index].hours[0] = "By appointment";
                        }

                        if (results.rows[index].hours[0] == "Monday:24/7") {
                            results.rows[index].hours = [];
                            results.rows[index].hours[0] = "24/7";
                        }
                    } else {
                        results.rows[index].hours = results.rows[index].hour;
                    }
                });
            });
            var monthNames = [
                "January",
                "February",
                "March",
                "April",
                "May",
                "June",
                "July",
                "August",
                "September",
                "October",
                "November",
                "December"
            ];

            var date = new Date();
            var presentMonth = [];
            var currentMonth = monthNames[date.getMonth()];
            for (var i = 0; i < results.rows.length; i++) {
                var premonth = results.rows[i].month.trim();
                if (premonth == currentMonth) {
                    presentMonth.push(results.rows[i]);
                }
            }
            if (error) {
                failureCallback(error);
            } else {
                successCallback(presentMonth);
            }
        }
    );
};

db.businessspotlight = function (data, successCallback, failureCallback) {
    var date = dateData();
    pool.query(
        "select  business.id, business.name,  business.description, business.phone,  business.email,  business.website_url, business.address_line1, " +
        "business.neighbourhood_id, business.zip,  business.lat, business.long, business.create_date, business.geom, business.title, business.body, " +
        "business.is_spotlight, city.city, city.state, " +
        'json_object(array_agg(photos.type),array_agg(photos.photo)) AS "photo",array_to_string(array_agg( distinct photos."type"),\',\')  AS "type" ' +
        "FROM city INNER JOIN neighbourhood ON (city.id = neighbourhood.city_id) " +
        "INNER JOIN business ON (neighbourhood.id = business.neighbourhood_id) " +
        "INNER JOIN deb_photos ON (deb_photos.business_id=business.id) " +
        'INNER JOIN photos ON (photos."id" = deb_photos.photo_id) ' +
        "where business.is_spotlight=$1 AND city.city=$2 GROUP BY business.id, business.name,  business.description, business.phone,  business.email,  " +
        "business.website_url, business.address_line1, business.neighbourhood_id, business.zip,  business.lat, business.long, business.create_date, " +
        "business.geom, business.title, business.body, business.is_spotlight, city.city, city.state ",
        [true, data["city"]],
        (error, result) => {
            console.log(error);
            var isProcessDone = false;
            var count = 1;
            result.rows.forEach(function (item, index) {
                result.rows[index].hasOffers = false;
                var name = result.rows[index].name;
                var city = result.rows[index].city;
                pool.query("select count(*) from business inner join deals ON (business.id = deals.business_id)" +
                    " INNER JOIN neighbourhood ON (neighbourhood.id = business.neighbourhood_id)" +
                    " INNER JOIN city ON (city.id = neighbourhood.city_id) " +
                    " INNER JOIN schedule ON (schedule.deal_id = deals.id)" +
                    "where business.name=$1 and city=$2 and " + date + "= $3",
                    [name, city, true], (error, offers) => {
                        result.rows[index].hasOffers = offers.rows[0].count != '0' ? true : false;
                        isProcessDone = count == result.rows.length ? true : false;
                        if (isProcessDone) {
                            if (error) failureCallback(error);
                            else successCallback(result.rows);
                        }
                        count++;
                    });
            });
        }
    );
};


module.exports = db;
