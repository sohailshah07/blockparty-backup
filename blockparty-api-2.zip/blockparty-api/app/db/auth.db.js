'use strict';
var crypt = require('../crypt');
var config = require('../../config/main');
var db = {};
var pjson = require('../../package.json');
const uuidv1 = require('uuid/v1');

const Pool = require('pg').Pool;
const pool = new Pool({
	user: config.user,
	host: config.host,
	database: config.database,
	password: config.password,
	port: config.pg_port,
});
var moment = require('moment-timezone');

function dateData() {
	var today = new Date().getDay().toLocaleString('en-US', {
		timeZone: 'America/Denver',
	});
	if (today == 0) var presentDay = 'schedule.sunday';
	if (today == 1) var presentDay = 'schedule.monday';
	if (today == 2) var presentDay = 'schedule.tuesday';
	if (today == 3) var presentDay = 'schedule.wednesday';
	if (today == 4) var presentDay = 'schedule.thursday';
	if (today == 5) var presentDay = 'schedule.friday';
	if (today == 6) var presentDay = 'schedule.saturday';

	return presentDay;
}

function currentData() {
	var today = new Date();
	var date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
	return date;
}

function formatDate(date) {
	var d = new Date(date),
		month = '' + (d.getMonth() + 1),
		day = '' + d.getDate(),
		year = d.getFullYear();

	if (month.length < 2) month = '0' + month;
	if (day.length < 2) day = '0' + day;

	return [year, month, day].join('-');
}

pool.query('SELECT * FROM users', (error, result) => {
	if (result) console.log('Connected to PG');
	else console.log('Connection error : ' + error);
});

db.findOneOrcreate = function (user, successCallback, failureCallback) {
	pool.query('SELECT * FROM users WHERE email = $1', [user.email], (error, results) => {
		if (error) {
			failureCallback(error);
		} else if (results.rowCount == 1) {
			crypt.createHash(
				user.password,
				function (passwordHash) {
					pool.query(
						'UPDATE users SET password=($1) WHERE id=($2)',
						[passwordHash, results.rows[0].id],
						(error, updatedresults) => {
							if (results) {
								pool.query(
									'SELECT * FROM users WHERE email = $1',
									[user.email],
									(error, results) => {
										if (results) successCallback(results.rows[0]);

										if (error) failureCallback(error);
									}
								);
							} else if (error) {
								failureCallback(error);
							}
						}
					);
				},
				function (err) {
					failureCallback();
				}
			);
		} else if (results.rowCount == 0) {
			successCallback({
				isUserExist: false,
			});
		} else {
			failureCallback('Authentication failed. User not found.');
		}
	});
};

// find a user
db.findOneUser = function (user, successCallback, failureCallback) {
	pool.query(
		'SELECT * FROM users WHERE LOWER(email) = LOWER($1)',
		[user.email],
		(error, results) => {
			if (error) {
				failureCallback(error);
			} else if (results.rowCount == 1) {
				successCallback(results.rows[0]);
			} else {
				failureCallback('Authentication failed. User not found.');
			}
		}
	);
};

// // find a user
// db.findOneUserById = function (user, successCallback, failureCallback) {
// 	console.log('Inside DB file - findOneUserById');
// 	pool.query('SELECT * FROM users WHERE id = $1', [user.id], (error, results) => {
// 		if (error) {
// 			failureCallback(error);
// 		} else if (results.rowCount == 1) {
// 			successCallback(results.rows[0]);
// 		} else {
// 			failureCallback('User not found.');
// 		}
// 	});
// };

//find referral code
db.findReferralCode = function (data, successCallback, failureCallback) {
	pool.query('Select * from business where referral=$1', [data.referral_code], (error, result) => {
		if (error) {
			failureCallback(error);
		} else if (result.rowCount == 1) {
			successCallback(result.rows[0]);
		} else {
			failureCallback('no match');
		}
	});
};

//Update the refferral code
db.updateReferralCode = function (data, successCallback, failureCallback) {
	pool.query(
		'update users set referral=$1 where email=$2',
		[data.referral_code, data.email],
		(error, result) => {
			if (error) {
				failureCallback(error);
			} else {
				successCallback(result);
			}
		}
	);
};

// find API version
db.fetchApiVersion = function (version, successCallback, failureCallback) {
	successCallback(pjson.api_build_no);
};

//Insert a user
db.createUser = function (user, successCallback, failureCallback) {
	var neighbourhood_id;
	pool.query('SELECT id FROM city where city = $1', [user.location], function (err, result) {
		if (err) {
		}

		pool.query('SELECT id FROM neighbourhood where city_id = $1', [result.rows[0].id], function (
			err,
			result
		) {
			if (err) {
			}

			if (result.rows[0]) {
				neighbourhood_id = result.rows[0].id;
			}

			crypt.createHash(
				user.password,
				function (passwordHash) {
					const id = uuidv1('');

					pool.query(
						'INSERT INTO users (id, email, password, first_name, last_name, avatar, location, age_range, gender, home_type, move_planned, is_admin, timezone, update_date, neighbourhood_id,referral) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15,$16)',
						[
							id,
							user.email,
							passwordHash,
							user.first_name,
							user.last_name,
							user.avatar,
							user.location,
							user.age_range,
							user.gender,
							user.home_type,
							user.move_planned,
							user.is_admin,
							user.timezone,
							user.update_date,
							neighbourhood_id,
							user.referral_code,
						],
						(error, results) => {
							if (error) {
								failureCallback(error);
								return;
							}

							if (results) {
								successCallback();
							} else {
								failureCallback('User not found.');
							}
						}
					);
				},
				function (err) {
					failureCallback();
				}
			);
		});
	});
};

//find user by email
db.findUserEmail = function (user, successCallback, failureCallback) {
	pool.query('SELECT * FROM users WHERE email =$1  ', [user.email], (error, results) => {
		if (error) {
			failureCallback(error);
		} else if (results.rowCount == 1) {
			successCallback(results.rows[0]);
		} else {
			failureCallback('User not found');
		}
	});
};

db.resetPassword = function (data, successCallback, failureCallback) {
	crypt.createHash(data.newPassword, function (passwordHash) {
		pool.query(
			'UPDATE users SET password=$1 WHERE email=$2',
			[passwordHash, data.email],
			(error, results) => {
				if (results) {
					successCallback('password changed');
				} else if (error) {
					failureCallback('password not changed');
				}
			}
		);
	});
};
db.newPassword = function (data, successCallback, failureCallback) {
	crypt.createHash(data.newPassword, function (passwordHash) {
		pool.query(
			'UPDATE users SET password =$1 WHERE email=$2',
			[passwordHash, data.email],
			(error, results) => {
				if (results) {
					successCallback('password changed');
				} else if (error) {
					failureCallback('password not changed');
				}
			}
		);
	});
};
db.updateProfile = function (data, successCallback, failureCallback) {
	pool.query(
		'UPDATE users SET first_name= $1, last_name =$2 WHERE id=$3 ',
		[data.first_name, data.last_name, data.id],
		(error, results) => {
			if (results) {
				successCallback('data updated');
			} else if (error) {
				failureCallback('data not changed');
			}
		}
	);
};
db.updateProfileImage = function (data, successCallback, failureCallback) {
	pool.query(
		'UPDATE users SET first_name= $1, last_name =$2 , email=$3 ,avatar=$4 WHERE id=$5 ',
		[data.first_name, data.last_name, data.email, data.avatar, data.id],
		(error, results) => {
			if (results) {
				successCallback('data updated');
			} else if (error) {
				failureCallback('data not changed');
			}
		}
	);
};

db.updateOrAddUserFromAppleSignIn = function (data, successCallback, failureCallback) {
	pool.query('SELECT email FROM users WHERE email = $1', [data.email], (error, results) => {
		if (results.rows[0]) {
			pool.query(
				'UPDATE users SET apple_user_token = $1 WHERE email = $2',
				[data.userToken, data.email],
				(err, result) => {
					if (result) {
						pool.query('SELECT * FROM users WHERE email = $1', [data.email], (errs, user) => {
							if (user) {
								successCallback(user.rows[0]);
							} else if (errs) {
								failureCallback(errs);
							}
						});
					} else if (error) {
						failureCallback('Data is not Changed');
					}
				}
			);
		} else {
			const id = uuidv1();
			pool.query(
				'INSERT INTO users (id, email, apple_user_token, first_name, last_name, password, location) VALUES ($1, $2, $3, $4, $5, $6, $7)',
				[id, data.email, data.userToken, data.firstName, data.lastName, data.password, 'Parker'],
				(error, result) => {
					if (result) {
						pool.query('SELECT * FROM users WHERE email = $1', [data.email], (errs, user) => {
							if (user) {
								successCallback(user.rows[0]);
							} else if (errs) {
								failureCallback(errs);
							}
						});
					} else if (error) {
						failureCallback('Data is not Inserted');
					}
				}
			);
		}
	});
};
//
db.getUserDetails = function (data, successCallback, failureCallback) {
	pool.query(
		'SELECT * FROM users WHERE apple_user_token = $1',
		[data.userToken],
		(error, results) => {
			if (results) {
				successCallback(results.rows[0]);
			} else {
				failureCallback('Data is not Present');
			}
		}
	);
};

module.exports = db;
