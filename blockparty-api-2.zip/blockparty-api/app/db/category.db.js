'use strict';
var crypt = require('../crypt');
var config = require('../../config/main');
var db = {};
const uuidv1 = require('uuid/v1');

const Pool = require('pg').Pool;
const pool = new Pool({
    user: config.user,
    host: config.host,
    database: config.database,
    password: config.password,
    port: config.pg_port,
});
var moment = require('moment-timezone');

function dateData() {
    var today = new Date().getDay().toLocaleString('en-US', {
        timeZone: 'America/Denver',
    });
    if (today == 0) var presentDay = 'schedule.sunday';
    if (today == 1) var presentDay = 'schedule.monday';
    if (today == 2) var presentDay = 'schedule.tuesday';
    if (today == 3) var presentDay = 'schedule.wednesday';
    if (today == 4) var presentDay = 'schedule.thursday';
    if (today == 5) var presentDay = 'schedule.friday';
    if (today == 6) var presentDay = 'schedule.saturday';

    return presentDay;
}

function currentData() {
    var today = new Date();
    var date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
    return date;
}

function formatDate(date) {
    var d = new Date(date),
        month = '' + (d.getMonth() + 1),
        day = '' + d.getDate(),
        year = d.getFullYear();

    if (month.length < 2) month = '0' + month;
    if (day.length < 2) day = '0' + day;

    return [year, month, day].join('-');
}

pool.query('SELECT * FROM users', (error, result) => {
    if (result) console.log('Connected to PG');
    else console.log('Connection error : ' + error);
});

//findCategories
db.findCategories = function (categorie, successCallback, failureCallback) {
    pool.query('SELECT * FROM categories order by serial_num asc', (error, results) => {
        if (error) failureCallback(error);
        else successCallback(results.rows);
    });
};

//find categories by location
db.findCategoriesBylocation = function (location, successCallback, failureCallback) {
    const query = `SELECT * FROM categories WHERE location = '${location}' OR "location" IS NULL order by serial_num asc`;
    pool.query(query, (error, results) => {
        if (error) failureCallback(error);
        else successCallback(results.rows);
    });
};

db.findCategoriesId = function (categoryname, successCallback, failureCallback) {
    var date = dateData();
    var setquery =
        'select * from (select t3.id,t3.pinned, t3.title, t3.details,t3.url,t3.business_id,t3.expiry_date,t4.phone, t4.email,  t4.lat, t4.long, t4.website_url,t4.address_line1, ' +
        't4.zip, t4.description,t4.city_name as "city", t4.state,array_to_string(array_agg(distinct t4.name),\',\') AS "name",array_to_string(array_agg(distinct t7."day"),\',\')  AS "day",' +
        'array_agg(distinct  t7.day || \':\' || t7.hours  )  AS "hour" ,array_to_string(array_agg(  distinct t9."type"),\',\')  AS "type",' +
        't3.redeem_code,json_object(array_agg(t9.type),array_agg(t9.photo)) AS "photo",t4.city_name AS "city1", ' +
        't3.redeems_allowed, redeems.redeem_count as user_redeem_count,redeems.user_id ' +
        'from categories t1 inner join deb_categories t2 on t1.id = t2.category_id ' +
        'inner join deals t3 on t2.deal_id = t3.id ' +
        'inner join business t4 on t3.business_id = t4.id ' +
        'inner join neighbourhood t5 on t4.neighbourhood_id=t5.id ' +
        'inner join open_hours t7 on t7.business_id=t4.id ' +
        'inner join city t6 on t5.city_id=t6.id ' +
        'inner join deb_photos t8 on t8.deals_id= t3.id ' +
        'inner join photos t9 on t8.photo_id = t9."id" ' +
        'INNER JOIN schedule ON (schedule.deal_id = t3.id) ' +
        'left outer JOIN redeems ON (redeems.deal_id = t3.id and redeems.user_id=$3) ' +
        'where (t1.categories=$1 AND t6.city=$2 AND t3.pinned = 0) ' +
        'GROUP BY  t3.id,t3.pinned,t3.details,t3.url,t3.title,t3.expiry_date,t4.lat,t4.long,t4.phone,t4.website_url,t4.address_line1,t4.zip,t4.email, t4.description,t6.city, ' +
        't4.state,t3.create_date,t3.business_id,t4.city_name, redeems.user_id,redeems.redeem_count ' +
        'UNION ALL ' +
        'select t3.id,t3.pinned, t3.title, t3.details,t3.url,t3.business_id,t3.expiry_date,t4.phone, t4.email,  t4.lat, t4.long, t4.website_url,t4.address_line1, t4.zip, ' +
        't4.description,t6.city, t4.state,array_to_string(array_agg(distinct t4.name),\',\') AS "name",array_to_string(array_agg(distinct t7."day"),\',\')  AS "day",' +
        'array_agg(distinct  t7.day || \':\' || t7.hours  )  AS "hour" ,array_to_string(array_agg(  distinct t9."type"),\',\')  AS "type",' +
        't3.redeem_code,json_object(array_agg(t9.type),array_agg(t9.photo)) AS "photo",t4.city_name AS "city1", ' +
        't3.redeems_allowed, redeems.redeem_count as user_redeem_count,redeems.user_id ' +
        'from categories t1 inner join deb_categories t2 on t1.id = t2.category_id ' +
        'inner join deals t3 on t2.deal_id = t3.id ' +
        'inner join business t4 on t3.business_id = t4.id ' +
        'inner join business_cities t10  on t4.id=t10.business_id ' +
        'inner join neighbourhood t5 on t4.neighbourhood_id=t5.id ' +
        'inner join open_hours t7 on t7.business_id=t4.id ' +
        'inner join city t6 on t5.city_id=t6.id ' +
        'inner join deb_photos t8 on t8.deals_id= t3.id ' +
        'inner join photos t9 on t8.photo_id = t9."id" ' +
        'INNER JOIN schedule ON (schedule.deal_id = t3.id) ' +
        'left outer JOIN redeems ON (redeems.deal_id = t3.id and redeems.user_id=$3) where (t1.categories=$1 AND t10.additional_location=$2 AND t3.pinned = 0)' +
        'GROUP BY  t3.id,t3.pinned,t3.details,t3.url,t3.title,t3.expiry_date,t4.lat,t4.long,t4.phone,t4.website_url,t4.address_line1,t4.zip,t4.email, t4.description,t6.city, t4.state,t3.create_date,t3.business_id,t4.city_name, redeems.user_id,redeems.redeem_count ) tt ORDER BY RANDOM()';
    pool.query(
        setquery,
        [categoryname.str, categoryname.city, categoryname.user_id],
        (error, results) => {
            var arr = [],
                resarr = [];
            results.rows.forEach(function (item, index) {
                if (!arr.includes(results.rows[index].name.toLowerCase())) {
                    resarr.push(results.rows[index]);
                    arr.push(results.rows[index].name.toLowerCase());
                }
                results.rows[index].hours = [];
                results.rows[index].hour.forEach(function (time, i) {
                    if (results.rows[index].hour.length < 2) {
                        results.rows[index].hours[0] = results.rows[index].hour[0];
                    }
                    if (results.rows[index].hour.length > 6) {
                        results.rows[index].hours[0] = results.rows[index].hour[1];
                        results.rows[index].hours[1] = results.rows[index].hour[5];
                        results.rows[index].hours[2] = results.rows[index].hour[6];
                        results.rows[index].hours[3] = results.rows[index].hour[4];
                        results.rows[index].hours[4] = results.rows[index].hour[0];
                        results.rows[index].hours[5] = results.rows[index].hour[2];
                        results.rows[index].hours[6] = results.rows[index].hour[3];

                        if (
                            results.rows[index].hours[0] == 'Monday:By appointment' &&
                            results.rows[index].hours[1] == 'Tuesday:By appointment' &&
                            results.rows[index].hours[2] == 'Wednesday:By appointment' &&
                            results.rows[index].hours[3] == 'Thursday:By appointment'
                        ) {
                            results.rows[index].hours = [];
                            results.rows[index].hours[0] = 'By appointment';
                        }

                        if (
                            results.rows[index].hours[0] == 'Monday:Opening in October 2019' &&
                            results.rows[index].hours[1] == 'Tuesday:Opening in October 2019' &&
                            results.rows[index].hours[2] == 'Wednesday:Opening in October 2019' &&
                            results.rows[index].hours[3] == 'Thursday:Opening in October 2019'
                        ) {
                            results.rows[index].hours = [];
                            results.rows[index].hours[0] = 'Opening in October 2019';
                        }

                        if (
                            results.rows[index].hours[0] == 'Monday:24/7' &&
                            results.rows[index].hours[1] == 'Tuesday:24/7' &&
                            results.rows[index].hours[2] == 'Wednesday:24/7'
                        ) {
                            results.rows[index].hours = [];

                            results.rows[index].hours[0] = '24/7';
                        }
                    } else {
                        for (var hr = 0; hr < results.rows[index].hour.length; hr++) {
                            if (results.rows[index].hour[hr].includes('Monday')) {
                                results.rows[index].hours[0] = results.rows[index].hour[hr];
                            } else if (results.rows[index].hour[hr].includes('Tuesday')) {
                                results.rows[index].hours[1] = results.rows[index].hour[hr];
                            } else if (results.rows[index].hour[hr].includes('Wednesday')) {
                                results.rows[index].hours[2] = results.rows[index].hour[hr];
                            } else if (results.rows[index].hour[hr].includes('Thursday')) {
                                results.rows[index].hours[3] = results.rows[index].hour[hr];
                            } else if (results.rows[index].hour[hr].includes('Friday')) {
                                results.rows[index].hours[4] = results.rows[index].hour[hr];
                            } else if (results.rows[index].hour[hr].includes('Saturday')) {
                                results.rows[index].hours[5] = results.rows[index].hour[hr];
                            } else if (results.rows[index].hour[hr].includes('Sunday')) {
                                results.rows[index].hours[6] = results.rows[index].hour[hr];
                            }
                        }
                    }
                });
                results.rows[index].hours = results.rows[index].hours.filter((v) => v != null);
            });

            if (error) failureCallback(error);
            else successCallback(resarr);
        }
    );
};
db.findCategoriesIdall = function (data, successCallback, failureCallback) {
    var date = dateData();
    var setquery =
        'select t3.id, t3.title,t3.is_feature, t3.details,t3.url,t3.business_id,t3.expiry_date,t4.phone, t4.email,  t4.lat, t4.long, t4.website_url,t4.address_line1, t4.zip, t4.description,t4.city_name as "city", t4.state,array_to_string(array_agg(distinct t4.name),\',\') AS "name",array_to_string(array_agg(distinct t7."day"),\',\')  AS "day",array_agg(distinct  t7.day || \':\' || t7.hours  )  AS "hour" ,array_to_string(array_agg(  distinct t9."type"),\',\')  AS "type",json_object(array_agg(t9.type),array_agg(t9.photo)) AS "photo" from categories t1 inner join deb_categories t2 on t1.id = t2.category_id inner join deals t3 on t2.deal_id = t3.id inner join business t4 on t3.business_id = t4.id inner join neighbourhood t5 on t4.neighbourhood_id=t5.id inner join open_hours t7 on t7.business_id=t4.id inner join city t6 on t5.city_id=t6.id inner join deb_photos t8 on t8.deals_id= t3.id inner join photos t9 on t8.photo_id = t9."id" INNER JOIN schedule ON (schedule.deal_id = t3.id) where (t1.categories=$1 AND t3.is_feature=$2 AND t6.city=$3 AND ' +
        date +
        '= $4) GROUP BY  t3.id,t3.details,t3.url,t3.title,t3.expiry_date,t4.lat,t4.long,t4.phone,t4.website_url,t4.address_line1,t4.zip,t4.email, t4.description,t6.city, t4.state,t3.create_date,t3.business_id,t3.is_feature';
    pool.query(setquery, [data.cat, data.is_feature, data.city, true], (error, results) => {
        results.rows.forEach(function (item, index) {
            results.rows[index].hours = [];
            results.rows[index].hour.forEach(function (time, i) {
                if (results.rows[index].hour.length > 6) {
                    results.rows[index].hours[0] = results.rows[index].hour[1];
                    results.rows[index].hours[1] = results.rows[index].hour[5];
                    results.rows[index].hours[2] = results.rows[index].hour[6];
                    results.rows[index].hours[3] = results.rows[index].hour[4];
                    results.rows[index].hours[4] = results.rows[index].hour[0];
                    results.rows[index].hours[5] = results.rows[index].hour[2];
                    results.rows[index].hours[6] = results.rows[index].hour[3];

                    if (
                        results.rows[index].hours[0] == 'Monday:By appointment' &&
                        results.rows[index].hours[1] == 'Tuesday:By appointment' &&
                        results.rows[index].hours[2] == 'Wednesday:By appointment' &&
                        results.rows[index].hours[3] == 'Thursday:By appointment'
                    ) {
                        results.rows[index].hours = [];
                        results.rows[index].hours[0] = 'By appointment';
                    }

                    if (
                        results.rows[index].hours[0] == 'Monday:Opening in October 2019' &&
                        results.rows[index].hours[1] == 'Tuesday:Opening in October 2019' &&
                        results.rows[index].hours[2] == 'Wednesday:Opening in October 2019' &&
                        results.rows[index].hours[3] == 'Thursday:Opening in October 2019'
                    ) {
                        results.rows[index].hours = [];
                        results.rows[index].hours[0] = 'Opening in October 2019';
                    }

                    if (
                        results.rows[index].hours[0] == 'Monday:24/7' &&
                        results.rows[index].hours[1] == 'Tuesday:24/7' &&
                        results.rows[index].hours[2] == 'Wednesday:24/7'
                    ) {
                        results.rows[index].hours = [];

                        results.rows[index].hours[0] = '24/7';
                    }
                } else {
                    for (var hr = 0; hr < results.rows[index].hour.length; hr++) {
                        if (results.rows[index].hour[hr].includes('Monday')) {
                            results.rows[index].hours[0] = results.rows[index].hour[hr];
                        } else if (results.rows[index].hour[hr].includes('Tuesday')) {
                            results.rows[index].hours[1] = results.rows[index].hour[hr];
                        } else if (results.rows[index].hour[hr].includes('Wednesday')) {
                            results.rows[index].hours[2] = results.rows[index].hour[hr];
                        } else if (results.rows[index].hour[hr].includes('Thursday')) {
                            results.rows[index].hours[3] = results.rows[index].hour[hr];
                        } else if (results.rows[index].hour[hr].includes('Friday')) {
                            results.rows[index].hours[4] = results.rows[index].hour[hr];
                        } else if (results.rows[index].hour[hr].includes('Saturday')) {
                            results.rows[index].hours[5] = results.rows[index].hour[hr];
                        } else if (results.rows[index].hour[hr].includes('Sunday')) {
                            results.rows[index].hours[6] = results.rows[index].hour[hr];
                        }
                    }
                }
            });
            results.rows[index].hours = results.rows[index].hours.filter((v) => v != null);
        });

        if (error) failureCallback(error);
        else successCallback(results.rows);
    });
};

module.exports = db;
