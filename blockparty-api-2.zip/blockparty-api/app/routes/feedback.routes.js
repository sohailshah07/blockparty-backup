const express = require('express');
const FeedbackController = require('../controllers/feedback.controller'),
    feedbackController = new FeedbackController();
const router = express.Router();

router.post('/', (req, res) => feedbackController.addFeedback(req, res));

module.exports = router;
