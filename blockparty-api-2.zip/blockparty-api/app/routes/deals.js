'use strict'
// Import dependencies
var passport = require('passport');
var express = require('express');

var db = require('../db/deals.db');
var categorydb = require('../db/category.db');
// Set up middleware
var requireAuth = passport.authenticate('jwt', {
    session: false
});


module.exports = function (app) {
    // API Route Section

    app.use(passport.initialize());

    // Bring in defined Passport Strategy
    require('../../config/passport')(passport);


    // Create API group routes
    var apiRoutes = express.Router();

    passport.serializeUser(function (user, done) {
        done(null, user);
    });

    passport.deserializeUser(function (obj, done) {
        done(null, obj);
    });

    apiRoutes.post('/api/auth/deals', requireAuth, function (request, response) {
        var is_feature = request.body.is_feature
        var categories = request.body.category
        console.log('category: '+categories);
        if (!request.body.category) {
            categories = null
        }
        if (is_feature) {
            db.findDeals({
                city: request.body.city,
                is_featured: 't',
                user_id: request.body.user_id
            }, function (res) {
                response.header('data', 'data');
                response.send({
                    "data": res
                });
            });
        } else {
            if (categories != null) {

                var str = categories.replace(/'/g, "");
                console.log('category str: '+categories);
                categorydb.findCategoriesId({
                    str,
                    city: request.body.city,
                    user_id: request.body.user_id
                }, function (res) {
                    response.header('data', 'data');
                    response.send({
                        "data": res
                    });
                });
            } else {
                db.simpleDeals({
                    city: request.body.city,
                    is_featured: 'f'
                }, function (res) {
                    response.header('data', 'data');
                    response.send({
                        "data": res
                    });
                });
            }
        }
    });
    apiRoutes.get('/api/auth/getSaveDeals', requireAuth, function (request, response) {
        db.findSavedDealsbyid({
            user_id: request.query.id
        }, function (res) {
            response.header('data', 'data');
            response.send({
                "data": res
            });
        });
    });

    apiRoutes.get('/api/auth/getRedeemDeals', requireAuth, function (request, response) {
        db.findRedeembyid({
            user_id: request.query.id
        }, function (res) {
            response.header('data', 'data');
            response.send({
                "data": res
            });
        });
    });

    //save deals
    apiRoutes.post('/api/auth/saveDeals', requireAuth, function (request, response) {
        if (request.body.id != null && (request.query.id == request.user.id)) {
            db.saveDeals({
                deals_id: request.body.id,
                user_id: request.query.id
            }, function (res) {
                response.header('data', 'data');
                response.send({
                    "data": res
                });
            });
        } else {
            response.status(404).json({
                success: false,
                message: "Can't save deals"
            });
        }
    });

    //delete saved offers
    apiRoutes.delete('/api/auth/deleteOffers', requireAuth,  (request, response) => {
        if  (request.query.user_id === request.user.id) {
            db.deleteSavedOffers({
                user_id: request.query.user_id,
                offer_id:request.query.offer_id
            }, function (res) {
                response.header('data', 'data');
                response.send({
                    "data": res
                });
            },function (err) {
                response.header('data', 'data');
                response.status(404);
                response.send({
                    "data": err
                });
            });
        } else {
            response.status(404).json({
                success: false,
                message: "Can't delete offers"
            });
        }
    });

    //delete redeem
    apiRoutes.delete('/api/auth/deleteRedeems', requireAuth,  (request, response) => {
        if  (request.query.user_id === request.user.id) {
            db.deleteRedeems({
                user_id: request.query.user_id,
                redeem_id:request.query.redeem_id
            }, function (res) {
                response.header('data', 'data');
                response.send({
                    "data": res
                });
            },function (err) {
                response.header('data', 'data');
                response.status(404);
                response.send({
                    "data": err
                });
            });
        } else {
            response.status(404).json({
                success: false,
                message: "Can't delete redeem"
            });
        }
    });

    apiRoutes.post('/api/deals', function (request, response) {
        var is_feature = request.body.is_feature
        var categories = request.body.category
        var city = request.body.city
        if (!request.body.category) {
            categories = null
        }
        if (is_feature && !categories) {
            db.findDeals({
                city: request.body.city,
                is_featured: 't'
            }, function (res) {
                response.header('data', 'data');
                response.send({
                    "data": res
                });
            });
        } else {
            if (categories != null) {
                if (categories && (is_feature != null)) {
                    console.log('###1')
                    var cat = categories.replace(/'/g, "");
                    categorydb.findCategoriesIdall({
                        cat,
                        is_feature,
                        city
                    }, function (res) {
                        response.header('data', 'data');
                        response.send({
                            "data": res
                        });
                    });
                } else {
                    console.log('###2')
                    var str = categories.replace(/'/g, "");
                    categorydb.findCategoriesId(str, function (res) {
                        response.header('data', 'data');
                        response.send({
                            "data": res
                        });
                    });
                }
            } else {
                db.simpleDeals({
                    city: request.body.city,
                    is_featured: 'f'
                }, function (res) {
                    response.header('data', 'data');
                    response.send({
                        "data": res
                    });
                });
            }
        }
    });

    apiRoutes.post('/api/auth/location', requireAuth, function (request, response) {
        if (request.query.city != null) {
            db.locationDeals({
                city: request.query.city,
                is_featured: request.query.is_featured,
                user_id: request.query.user_id
            }, function (res, error) {
                response.header('data', 'data');
                response.send({
                    "data": res
                });
            });
        } else {
            response.send("No city")
        }
    });

    apiRoutes.post('/api/auth/redeemDeals', function (request, response) {
        if (request.body.id != null) {
            db.redeemDeals({
                deals_id: request.body.id,
                user_id: request.query.id
            }, function (res) {
                response.header('data', 'data');
                response.send({
                    "data": res
                });
            });
        } else {
            response.send("no redeem deals")
        }
    });

    apiRoutes.get('/api/search', function (request, response) {
        var deal = request.query.deal
        var str = deal.replace(/  +/g, ' ').trimLeft()
        if (request.query.deal != null && request.query.deal != "") {
            db.searchDeals({
                city: request.query.city,
                name: str,
                user_id: request.query.user_id
            }, function (res) {
                response.header('data', 'data');
                response.send({
                    "data": res
                })
            });
        } else {
            response.status(404).json({
                success: false,
                message: "Enter a valid data"
            })
        }
    });
    apiRoutes.post('/api/auth/hotDeals', requireAuth, function (request, response) {

        var is_hot_deals = request.query.is_hot_deals
        var is_feature = request.query.is_feature
        //var category=request.body.categories
        if (!is_hot_deals || !is_feature) {
            response.status(404).json({
                success: false,
                message: "Enter a valid data"
            })
        } else {
            if (is_feature && is_hot_deals) {
                db.hotDeals({
                    city: request.query.city,
                    is_hot_deals: is_hot_deals,
                    is_feature: is_feature
                }, function (res) {
                    response.header('data', 'data');
                    response.send({
                        "data": res
                    })
                });
            } else {
                if (is_hot_deals) {
                    db.hotDeals({
                        city: request.query.city,
                        is_hot_deals: is_hot_deals,
                        is_feature: is_feature
                    }, function (res) {
                        response.header('data', 'data');
                        response.send({
                            "data": res
                        })
                    });
                }


            }


        }

    })
    //search for hot_deals data
    apiRoutes.get('/api/hotDealsSearch', function (request, response) {
        var deal = request.query.hotDeal
        var is_feature = request.query.is_feature
        var is_hot_deal = request.query.is_hot_deal
        var str = deal.replace(/  +/g, ' ').trimLeft().trimRight()
        if (!deal || !is_feature || !is_hot_deal) {
            response.send("enter data")

        } else {
            if (is_feature && is_hot_deal && deal) {
                db.hotDealsSearch({
                    city: request.query.city,
                    is_hot_deal: is_hot_deal,
                    is_feature: is_feature,
                    name: str
                }, function (res) {
                    response.header('data', 'data');
                    response.send({
                        "data": res
                    })
                });
            } else {
                response.status(404).json({
                    success: false,
                    message: "Enter a valid data"
                })
            }

        }

    })
//multi deals display for business
    apiRoutes.get('/api/multiDeals', function (request, response) {
        db.multiDeals({
            id: request.query.id,
            is_hot_deals: request.query.is_hot_deals,
            user_id: request.query.user_id
        }, function (res) {
            response.header('data', 'data');
            response.send({
                "data": res
            });
        });
    })

    apiRoutes.get('/api/auth/deals/special', function (request, response) {
        var city = "";
        var userId = "";
        if (request.query.city) {
            city = request.query.city;
        } else {
            city = 'Parker';
        }
        userId = request.query.user_id;

        db.findDealsSpecial({
            city: city,
            user_id: userId,
            is_featured: 'true'
        }, function (res) {
            response.header('data', 'data');
            response.send({
                success: true,
                "data": res
            });
        });
    });


    // Set url for API group routes
    app.use('', apiRoutes);
};
