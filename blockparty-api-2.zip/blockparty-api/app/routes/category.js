'use strict';
// Import dependencies
const passport = require('passport');
const express = require('express');
const HttpCodes = require('http-status-codes');
var db = require('../db/category.db');

module.exports = function (app) {
    // API Route Section

    app.use(passport.initialize());

    // Bring in defined Passport Strategy
    require('../../config/passport')(passport);

    // Create API group routes
    var apiRoutes = express.Router();

    passport.serializeUser(function (user, done) {
        done(null, user);
    });

    passport.deserializeUser(function (obj, done) {
        done(null, obj);
    });

    apiRoutes.get(
        '/api/categories',
        function (request, response) {
            db.findCategories(
                {},
                function (categories) {
                    response.header('data', 'data');
                    response.header('count', categories.length);
                    var rendres = {};
                    response.send({
                        data: categories,
                    });
                },
                function (err) {
                    response.status(404).json({
                        success: false,
                        message: err,
                    });
                }
            );
        },
        function (err) {
            response.status(401).json({
                success: false,
                message: err,
            });
        }
    );

    apiRoutes.get(
        '/api/categories/:location',
        function (request, response) {
            const {location} = request.params;
            db.findCategoriesBylocation(
                location,
                function (categories) {
                    response.header('data', 'data');
                    response.header('count', categories.length);
                    var rendres = {};
                    response.send({
                        data: categories,
                    });
                },
                function (err) {
                    response.status(HttpCodes.NOT_FOUND).json({
                        success: false,
                        message: err,
                    });
                }
            );
        },
        function (err) {
            response.status(HttpCodes.UNAUTHORIZED).json({
                success: false,
                message: err,
            });
        }
    );

    // Set url for API group routes
    app.use('', apiRoutes);
};
