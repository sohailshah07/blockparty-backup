'use strict'
// Import dependencies
var passport = require('passport');
var express = require('express');
var config = require('../../config/main');
var jwt = require('jsonwebtoken');
var crypt = require('../crypt');
var db = require('../db/auth.db');
const HttpCodes = require('http-status-codes');

// Set up middleware
var requireAuth = passport.authenticate('jwt', {
    session: false
});
// Export the routes for our app to use

var facebookDATA = '';
var facebookProfile;
var profile;
var FacebookTokenStrategy = require('passport-facebook-token');
//mamamama


module.exports = function (app) {
    // API Route Section

    app.use(passport.initialize());

    // Bring in defined Passport Strategy
    require('../../config/passport')(passport);

    // Create API group routes
    var apiRoutes = express.Router();

    passport.serializeUser(function (user, done) {
        done(null, user);
    });

    passport.deserializeUser(function (obj, done) {
        done(null, obj);
    });

    passport.use(new FacebookTokenStrategy({
            clientID: config.clientID,
            clientSecret: config.clientSecret
        },
        function (accessToken, refreshToken, profile, done) {
            facebookProfile = profile;
            process.nextTick(function () {
                return done(null, profile);
            });
        }));

    apiRoutes.post('/api/auth/facebook', passport.authenticate('facebook-token'), function (req, res) {
        db.findOneOrcreate({
            email: facebookProfile._json.email,
            first_name: facebookProfile._json.first_name,
            last_name: facebookProfile._json.last_name,
            gender: facebookProfile.gender,
            password: req.query.password
        }, function (user) {
            JSON.stringify(user);
            if (user.isUserExist == false) {
                res.status(401).json({
                    success: false,
                    isUserExist: false,
                    message: 'Authentication failed. User not found.'
                });
            } else {
                var fbuser = {
                    user_id: user.id,
                    firstname: user.first_name,
                    lastname: user.last_name,
                    email: user.email,
                    location: user.location,
                    age_range: user.age_range,
                    gender: user.gender,
                    avatar: user.avatar,
                    neighbourhood_id: user.neighbourhood_id
                };
                crypt.compareHash(req.query.password, user.password, function (err, isMatch) {
                    if (isMatch && !err) {
                        var token = jwt.sign(user, config.secret, {
                            expiresIn: 100890 // in seconds
                        });
                        res.setHeader('token', 'JWT ' + token);
                        res.setHeader('Content-Type', 'application/json');
                        res.status(200).json({
                            success: true,
                            token: 'JWT ' + token,
                            user: fbuser
                        });
                    } else {
                        res.status(401).json({
                            success: false,
                            message: 'Authentication failed. Passwords did not match.'
                        });
                    }
                });
            }
        }, function (err) {
            return res.status(400).json({
                success: false,
                message: err
            });
        });
    });


    apiRoutes.get('/api/status', function (request, response) {
        db.fetchApiVersion({}, function (version) {
            response.header('data', 'data');
            response.send({
                "message": "Blockparty API is running...!!",
                "version": version
            })
        }, function (err) {
            response.status(404).json({
                success: false,
                message: err
            });
        });
    }, function (err) {
        response.status(404).json({
            success: false,
            message: err
        });
    });


    apiRoutes.post('/api/auth/login', function (request, response) {
        db.findOneUser({
            email: request.body.email.trim()
        }, function (res) {
            var user = {
                user_id: res.id,
                firstname: res.first_name,
                lastname: res.last_name,
                email: res.email,
                location: res.location,
                age_range: res.age_range,
                gender: res.gender,
                avatar: res.avatar,
                neighbourhood_id: request.body.neighbourhood_id,
                referral_code: res.referral
            };


            crypt.compareHash(request.body.password.trim(), res.password, function (err, isMatch) {
                if (isMatch && !err) {
                    var token = jwt.sign(user, config.secret, {
                        expiresIn: 100890 // in seconds
                    });
                    response.setHeader('token', 'JWT ' + token);
                    response.setHeader('Content-Type', 'application/json');
                    response.status(200).json({
                        success: true,
                        token: 'JWT ' + token,
                        user: user
                    });
                } else {
                    response.status(401).json({
                        success: false,
                        message: 'Authentication failed. Passwords did not match.'
                    });
                }
            });
        }, function (err) {
            response.status(401).json({
                success: false,
                message: 'Authentication failed. User not found.'
            });
        });
    });

    apiRoutes.put('/api/auth/updateReferralCode', function (request, response) {
        db.findOneUser({
            email: request.body.email.trim(),
            referral_code: request.body.referral_code
        }, function (res) {
            //response.send("user details")
            var user = {
                user_id: res.id,
                firstname: res.first_name,
                lastname: res.last_name,
                email: res.email,
                location: res.location,
                age_range: res.age_range,
                gender: res.gender,
                avatar: res.avatar,
                neighbourhood_id: request.body.neighbourhood_id,
                referral_code: res.referral
            }

            if (!res.referral && request.body.referral_code) {
                var str = (request.body.referral_code).trimLeft().trimRight()
                db.findReferralCode({
                    email: request.body.email,
                    referral_code: str
                }, function (res) {
                    db.updateReferralCode({
                        email: request.body.email,
                        referral_code: str
                    }, function (res) {
                        response.status(200).json({
                            success: true,
                            message: "data updated"
                        })
                    }, function (err) {
                        response.status(400).json({
                            success: true,
                            message: "data not updated"
                        })
                    })
                }, function (err) {
                    response.status(400).json({
                        success: false,
                        message: "data doesnot match so can not be updated"
                    })
                })
            } else {
                if (res.referral && request.body.referral_code)
                    var str = (request.body.referral_code).trimLeft().trimRight()
                db.findReferralCode({
                    email: request.body.email,
                    referral_code: str
                }, function (res) {
                    db.updateReferralCode({
                        email: request.body.email,
                        referral_code: str
                    }, function (res) {
                        response.status(200).json({
                            success: true,
                            message: "data updated"
                        })
                    }, function (err) {
                        response.status(400).json({
                            success: true,
                            message: "data not updated"
                        })
                    })
                }, function (err) {
                    response.status(400).json({
                        success: false,
                        message: "referral code doesnot match so can not be updated"
                    })
                })
            }
        }, function (err) {
            response.status(401).json({
                success: false,
                message: 'Authentication failed. User not found.'
            });
        });

    })

    // Register new users
    apiRoutes.post('/api/users', function (request, response) {
        if (!request.body.email || !request.body.password) {
            response.status(400).json({
                success: false,
                message: 'Please enter email and password.'
            });
        } else {
            var newUser = {
                email: request.body.email.trim(),
                password: request.body.password.trim(),
                first_name: request.body.first_name,
                last_name: request.body.last_name,
                avatar: request.body.avatar,
                location: request.body.location,
                age_range: request.body.age_range,
                gender: request.body.gender,
                home_type: request.body.home_type,
                move_planned: request.body.move_planned,
                is_admin: request.body.is_admin,
                timezone: request.body.timezone,
                update_date: request.body.update_date,
                neighbourhood_id: request.body.neighbourhood_id,
                referral_code: request.body.referral_code
            };
            db.findOneUser({
                email: request.body.email.trim()
            }, function (res) {
                response.status(401).json({
                    success: false,
                    message: 'Authentication failed. Email already exist.'
                });
            }, function (err) {
                if (request.body.referral_code) {
                    var str = (request.body.referral_code).trimLeft().trimRight()
                    db.createUser(newUser, function (res) {
                        response.status(201).json({
                            success: true,
                            message: 'Successfully created new user.'
                        });
                    })
                } else {
                    db.createUser(newUser, function (res) {
                        response.status(200).json({
                            success: true,
                            message: 'Successfully created new user.'
                        });
                    })
                }
            })
        }
    });


    apiRoutes.get('/api/auth/me', requireAuth, function (request, response) {
        db.findOneUser({
            email: request.user.email.trim()
        }, function (res) {
            var user = {
                user_id: res.id,
                firstname: res.firstname,
                lastname: res.lastname,
                email: res.email
            };
            response.header('data', 'data');
            response.send(user);
        }, function (err) {
            response.status(404).json({
                success: false,
                message: err
            });
        });
    }, function (err) {
        response.status(401).json({
            success: false,
            message: err
        });
    });

    app.put('/api/auth/resetPassword', requireAuth ,function (request, response) {
        if (!request.body.email || !request.body.password || !request.body.newPassword) {
            response.status(400).json({
                success: false,
                message: 'Please enter email and password.'
            });
        } else {
            db.findOneUser({
                email: request.body.email.trim(),
                password: request.body.password.trim()
            }, function (res) {
                var user = {
                    email: res.email,
                    password: res.Password
                }
                crypt.compareHash(request.body.password.trim(), res.password, function (err, isMatch) {
                    if (isMatch && !err) {
                        db.resetPassword({
                            email: request.body.email.trim(),
                            password: request.body.password.trim(),
                            newPassword: request.body.newPassword.trim(),
                        }, function (res) {
                            response.header('data', 'data');
                            response.send({
                                "data": res,
                            });
                        }, function (err) {
                            response.status(404).json({
                                success: false,
                                message: err
                            });
                        });
                    } else {
                        response.status(401).json({
                            success: false,
                            message: 'Current Password not match.'
                        });
                    }
                });
            })
        }
    })

    app.post('/api/forgotPassword' ,function (request, response) {
        if (!request.body.email || !request.body.newPassword) {
            response.status(400).json({
                success: false,
                message: 'Please enter email and password.'
            });
        } else {
            db.findOneUser({
                email: request.body.email.trim(),
                password: request.body.newPassword.trim()
            }, function (res) {
                var user = {
                    email: res.email,
                    password: res.Password
                }
                db.newPassword({
                    email: request.body.email.trim(),
                    newPassword: request.body.newPassword.trim(),
                }, function (res) {
                    response.header('data', 'data');
                    response.send({
                        "data": res,
                    });
                }, function (err) {
                    response.status(404).json({
                        success: false,
                        message: err
                    });
                });
            }, function (err) {
                response.status(401).json({
                    success: false,
                    message: ' User not found.'
                });
            })
        }
    });

    //Update user profile
    app.put('/api/auth/updateProfile', requireAuth, function (request, response) {
        if (!request.query.id) {
            response.send("ENTER USER ID")
        } else if (request.body.first_name && request.body.last_name && request.body.email && !request.body.avatar) {
            db.updateProfile({
                    id: request.query.id,
                    first_name: request.body.first_name,
                    last_name: request.body.last_name,
                    email: request.body.email,
                },
                function (res) {
                    response.header('data', 'data');
                    response.send({
                        "data": res,
                    });
                },
                function (err) {
                    response.status(404).json({
                        success: false,
                        message: err
                    });
                });
        } else if (request.body.avatar) {
            db.updateProfileImage({
                    id: request.query.id,
                    first_name: request.body.first_name,
                    last_name: request.body.last_name,
                    email: request.body.email,
                    avatar: request.body.avatar
                },
                function (res) {
                    response.header('data', 'data');
                    response.send({
                        "data": res,
                    });
                },
                function (err) {
                    response.status(404).json({
                        success: false,
                        message: err
                    });
                });
        } else {
            response.status(400).json({
                success: false,
                message: 'Please enter all the fields.'
            });
        }
    })

    function generateToken(res) {
        return jwt.sign(res, config.secret, {
            expiresIn: 100890 // in seconds
        });
    }

    app.post('/api/appleSignIn', function (request, response) {
        const {firstName, email, userToken, lastName, password} = request.body;
        if (email) {
            crypt.createHash(password, function (passwordHash) {
                db.updateOrAddUserFromAppleSignIn({
                        firstName: firstName,
                        email: email,
                        userToken: userToken,
                        lastName: lastName,
                        password: passwordHash
                    },
                    function (res) {
                        const token = generateToken(res);
                        response.header('data', 'data');
                        response.send({
                            'success': true,
                            'token': 'JWT ' + token,
                            "user": {
                                "user_id": res.id,
                                "firstname": res.first_name,
                                "lastname": res.last_name,
                                "email": res.email,
                                "location": res.location,
                                "age_range": res.age_range,
                                "gender": res.gender,
                                "avatar": res.avatar,
                                "referral_code": res.referral_code
                            }
                        });
                    },
                    function (err) {
                        response.status(HttpCodes.NOT_FOUND).json({
                            success: false,
                            message: err
                        });
                    });
            })
        } else if (userToken) {
            //get user details.
            db.getUserDetails({
                    userToken: userToken
                },
                function (res) {
                    const token = generateToken(res);
                    response.header('data', 'data');
                    response.send({
                        'success': true,
                        'token': 'JWT ' + token,
                        "user": {
                            "user_id": res.id,
                            "firstname": res.first_name,
                            "lastname": res.last_name,
                            "email": res.email,
                            "location": res.location,
                            "age_range": res.age_range,
                            "gender": res.gender,
                            "avatar": res.avatar,
                            "referral_code": res.referral_code
                        }
                    });
                }, function (err) {
                    response.status(HttpCodes.NOT_FOUND).json({
                        success: false,
                        message: err
                    })
                });
        } else {
            response.status(HttpCodes.NOT_FOUND).json({
                success: false,
                message: 'Something went wrong Please try again later.'
            })
        }
    });
    // Set url for API group routes
    app.use('', apiRoutes);
};
