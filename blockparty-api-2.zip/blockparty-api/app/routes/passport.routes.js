const express = require('express');
const PassportController = require('../controllers/PassPort.controller'),
	passportController = new PassportController();
const router = express.Router();

router.get('/', (req, res) => passportController.getPassportList(req, res));
router.get('/checkqrCode', (req, res) => passportController.validateQRCode(req, res));
router.get('/getPartyPack/:userId', (req, res) => passportController.getPartyPack(req, res));
router.put('/deal/redeem', (req, res) => passportController.redeem(req, res));
router.post('/qr', (req, res) => passportController.checkQrCode(req, res));
router.get('/purchased/:userId', (req, res) => passportController.purchasedList(req, res));
router.get('/:id', (req, res) => passportController.getPassportById(req, res))
module.exports = router;
