const express = require('express');
const AnalyticsController = require('../controllers/analytics.controller'),
    analyticsController = new AnalyticsController();
const router = express.Router();

router.post('/', (req, res) => analyticsController.addAnalytics(req, res));

module.exports = router;
