'use strict'
// Import dependencies
var passport = require('passport');
var express = require('express');
var config = require('../../config/main');

var db = require('../db/event.db');
var moment = require('moment');
// Set up middleware
var requireAuth = passport.authenticate('jwt', {
    session: false
});


module.exports = function (app) {
    // API Route Section

    app.use(passport.initialize());

    // Bring in defined Passport Strategy
    require('../../config/passport')(passport);

    // Create API group routes
    var apiRoutes = express.Router();

    passport.serializeUser(function (user, done) {
        done(null, user);
    });

    passport.deserializeUser(function (obj, done) {
        done(null, obj);
    });


    //Events list based on is_feature and to-do event
    apiRoutes.get('/api/auth/events', requireAuth, function (request, response) {
        var is_feature = request.query.is_feature
        var is_todo = request.query.is_todo
        var is_news_feed = request.query.is_news_feed
        if (!request.query.city && !request.query.is_feature) {
            response.send("Enter city name")
        } else if (!is_todo) {
            db.findFeaturedEvents({
                    city: request.query.city,
                    is_feature: request.query.is_feature
                }, function (res) {
                    response.header('data', 'data');
                    response.send({
                        "data": res,
                    });
                },
                function (err) {
                    response.status(404).json({
                        success: false,
                        message: err
                    });
                });
        } else if (is_todo !== 'undefined' & is_todo.toUpperCase() === "TRUE") {
            db.findEvents({
                city: request.query.city,
                is_todo: request.query.is_todo
            }, function (res) {
                response.header('data', 'data');
                var dateArray = [];
                for (var i = 0; i < 7; i++) {
                    var date = new Date();
                    date.setDate(date.getDate() + i);
                    dateArray.push(moment(date).format('YYYY MMMM DD'));
                }
                var responseArray = [];
                var keys = Object.keys(res);
                var keyValues = Object.values(res)
                for (var i = 0; i < keys.length; i++) {
                    var responseObject = {};
                    let value = keys[i].split(", ")
                    if (dateArray.includes(value[1])) {
                        responseObject['Day_' + [responseArray.length + 1]] = keyValues[i];
                        responseArray.push(responseObject);
                    }
                }
                response.send({
                    'data': responseArray
                });
            }, function (err) {
                response.status(404).json({
                    success: false,
                    message: err
                })
            });
        } else {
            response.status(404).json({
                success: false,
                message: "Invalid or missing query param!!"
            })
        }
    });

    apiRoutes.get('/api/auth/eventsToDo', requireAuth, (request, response) => {
        if (request.query.city) var city = request.query.city; else var city = 'Parker';
        db.findEventstodo({
                city: city,
                is_todo: true
            }, function (res) {
                response.header('data', 'data');
                var dateArray = [];
                for (var i = 0; i < 3; i++) {
                    var date = new Date();
                    date.setDate(date.getDate() + i);
                    dateArray.push(moment(date).format('YYYY MMMM DD'));
                }
                var responseArray = [], arrdata = [];
                var keys = Object.keys(res);
                var keyValues = Object.values(res)
                for (var i = 0; i < keys.length; i++) {
                    var responseObject = {};
                    let value = keys[i].split(", ")
                    if (dateArray.includes(value[1])) {
                        for (var j = 0; j < keyValues[i].length; j++) {
                            if (arrdata.length < 50) {
                                arrdata.push(keyValues[i][j]);
                            }
                        }
                        responseObject['Day_' + [responseArray.length + 1]] = keyValues[i];
                        responseArray.push(responseObject);
                    }
                }
                response.send({
                    'data': arrdata
                })
            },
            function (err) {
                response.status(404).json({
                    success: false,
                    message: err
                })
            })
    })

    //save events
    apiRoutes.post('/api/auth/saveEvents', requireAuth, function (request, response) {
        if (request.body.id != null && request.query.id != null) {
            db.saveEvents({
                event_id: request.body.id,
                user_id: request.query.id
            }, function (res) {
                response.header('data', 'data');
                response.send({
                    "data": res
                });
            });
        } else {
            response.status(404).json({
                success: false,
                message: "Can't save events"
            });
        }
    });

    apiRoutes.delete('/api/auth/deleteEvents', requireAuth,  (request, response) => {
        if  (request.query.user_id === request.user.id) {
            db.deleteSavedEvents({
                user_id: request.query.user_id,
                event_id:request.query.event_id
            }, function (res) {
                response.header('data', 'data');
                response.send({
                    "data": res
                });
            },function (err) {
                response.header('data', 'data');
                response.status(404);
                response.send({
                    "data": err
                });
            });
        } else {
            response.status(404).json({
                success: false,
                message: "Can't delete events"
            });
        }
    });

    //find save events
    apiRoutes.get('/api/auth/getEvents', requireAuth, function (request, response) {
        db.findSavedEventsbyid({
            user_id: request.query.id
        }, function (res) {
            response.header('data', 'data');
            response.send({
                "data": res
            });
        });
    })

    apiRoutes.get('/api/searchEvents', function (request, response) {
        var events = request.query.events
        var is_feature = request.query.is_feature
        var is_todo = request.query.is_todo
        var str = events.replace(/  +/g, ' ').trimLeft().trimRight()
        if (request.query.city != null && request.query.events != "" && is_feature) {
            db.searchEventsForFeature({
                city: request.query.city,
                name: str,
                is_feature: request.query.is_feature
            }, function (res) {
                response.header('data', 'data');
                response.send({
                    "data": res
                })
            });
        } else if (request.query.city != null && request.query.events != "" && is_todo) {
            db.searchEventsForTodo({
                city: request.query.city,
                name: str,
                is_todo: request.query.is_todo
            }, function (res) {
                response.header('data', 'data');
                response.send({
                    "data": res
                })
            });
        } else {
            response.status(404).json({
                success: false,
                message: "Enter a valid data"
            })
        }
    });


    apiRoutes.get('/api/auth/events/special', requireAuth, function (request, response) {
        if (request.query.city) var city = request.query.city; else var city = 'Parker';
        var photo = '';
        var photolist = [];
        db.findThingsTodo({
            city: city,
        }, function (res) {
            response.header('data', 'data');
            if (res.length > 0) {
                response.send({
                    'data': res
                });
            } else {
                response.header('data', 'data');
                response.send({
                    success: true,
                    "data": res
                });
            }
        }, function (err) {
            response.status(404).json({
                success: false,
                message: err
            })
        });

    });


    apiRoutes.get('/api/auth/business/special', requireAuth, function (request, response) {
        if (request.query.city) var city = request.query.city; else var city = 'Parker';
        db.businessspotlight({
            city: city,
        }, function (res) {
            response.header('data', 'data');
            response.send({
                success: true,
                "data": res
            });
        });
    });

    // Set url for API group routes
    app.use('', apiRoutes);
};
