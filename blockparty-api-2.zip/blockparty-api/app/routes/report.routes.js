const express = require('express');
const ReportController = require('../controllers/report.controller.js'),
	reportController = new ReportController();
const router = express.Router();

router.get('/hello', (req, res) => reportController.getHello(req, res));
//router.post('/cardSales', (req, res) => reportController.getPassportSales(req, res));
router.get('/creditcardSales', (req, res) => reportController.getPassportSales(req, res, 1));
router.get('/cashSales', (req, res) => reportController.getPassportSales(req, res, 0));
router.get('/analytics/redeemDeals', (req, res) => reportController.getRedeemDealReport(req, res));
router.post('/analytics/realtimeDeals', (req, res) => reportController.sendRealtimeData(req, res));
router.get('/analytics/viewedDeals', (req, res) => reportController.getViewedDealsReport(req, res));
router.get('/analytics/qrCode', (req, res) => reportController.getQrCodeReport(req, res));

module.exports = router;
