const express = require('express');
const TransactionsController = require('../controllers/Transactions.controller'),
	transactionsController = new TransactionsController();
const router = express.Router();

router.post('/success', (req, res) => transactionsController.addTransaction(req, res));
router.post('/redeem', (req, res) => transactionsController.redeemPassport(req, res));
router.post('/createPaymentIntent', (req, res) => transactionsController.createPaymentIntent(req, res));

module.exports = router;
