const express = require('express');
const AuthController = require('../controllers/auth.controller'),
    authController = new AuthController();
const router = express.Router();

router.get('/resetPassword', (req, res) => authController.updatePassword(req, res));

module.exports = router;
