'use strict';
// Include our packages in our main server file
var express = require('express');
const { handleError, ErrorHandler } = require('./app/helpers/error');
var app = express();
var bodyParser = require('body-parser');
var morgan = require('morgan');
var passport = require('passport');
var config = require('./config/main');
var crypt = require('./app/crypt');
var cors = require('cors');
var port = config.port;
var mongoose = require('mongoose');
const multer = require('multer');
const upload = multer();

//process.env.TZ = "Asia/Calcutta";
process.env.TZ = "America/Denver";
//process.env.TZ = "America/Vancouver";

console.log('#####:TIMEZONE STATUS:#####');
console.log(new Date().toString());

mongoose
	.connect(config.mongoURL, {
		user: config.mongoUN,
		pass: config.mongoPW,
		keepAlive: true,
		keepAliveInitialDelay: 300000,
		useNewUrlParser: true,
		useUnifiedTopology: true,
	})
	.then(() => {
		console.log('Connected to %s', config.mongoURL);
		console.log('App is running');
	});

mongoose.connection = true;
// Use body-parser to get POST requests for API use
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(upload.any());
app.use(cors());

// Log requests to console
app.use(morgan('dev'));

app.use(function (req, res, next) {
	const auth =
		req.headers['authorization'] == null ||
		req.headers['authorization'] == undefined ||
		req.headers['authorization'].length == 0;
	crypt.checkKey(req.headers['x-api-key'], function (err, isMatch) {
		if (!isMatch && !auth) {
			res.status(401).json({
				success: false,
				message: 'Missing API Key!!',
			});
		} else {
			console.log(
				'**************************************START*********************************************************'
			);
			console.log(new Date().toISOString());
			const fullUrl = req.protocol + '://' + req.get('host') + req.originalUrl;
			console.log('Request URL:============================== ' + fullUrl);
			console.log('Request Headers:========================== ' + JSON.stringify(req.headers));
			console.log('Request Body:============================= ' + JSON.stringify(req.body));
			next();
			console.log(
				'***************************************END********************************************************'
			);

		}
	});
});

// Home route. We'll end up changing this to our main front end index later.
app.get('/', function (req, res) {
	res.send('Welcome block party API - Deployed using CodeDeploy - v2.0.0');
});

require('./app/routes/deals')(app);
require('./app/routes/auth')(app);
require('./app/routes/category')(app);
require('./app/routes/event')(app);

const passports = require('./app/routes/passport.routes');
const transactions = require('./app/routes/transactions.routes');
const feedback = require('./app/routes/feedback.routes');
const report = require('./app/routes/report.routes');
const analytics = require('./app/routes/analytics.routes');
const auth = require('./app/routes/auth.routes');

app.use('/api/passports', passports);
app.use('/api/transactions', transactions);
app.use('/api/feedback', feedback);
app.use('/api/report', report);
app.use('/api/analytics', analytics);
app.use('/api/v2', auth);

app.get('/error', (req, res) => {
	throw new ErrorHandler(500, 'Internal server error');
});

app.use((err, req, res, next) => {
	handleError(err, res);
});
// Start the server
var s = app.listen(port);
s.setTimeout(500000);
console.log('Your server is running on port: ' + port);
